<div>
    @section('page_title', 'Clients Management')
    <!-- Breadcrumbs -->
    @if ($selectedClientDetailId && $clientDetails)
        <x-admin.breadcrumbs :items="['Clients' => route('admin.clients'), $clientDetails->user->name ?? 'Detail' => null]" />
    @else
        <x-admin.breadcrumbs :items="['Clients' => null]" />
    @endif

    @if ($selectedClientDetailId && $clientDetails)
        {{-- ==========================================
             CLIENT DETAIL DASHBOARD VIEW
             ========================================== --}}
        <!-- Client Header Card -->
        <div class="bg-white/93 dark:bg-slate-900/60 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-4 sm:p-6 mb-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4 sm:gap-6">
            <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4 min-w-0 w-full md:w-auto">
                <div class="relative shrink-0">
                    @if($clientDetails->profile_image)
                        <img src="{{ asset('storage/' . $clientDetails->profile_image) }}" alt="{{ $clientDetails->user->name }}" class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-800" />
                    @else
                        <div class="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-lg sm:text-xl font-bold text-indigo-600 dark:text-indigo-400">
                            {{ $clientDetails->getInitials() }}
                        </div>
                    @endif
                </div>
                <div class="min-w-0 flex-1">
                    <div class="flex items-center gap-2.5 flex-wrap">
                        <h1 class="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white break-words">{{ $clientDetails->user->name }}</h1>
                        <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase {{ $clientDetails->status === 'active' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-slate-500/10 text-slate-600 dark:text-slate-400' }} tracking-wider shrink-0">
                            {{ $clientDetails->status }}
                        </span>
                        @foreach($clientDetails->plans as $pl)
                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-{{ $pl->color }}-500/10 text-{{ $pl->color }}-600 dark:text-{{ $pl->color }}-400 tracking-wider shrink-0">
                                {{ $pl->name }}
                            </span>
                        @endforeach
                    </div>
                    <div class="mt-2 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium">
                        <span class="flex items-center gap-1.5 truncate max-w-full">
                            <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                            <span class="truncate">{{ $clientDetails->company_name ?: 'No Company' }}</span>
                        </span>
                        <span class="flex items-center gap-1.5 truncate max-w-full">
                            <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <span class="truncate">{{ $clientDetails->user->email }}</span>
                        </span>
                        @if($clientDetails->phones->isNotEmpty())
                            <span class="flex items-center gap-1.5 shrink-0">
                                <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.94.725l.548 2.2a1 1 0 01-.321.988l-1.305.98a10.582 10.582 0 004.872 4.872l.98-1.305a1 1 0 01.988-.321l2.2.548a1 1 0 01.725.94V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                </svg>
                                {{ $clientDetails->phones->first()->phone }}
                            </span>
                        @endif
                        <span class="flex items-center gap-1.5 shrink-0">
                            <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            Registered {{ $clientDetails->created_at->format('M d, Y') }} ({{ $clientDetails->created_at->diffForHumans() }})
                        </span>
                    </div>
                </div>
            </div>
            @php
                $detailMappingData = [
                    'id' => $clientDetails->id,
                    'name' => $clientDetails->user->name ?? 'Client',
                    'email' => $clientDetails->user->email ?? '',
                    'company_name' => $clientDetails->company_name ?? '',
                    'initials' => $clientDetails->getInitials(),
                ];
                $detailClickUpFolderIds = \App\Modules\CRM\ClickUp\Models\ClickUpFolder::where('client_id', $clientDetails->id)->pluck('id')->map(fn($id) => (string)$id)->toArray();
                $detailClientEditData = [
                    'id' => $clientDetails->id,
                    'user_id' => $clientDetails->user_id,
                    'name' => $clientDetails->user->name ?? '',
                    'email' => $clientDetails->user->email ?? '',
                    'company_name' => $clientDetails->company_name ?? '',
                    'profile_image' => $clientDetails->profile_image ?? '',
                    'status' => $clientDetails->status ?? 'active',
                    'notes' => $clientDetails->notes ?? '',
                    'address' => $clientDetails->address ?? '',
                    'landmark' => $clientDetails->landmark ?? '',
                    'state' => $clientDetails->state ?? '',
                    'country' => $clientDetails->country ?? '',
                    'region' => $clientDetails->region ?? '',
                    'zip_code' => $clientDetails->zip_code ?? '',
                    'phones' => $clientDetails->phones->isNotEmpty() 
                        ? $clientDetails->phones->map(fn($p) => ['phone' => $p->phone, 'label' => $p->label])->toArray() 
                        : [['phone' => '', 'label' => 'Work']],
                    'plan_ids' => $clientDetails->plans->pluck('id')->toArray(),
                    'assigned_staff_id' => $clientDetails->assignedStaff->first()?->id,
                ];
            @endphp
            <div class="flex flex-wrap items-center gap-2 w-full sm:w-auto shrink-0 justify-end">
                @if(!empty($detailClickUpFolderIds))
                    <button type="button"
                            wire:click="disconnectClickUpMapping({{ $clientDetails->id }})"
                            wire:confirm="Are you sure you want to disconnect ClickUp from {{ $clientDetails->company_name ?: ($clientDetails->user->name ?? 'this client') }}?"
                            class="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-800/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
                            title="Disconnect ClickUp from this client">
                        <span>Disconnect</span>
                        <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                    </button>
                @else
                    <button type="button" 
                            @click="
                                $dispatch('open-clickup-modal', { client: {{ Js::from($detailMappingData) }}, folderIds: {{ Js::from($detailClickUpFolderIds) }} });
                                $dispatch('open-modal', { name: 'clickup-client-mapping-modal' });
                            " 
                            class="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700 font-bold text-xs rounded-xl shadow-sm transition active:scale-95">
                        <span>Map With</span>
                        <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                    </button>
                @endif
                <button type="button" 
                        @click="
                            const data = {{ Js::from($detailClientEditData) }};
                            $wire.editingClientId = data.id;
                            $wire.editingUserId = data.user_id;
                            $wire.name = data.name;
                            $wire.email = data.email;
                            $wire.password = '';
                            $wire.company_name = data.company_name;
                            $wire.existing_profile_image = data.profile_image;
                            $wire.profile_image = '';
                            $wire.status = data.status;
                            $wire.notes = data.notes;
                            $wire.address = data.address;
                            $wire.landmark = data.landmark;
                            $wire.state = data.state;
                            $wire.country = data.country;
                            $wire.region = data.region;
                            $wire.zip_code = data.zip_code;
                            $wire.phones = data.phones;
                            $wire.plan_ids = data.plan_ids;
                            $wire.assigned_staff_id = data.assigned_staff_id;
                            $dispatch('open-modal', { name: 'edit-client-modal' });
                        " 
                        class="flex-1 sm:flex-none px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-350 font-bold text-xs rounded-xl active:scale-95 transition">
                    Edit
                </button>
            </div>
        </div>

        <!-- Tabs Navigation -->
        <div class="mb-6 bg-slate-100/80 dark:bg-slate-900/50 p-1.5 rounded-2xl overflow-x-auto no-scrollbar border border-slate-200/40 dark:border-slate-800/40">
            <nav class="flex flex-nowrap space-x-1 min-w-max" aria-label="Tabs">
                @foreach([
                    'overview' => 'Overview', 
                    'clickup_tickets' => 'ClickUp Tickets', 
                    'websites' => 'Websites', 
                    'marketing' => 'Marketing',
                    'maintenance' => 'Maintenance', 
                    'support' => 'Support',
                    'documents' => 'Documents', 
                    'activity log' => 'Activity', 
                    'integrations' => 'Integrations',
                    'settings' => 'Settings'
                ] as $tabKey => $tabLabel)
                    <a href="{{ route('admin.clients.detail', ['id' => $clientDetails->id, 'tab' => $tabKey]) }}" wire:navigate
                       class="py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all duration-150 flex items-center gap-1.5 shrink-0 {{ $activeTab === $tabKey ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 hover:text-slate-850 hover:bg-white/40 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800/30' }}">
                        <span>{{ $tabLabel }}</span>
                    </a>
                @endforeach
            </nav>
        </div>

        <!-- Tab Contents -->
        @if ($activeTab === 'overview')
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fadeIn">
                <!-- About Card -->
                <div class="lg:col-span-2 space-y-6">
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4">About</h3>
                        <p class="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                            {{ $clientDetails->notes ?: 'No additional notes provided for this client.' }}
                        </p>
                    </div>

                    <!-- Address Section -->
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4">Address Details</h3>
                        @if($clientDetails->address || $clientDetails->landmark || $clientDetails->state || $clientDetails->country || $clientDetails->region || $clientDetails->zip_code)
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                                @if($clientDetails->address)
                                    <div class="col-span-2 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                        <span class="font-bold text-slate-400 uppercase text-[10px] block mb-1">Street Address</span>
                                        <span class="text-slate-800 dark:text-slate-200 font-semibold">{{ $clientDetails->address }}</span>
                                    </div>
                                @endif
                                @if($clientDetails->landmark)
                                    <div class="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                        <span class="font-bold text-slate-400 uppercase text-[10px] block mb-1">Landmark</span>
                                        <span class="text-slate-800 dark:text-slate-200 font-semibold">{{ $clientDetails->landmark }}</span>
                                    </div>
                                @endif
                                @if($clientDetails->region)
                                    <div class="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                        <span class="font-bold text-slate-400 uppercase text-[10px] block mb-1">Region</span>
                                        <span class="text-slate-800 dark:text-slate-200 font-semibold">{{ $clientDetails->region }}</span>
                                    </div>
                                @endif
                                @if($clientDetails->state)
                                    <div class="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                        <span class="font-bold text-slate-400 uppercase text-[10px] block mb-1">State / Province</span>
                                        <span class="text-slate-800 dark:text-slate-200 font-semibold">{{ $clientDetails->state }}</span>
                                    </div>
                                @endif
                                @if($clientDetails->country)
                                    <div class="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                        <span class="font-bold text-slate-400 uppercase text-[10px] block mb-1">Country</span>
                                        <span class="text-slate-800 dark:text-slate-200 font-semibold">{{ $clientDetails->country }}</span>
                                    </div>
                                @endif
                                @if($clientDetails->zip_code)
                                    <div class="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                        <span class="font-bold text-slate-400 uppercase text-[10px] block mb-1">ZIP / Postal Code</span>
                                        <span class="text-slate-800 dark:text-slate-200 font-semibold">{{ $clientDetails->zip_code }}</span>
                                    </div>
                                @endif
                            </div>
                        @else
                            <div class="text-sm text-slate-500 dark:text-slate-400 italic">No address details added.</div>
                        @endif
                    </div>
                </div>

                <!-- Sidebar Cards -->
                <div class="space-y-6">
                    <!-- Assigned Plans -->
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Assigned Plans</h3>
                            @if($clientDetails->plans->isNotEmpty())
                                <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                                    {{ $clientDetails->plans->count() }} {{ Str::plural('Plan', $clientDetails->plans->count()) }}
                                </span>
                            @endif
                        </div>
                        <div class="space-y-3">
                            @forelse($clientDetails->plans as $plan)
                                <div class="p-3 bg-indigo-50/50 dark:bg-indigo-900/20 rounded-xl border border-indigo-100 dark:border-indigo-800/40 flex items-center justify-between gap-3">
                                    <div class="min-w-0 flex-1">
                                        <h4 class="text-xs font-bold text-indigo-900 dark:text-indigo-300 truncate">{{ $plan->name }}</h4>
                                        <p class="text-[10px] text-indigo-700/70 dark:text-indigo-400/70 line-clamp-2 mt-0.5">{{ $plan->description ?: 'No description' }}</p>
                                    </div>
                                    <span class="px-2 py-0.5 bg-indigo-600 text-white rounded text-[10px] font-bold shrink-0">Active</span>
                                </div>
                            @empty
                                <div class="text-sm text-slate-500 dark:text-slate-400 italic">No plans assigned.</div>
                            @endforelse
                        </div>
                    </div>

                    <!-- Reports & Integrations -->
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Reports & Integrations</h3>
                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                                Analytics
                            </span>
                        </div>
                        <div class="space-y-4">
                            <p class="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                                View marketing performance, traffic analytics, and SEO rankings from connected third-party platforms.
                            </p>
                            
                            <div class="flex items-center gap-2 mb-4">
                                <div class="w-8 h-8 rounded-full bg-orange-50 dark:bg-orange-900/20 flex items-center justify-center text-orange-500 border border-orange-100 dark:border-orange-800/50" title="Google Analytics 4">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                                </div>
                                <div class="w-8 h-8 rounded-full bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-500 border border-blue-100 dark:border-blue-800/50" title="Google Search Console">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                                </div>
                                <div class="w-8 h-8 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-500 border border-emerald-100 dark:border-emerald-800/50" title="Google Ads">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 6l-9.5 9.5-5-5L1 18"></path><polyline points="17 6 23 6 23 12"></polyline></svg>
                                </div>
                                <div class="w-8 h-8 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 border border-slate-200 dark:border-slate-700 text-[10px] font-bold">
                                    +3
                                </div>
                            </div>

                            <a href="{{ route('admin.clients.detail', ['id' => $clientDetails->id, 'tab' => 'integrations']) }}" wire:navigate
                                class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-900/30 dark:hover:bg-indigo-900/50 text-indigo-650 dark:text-indigo-400 font-bold text-xs rounded-xl transition active:scale-95">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                                </svg>
                                View Integrations & Reports
                            </a>
                        </div>
                    </div>

                    <!-- Assigned Staff Members -->
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Assigned Staff</h3>
                            @if($clientDetails->assignedStaff->isNotEmpty())
                                <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                                    {{ $clientDetails->assignedStaff->count() }} {{ Str::plural('Member', $clientDetails->assignedStaff->count()) }}
                                </span>
                            @endif
                        </div>
                        <div class="space-y-3">
                            @forelse($clientDetails->assignedStaff as $staff)
                                @php
                                    $staffImg = $staff->profile_image;
                                    $staffImgUrl = $staffImg ? (Str::startsWith($staffImg, 'http') ? $staffImg : asset('storage/' . $staffImg)) : null;
                                    $staffDesignation = $staff->designations->pluck('name')->implode(', ') ?: 'Staff Member';
                                    $staffDetailUrl = route('admin.staff.detail', ['id' => $staff->id]);
                                @endphp
                                <div class="flex items-center justify-between gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-700/60 hover:bg-slate-100/60 dark:hover:bg-slate-800 transition-colors">
                                    <a href="{{ $staffDetailUrl }}" class="flex items-center gap-3 min-w-0 flex-1 group">
                                        <div class="shrink-0">
                                            @if($staffImgUrl)
                                                <img src="{{ $staffImgUrl }}" alt="{{ $staff->user->name ?? 'Staff' }}"
                                                     class="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:border-indigo-500 transition-colors"
                                                     onerror="this.outerHTML=`<div class='w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center'>{{ $staff->getInitials() }}</div>`" />
                                            @else
                                                <div class="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                                    {{ $staff->getInitials() }}
                                                </div>
                                            @endif
                                        </div>
                                        <div class="min-w-0 flex-1">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors truncate flex items-center gap-1">
                                                <span>{{ $staff->user->name ?? 'Staff Member' }}</span>
                                                <svg class="w-3 h-3 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                </svg>
                                            </h4>
                                            <div class="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 truncate">{{ $staffDesignation }}</div>
                                            @if(!empty($staff->user->email))
                                                <div class="flex items-center gap-1 text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                                                    <svg class="w-3 h-3 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                                    </svg>
                                                    <span class="truncate">{{ $staff->user->email }}</span>
                                                </div>
                                            @endif
                                        </div>
                                    </a>
                                </div>
                            @empty
                                <div class="text-sm text-slate-500 dark:text-slate-400 italic">No staff assigned.</div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>

        @elseif ($activeTab === 'clickup_tickets')
            <div wire:init="loadClickUpTasks" class="space-y-6 animate-fadeIn">
                <!-- Header Banner -->
                <div class="bg-white/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                            <div class="flex items-center gap-2 mb-1">
                                <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp" class="h-5 w-auto" />
                                <h3 class="text-lg font-extrabold text-slate-900 dark:text-white">Tickets & Tasks</h3>
                            </div>
                            <p class="text-xs text-slate-500 dark:text-slate-400">
                                Live tickets from ClickUp folders assigned to {{ $clientDetails->company_name ?: ($clientDetails->user->name ?? 'this client') }}.
                            </p>
                        </div>

                        <div class="flex items-center gap-3">
                            <button type="button" 
                                    @click="
                                        $dispatch('open-clickup-modal', { client: {{ Js::from($detailMappingData) }}, folderIds: {{ Js::from($detailClickUpFolderIds) }} });
                                        $dispatch('open-modal', { name: 'clickup-client-mapping-modal' });
                                    " 
                                    class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition active:scale-95">
                                <svg class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                </svg>
                                <span>Manage Mapped Folders</span>
                            </button>

                            <button type="button" wire:click="syncClientClickUpTasks" wire:loading.attr="disabled"
                                    class="inline-flex items-center gap-2 px-4 py-2 bg-[#135266] hover:bg-[#0f4152] text-white font-bold text-xs rounded-xl shadow transition active:scale-95">
                                <svg wire:loading.class="animate-spin" wire:target="syncClientClickUpTasks" class="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                </svg>
                                <span wire:loading.remove wire:target="syncClientClickUpTasks">Sync Tickets API</span>
                                <span wire:loading wire:target="syncClientClickUpTasks">Syncing...</span>
                            </button>
                        </div>
                    </div>

                    <!-- Mapped Folders Badges -->
                    <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center flex-wrap gap-2 text-xs">
                        <span class="font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider text-[10px]">Assigned Folders:</span>
                        @forelse($clientClickUpFolders as $cFolder)
                            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-400 font-bold border border-amber-500/20">
                                <svg class="w-3.5 h-3.5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                </svg>
                                {{ $cFolder->name }}
                            </span>
                        @empty
                            <span class="text-slate-400 italic">No folders assigned yet.</span>
                        @endforelse
                    </div>
                </div>

                @if(!$clickUpTasksLoaded)
                    <!-- Livewire Deferred Loading Skeleton Animation (Shown immediately when tab opens) -->
                    <div class="w-full space-y-4 animate-pulse">
                        <!-- Skeleton Filter Bar -->
                        <div class="h-14 bg-slate-200/60 dark:bg-slate-800/50 rounded-2xl w-full"></div>

                        <!-- Skeleton Accordion / Ticket Cards -->
                        <div class="space-y-4">
                            @for($i = 0; $i < 3; $i++)
                                <div class="bg-white/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 space-y-4">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center gap-3">
                                            <div class="w-9 h-9 rounded-xl bg-slate-200 dark:bg-slate-800"></div>
                                            <div class="space-y-2">
                                                <div class="w-44 h-4 bg-slate-200 dark:bg-slate-800 rounded-md"></div>
                                                <div class="w-28 h-3 bg-slate-200/70 dark:bg-slate-800/50 rounded-md"></div>
                                            </div>
                                        </div>
                                        <div class="w-20 h-7 bg-slate-200 dark:bg-slate-800 rounded-full"></div>
                                    </div>
                                </div>
                            @endfor
                        </div>
                    </div>
                @else
                    @if($clientClickUpFolders->isEmpty())
                        <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-10 text-center">
                            <svg class="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                            </svg>
                            <h4 class="font-bold text-slate-800 dark:text-slate-200 text-base mb-1">No ClickUp Folders Assigned</h4>
                            <p class="text-xs text-slate-400 max-w-sm mx-auto mb-4">Please assign 1 or more ClickUp folders to this client to view their tickets here.</p>
                            <button type="button" 
                                    @click="
                                        $dispatch('open-clickup-modal', { client: {{ Js::from($detailMappingData) }}, folderIds: {{ Js::from($detailClickUpFolderIds) }} });
                                        $dispatch('open-modal', { name: 'clickup-client-mapping-modal' });
                                    " 
                                    class="inline-flex items-center gap-2 px-4 py-2 bg-[#135266] text-white text-xs font-bold rounded-xl shadow active:scale-95 transition">
                                Map With ClickUp
                            </button>
                        </div>
                    @else
                    <!-- Status & Folder Filters Bar (Search Removed) -->
                    @if($clientClickUpFolders->count() > 1 || !empty($clientClickUpTasks))
                        <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-3.5 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                            <span class="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5 shrink-0">
                                <svg class="w-4 h-4 text-[#135266]" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
                                </svg>
                                Filter Tickets:
                            </span>

                            <div class="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto">
                                <!-- Folder Filter -->
                                @if($clientClickUpFolders->count() > 1)
                                    <select wire:model.live="clickUpTaskFolderFilter"
                                            class="block w-full sm:w-48 px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#135266]/40 focus:border-[#135266]">
                                        <option value="">All Folders ({{ $clientClickUpFolders->count() }})</option>
                                        @foreach($clientClickUpFolders as $cf)
                                            <option value="{{ $cf->id }}">{{ $cf->name }}</option>
                                        @endforeach
                                    </select>
                                @endif

                                <!-- Status Filter (Dynamic Options from ClickUp) -->
                                <select wire:model.live="clickUpTaskStatusFilter"
                                        class="block w-full sm:w-48 px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#135266]/40 focus:border-[#135266]">
                                    <option value="">All Statuses ({{ count($clickUpStatuses) }})</option>
                                    @foreach($clickUpStatuses as $st)
                                        <option value="{{ $st }}">{{ ucfirst($st) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    @endif

                    <!-- Tasks List (FAQ/Accordion for Multiple Folders, Flat View for Single Folder) -->
                    @if($clientClickUpFolders->count() > 1)
                        <!-- Accordion / FAQ Collapsible View for Multiple Folders (Closed by default) -->
                        <div class="space-y-4">
                            @foreach($clientClickUpFolders as $cFolder)
                                @php
                                    $folderTasks = collect($filteredClickUpTasks)->where('folder_id', (string)$cFolder->id);
                                @endphp
                                <div x-data="{ open: false }" class="bg-white/80 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800/70 rounded-2xl overflow-hidden shadow-sm transition">
                                    <!-- Accordion Header (Click to toggle) -->
                                    <button type="button" @click="open = !open" 
                                            class="w-full px-5 py-4 flex items-center justify-between gap-4 bg-slate-50/80 dark:bg-slate-800/50 hover:bg-slate-100/80 dark:hover:bg-slate-800/80 transition text-left">
                                        <div class="flex items-center gap-3">
                                            <div class="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 shrink-0">
                                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                </svg>
                                            </div>
                                            <div>
                                                <h4 class="font-extrabold text-slate-900 dark:text-white text-base">
                                                    {{ $cFolder->name }}
                                                </h4>
                                                <p class="text-xs text-slate-500 dark:text-slate-400">
                                                    {{ count($folderTasks) }} {{ Str::plural('ticket', count($folderTasks)) }}
                                                </p>
                                            </div>
                                        </div>

                                        <div class="flex items-center gap-3">
                                            <span class="px-2.5 py-1 rounded-full text-xs font-extrabold bg-[#135266]/10 text-[#135266] dark:bg-teal-400/10 dark:text-teal-400">
                                                {{ count($folderTasks) }} {{ Str::plural('Ticket', count($folderTasks)) }}
                                            </span>
                                            <svg class="w-5 h-5 text-slate-400 transition-transform duration-200" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                            </svg>
                                        </div>
                                    </button>

                                    <!-- Accordion Body (Tickets inside folder) -->
                                    <div x-show="open" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 -translate-y-2" x-transition:enter-end="opacity-100 translate-y-0" class="p-4 border-t border-slate-100 dark:border-slate-800 space-y-3 bg-slate-50/30 dark:bg-slate-950/20">
                                        @forelse($folderTasks as $task)
                                            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 hover:border-slate-300 dark:hover:border-slate-700 rounded-2xl p-4 shadow-sm transition">
                                                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                                    <div class="space-y-1.5 flex-1 min-w-0">
                                                        <div class="flex items-center flex-wrap gap-2">
                                                            <!-- List Tag -->
                                                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                                                {{ $task['list_name'] }}
                                                            </span>

                                                            <!-- Status Badge -->
                                                            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider" style="background-color: {{ $task['status_color'] }}1a; color: {{ $task['status_color'] }}">
                                                                <span class="w-1.5 h-1.5 rounded-full" style="background-color: {{ $task['status_color'] }}"></span>
                                                                {{ $task['status'] }}
                                                            </span>
                                                        </div>

                                                        <!-- Task Title -->
                                                        <h4 class="font-extrabold text-slate-900 dark:text-white text-base leading-snug">
                                                            {{ $task['name'] }}
                                                        </h4>

                                                        @if($task['description'])
                                                            <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                                                {{ $task['description'] }}
                                                            </p>
                                                        @endif
                                                    </div>

                                                    <!-- Right Side Info & Actions -->
                                                    <div class="flex sm:flex-col items-end justify-between sm:justify-center gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 dark:border-slate-800">
                                                        <!-- Open in ClickUp Link -->
                                                        <a href="{{ $task['url'] }}" target="_blank"
                                                           class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 font-bold text-xs rounded-xl transition">
                                                            <span>Open Ticket</span>
                                                            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                                <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                                            </svg>
                                                        </a>

                                                        <!-- Assignees & Dates -->
                                                        <div class="flex items-center gap-3 text-xs text-slate-400 dark:text-slate-500">
                                                            @if(!empty($task['assignees']))
                                                                <div class="flex items-center -space-x-1.5" title="Assigned To: {{ implode(', ', array_column($task['assignees'], 'username')) }}">
                                                                    @foreach($task['assignees'] as $assignee)
                                                                        @if(!empty($assignee['profilePicture']))
                                                                            <img src="{{ $assignee['profilePicture'] }}" alt="{{ $assignee['username'] }}" class="w-5 h-5 rounded-full object-cover border border-white dark:border-slate-900" />
                                                                        @else
                                                                            <div class="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-white dark:border-slate-900 flex items-center justify-center text-[9px] font-bold">
                                                                                {{ strtoupper(substr($assignee['username'], 0, 2)) }}
                                                                            </div>
                                                                        @endif
                                                                    @endforeach
                                                                </div>
                                                            @else
                                                                <span class="text-[11px] italic">Unassigned</span>
                                                            @endif

                                                            @if($task['date_created'])
                                                                <span class="text-[11px] font-mono">{{ $task['date_created'] }}</span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @empty
                                            <div class="py-6 text-center text-slate-400 text-xs italic">
                                                No active tickets found in this folder.
                                            </div>
                                        @endforelse
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <!-- Single Folder Flat View (No Accordion) -->
                        <div class="space-y-3">
                            @forelse($filteredClickUpTasks as $task)
                                <div class="bg-white/80 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800/60 hover:border-slate-300 dark:hover:border-slate-700 rounded-2xl p-4 shadow-sm transition">
                                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                        <div class="space-y-1.5 flex-1 min-w-0">
                                            <div class="flex items-center flex-wrap gap-2">
                                                <!-- Folder Tag -->
                                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                                    <svg class="w-3 h-3 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                    </svg>
                                                    {{ $task['folder_name'] }} / {{ $task['list_name'] }}
                                                </span>

                                                <!-- Status Badge -->
                                                <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider" style="background-color: {{ $task['status_color'] }}1a; color: {{ $task['status_color'] }}">
                                                    <span class="w-1.5 h-1.5 rounded-full" style="background-color: {{ $task['status_color'] }}"></span>
                                                    {{ $task['status'] }}
                                                </span>
                                            </div>

                                            <!-- Task Title -->
                                            <h4 class="font-extrabold text-slate-900 dark:text-white text-base leading-snug">
                                                {{ $task['name'] }}
                                            </h4>

                                            @if($task['description'])
                                                <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                                    {{ $task['description'] }}
                                                </p>
                                            @endif
                                        </div>

                                        <!-- Right Side Info & Actions -->
                                        <div class="flex sm:flex-col items-end justify-between sm:justify-center gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 dark:border-slate-800">
                                            <!-- Open in ClickUp Link -->
                                            <a href="{{ $task['url'] }}" target="_blank"
                                               class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 font-bold text-xs rounded-xl transition">
                                                <span>Open Ticket</span>
                                                <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                                </svg>
                                            </a>

                                            <!-- Assignees & Dates -->
                                            <div class="flex items-center gap-3 text-xs text-slate-400 dark:text-slate-500">
                                                @if(!empty($task['assignees']))
                                                    <div class="flex items-center -space-x-1.5" title="Assigned To: {{ implode(', ', array_column($task['assignees'], 'username')) }}">
                                                        @foreach($task['assignees'] as $assignee)
                                                            @if(!empty($assignee['profilePicture']))
                                                                <img src="{{ $assignee['profilePicture'] }}" alt="{{ $assignee['username'] }}" class="w-5 h-5 rounded-full object-cover border border-white dark:border-slate-900" />
                                                            @else
                                                                <div class="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-white dark:border-slate-900 flex items-center justify-center text-[9px] font-bold">
                                                                    {{ strtoupper(substr($assignee['username'], 0, 2)) }}
                                                                </div>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                @else
                                                    <span class="text-[11px] italic">Unassigned</span>
                                                @endif

                                                @if($task['date_created'])
                                                    <span class="text-[11px] font-mono">{{ $task['date_created'] }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-8 text-center text-slate-400 text-xs">
                                    No ClickUp tickets found matching your filter criteria.
                                </div>
                            @endforelse
                        </div>
                    @endif
                @endif
            @endif
            </div>

        @elseif ($activeTab === 'websites')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl overflow-hidden shadow-sm animate-fadeIn">
                @if ($clientWebsites->isEmpty())
                    <div class="text-center py-12 text-slate-500">No websites associated with this client.</div>
                @else
                    <table class="w-full text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                        <thead>
                            <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                <th class="px-6 py-4">Domain</th>
                                <th class="px-6 py-4">Hosting</th>
                                <th class="px-6 py-4">SSL</th>
                                <th class="px-6 py-4">Health</th>
                                <th class="px-6 py-4">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                            @foreach ($clientWebsites as $site)
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                    <td class="px-6 py-4">
                                        <div class="font-bold text-slate-900 dark:text-white">
                                            <a href="{{ $site->url }}" target="_blank" class="hover:text-indigo-600 dark:hover:text-indigo-400 hover:underline">
                                                {{ $site->site_name }}
                                            </a>
                                        </div>
                                        <div class="text-xs text-slate-400 dark:text-slate-500 font-medium">
                                            {{ parse_url($site->url, PHP_URL_HOST) ?: $site->url }}
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-slate-600 dark:text-slate-300 font-semibold">{{ $site->hosting_provider ?: '—' }}</td>
                                    <td class="px-6 py-4">
                                        <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">Valid</span>
                                    </td>
                                    <td class="px-6 py-4 font-bold text-slate-700 dark:text-slate-350">
                                        {{ $site->latestMaintenanceReport?->health_score ? $site->latestMaintenanceReport->health_score . '%' : '—' }}
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">Online</span>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>

        @elseif ($activeTab === 'maintenance')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl overflow-hidden shadow-sm animate-fadeIn">
                @if ($clientMaintenanceReports->isEmpty())
                    <div class="text-center py-12 text-slate-500">No reports yet</div>
                @else
                    <table class="w-full text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                        <thead>
                            <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                <th class="px-6 py-4">ID</th>
                                <th class="px-6 py-4">Month</th>
                                <th class="px-6 py-4">Score</th>
                                <th class="px-6 py-4">Status</th>
                                <th class="px-6 py-4">Author</th>
                                <th class="px-6 py-4 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                            @foreach ($clientMaintenanceReports as $report)
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                    <td class="px-6 py-4 text-slate-400 dark:text-slate-500">#{{ $report->id }}</td>
                                    <td class="px-6 py-4 font-bold text-slate-900 dark:text-white">{{ $report->maintenance_month }}</td>
                                    <td class="px-6 py-4 font-bold text-slate-700 dark:text-slate-350">{{ $report->health_score }}%</td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase {{ $report->status === 'completed' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-amber-500/10 text-amber-600 dark:text-amber-400' }} tracking-wider">
                                            {{ $report->status }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-slate-600 dark:text-slate-400 font-semibold">{{ $report->developer->name ?? 'System' }}</td>
                                    <td class="px-6 py-4 text-right">
                                        <div class="inline-flex items-center justify-end gap-1">
                                            {{-- View button --}}
                                            <a href="{{ route('admin.maintenance.view', $report->id) }}"
                                               class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="View Report">
                                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                                </svg>
                                            </a>

                                            {{-- Edit button --}}
                                            <a href="{{ route('admin.maintenance.edit', $report->id) }}"
                                               class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="Edit Report">
                                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                </svg>
                                            </a>

                                            {{-- PDF button --}}
                                            <a href="{{ route('admin.maintenance.pdf', $report->id) }}" target="_blank"
                                               class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="Generate PDF">
                                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                </svg>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="mt-4 p-4 border-t border-slate-200/50 dark:border-slate-800/40">
                        {{ $clientMaintenanceReports->links() }}
                    </div>
                @endif
            </div>

        @elseif ($activeTab === 'documents')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl overflow-hidden shadow-sm animate-fadeIn">
                @if ($clientDocuments->isEmpty())
                    <div class="text-center py-12 text-slate-500">No resources or links added yet.</div>
                @else
                    <table class="w-full text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                        <thead>
                            <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                <th class="px-6 py-4">Name</th>
                                <th class="px-6 py-4">Type</th>
                                <th class="px-6 py-4">Size</th>
                                <th class="px-6 py-4">Uploaded</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                            @foreach ($clientDocuments as $doc)
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                    <td class="px-6 py-4 font-bold text-indigo-600 dark:text-indigo-400">
                                        <a href="{{ asset('storage/' . $doc->file_path) }}" target="_blank" class="hover:underline">
                                            {{ $doc->title }}
                                        </a>
                                    </td>
                                    <td class="px-6 py-4 text-slate-600 dark:text-slate-400 uppercase font-bold text-xs">{{ $doc->file_type ?: 'PDF' }}</td>
                                    <td class="px-6 py-4 text-slate-600 dark:text-slate-350 font-semibold">{{ $doc->file_size ? number_format($doc->file_size / (1024 * 1024), 1) . ' MB' : '—' }}</td>
                                    <td class="px-6 py-4 text-slate-500 dark:text-slate-500 text-xs font-medium">{{ $doc->created_at->format('Y-m-d') }} - {{ $doc->addedBy->name ?? 'System' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="mt-4 p-4 border-t border-slate-200/50 dark:border-slate-800/40">
                        {{ $clientDocuments->links() }}
                    </div>
                @endif
            </div>

        @elseif ($activeTab === 'activity log')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6 shadow-sm animate-fadeIn">
                @if ($clientActivityLogs->isEmpty())
                    <div class="text-center py-6 text-slate-500">No activity logs recorded yet.</div>
                @else
                    <div class="flow-root">
                        <ul class="-mb-8">
                            @foreach ($clientActivityLogs as $log)
                                <li>
                                    <div class="relative pb-8">
                                        @if (!$loop->last)
                                            <span class="absolute top-4 left-4 -ml-px h-full w-0.5 bg-slate-200 dark:bg-slate-800" aria-hidden="true"></span>
                                        @endif
                                        <div class="relative flex space-x-3">
                                            <div>
                                                <span class="h-8 w-8 rounded-full bg-slate-100 dark:bg-slate-850 flex items-center justify-center ring-8 ring-white dark:ring-slate-900">
                                                    <svg class="h-4 w-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                </span>
                                            </div>
                                            <div class="flex-1 min-w-0 pt-1.5 flex justify-between space-x-4">
                                                <div>
                                                    <p class="text-sm text-slate-600 dark:text-slate-350">{{ $log->description }}</p>
                                                </div>
                                                <div class="text-right text-xs whitespace-nowrap text-slate-400 dark:text-slate-500">
                                                    <time datetime="{{ $log->created_at }}">{{ $log->created_at->diffForHumans() }}</time>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="mt-4">
                        {{ $clientActivityLogs->links() }}
                    </div>
                @endif
            </div>

        @elseif ($activeTab === 'marketing')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6 shadow-sm animate-fadeIn">
                <div class="flex items-center gap-3 mb-4">
                    <div class="p-2 rounded-xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 shrink-0">
                        <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-slate-900 dark:text-white">Marketing Performance Hub</h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">Track and review comprehensive marketing stats and campaign results.</p>
                    </div>
                </div>
                <div class="border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center bg-slate-50/20 dark:bg-slate-950/10">
                    <svg class="w-12 h-12 text-slate-350 dark:text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 002 2h2a2 2 0 002-2z" />
                    </svg>
                    <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm mb-1">Marketing Reports Coming Soon</h4>
                    <p class="text-xs text-slate-450 dark:text-slate-550 max-w-md mx-auto">We are actively working on building comprehensive marketing performance reports. Soon you will be able to track search performance, campaign statistics, and SEO health directly from this dashboard.</p>
                </div>
            </div>

        @elseif ($activeTab === 'support')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6 shadow-sm animate-fadeIn">
                <div class="flex items-center justify-between gap-4 mb-5 pb-4 border-b border-slate-100 dark:border-slate-800/60">
                    <div>
                        <h3 class="text-base font-bold text-slate-900 dark:text-white">Client Support Tickets</h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">All registered support requests and responses for this client.</p>
                    </div>
                </div>

                @if($clientSupportTickets->isEmpty())
                    <div class="border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center bg-slate-50/20 dark:bg-slate-950/10">
                        <svg class="w-12 h-12 text-slate-350 dark:text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm mb-1">No Support Tickets Found</h4>
                        <p class="text-xs text-slate-450 dark:text-slate-550">This client has not opened any support requests yet.</p>
                    </div>
                @else
                    <div class="overflow-x-auto rounded-xl border border-slate-200/50 dark:border-slate-800/50">
                        <table class="w-full text-left border-collapse text-xs">
                            <thead>
                                <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                    <th class="px-4 py-3">Ticket ID</th>
                                    <th class="px-4 py-3">Subject</th>
                                    <th class="px-4 py-3">Category</th>
                                    <th class="px-4 py-3">Priority</th>
                                    <th class="px-4 py-3">Status</th>
                                    <th class="px-4 py-3">Last Active</th>
                                    <th class="px-4 py-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-slate-700 dark:text-slate-350">
                                @foreach($clientSupportTickets as $ticket)
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                        <td class="px-4 py-3 font-semibold font-mono text-slate-500">{{ $ticket->ticket_number }}</td>
                                        <td class="px-4 py-3 font-bold text-slate-900 dark:text-white">{{ $ticket->subject }}</td>
                                        <td class="px-4 py-3 font-semibold">{{ ucfirst($ticket->category) }}</td>
                                        <td class="px-4 py-3">
                                            @php
                                                $prioColor = [
                                                    'low' => 'slate',
                                                    'medium' => 'indigo',
                                                    'high' => 'amber',
                                                    'urgent' => 'red',
                                                ][$ticket->priority] ?? 'slate';
                                            @endphp
                                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-{{ $prioColor }}-500/10 text-{{ $prioColor }}-600 dark:text-{{ $prioColor }}-450 tracking-wider">
                                                {{ $ticket->priority }}
                                            </span>
                                        </td>
                                        <td class="px-4 py-3">
                                            @php
                                                $statColor = [
                                                    'open' => 'indigo',
                                                    'pending' => 'amber',
                                                    'resolved' => 'emerald',
                                                    'closed' => 'slate',
                                                ][$ticket->status] ?? 'slate';
                                            @endphp
                                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-{{ $statColor }}-500/10 text-{{ $statColor }}-600 dark:text-{{ $statColor }}-450 tracking-wider">
                                                {{ $ticket->status }}
                                            </span>
                                        </td>
                                        <td class="px-4 py-3 text-slate-450 dark:text-slate-500 font-semibold">{{ $ticket->updated_at->diffForHumans() }}</td>
                                        <td class="px-4 py-3 text-right">
                                            <a href="{{ route('admin.support.detail', $ticket->id) }}" class="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-250 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-lg transition">
                                                View Thread
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>

        @elseif ($activeTab === 'integrations')
            <!-- Website Selection Dropdown -->
            <div class="mb-6 flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50/50 dark:bg-slate-900/30 border border-slate-200/40 dark:border-slate-800/40 rounded-2xl">
                <div>
                    <h3 class="text-sm font-bold text-slate-800 dark:text-slate-200">Manage Integrations</h3>
                    <p class="text-xs text-slate-500">Select a specific website to manage its third-party connection credentials.</p>
                </div>
                <div class="w-full sm:w-64">
                    <select wire:model.live="selectedWebsiteId" class="w-full text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-750 dark:text-slate-300 py-2.5 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500">
                        @if($clientWebsites->isEmpty())
                            <option value="">No websites registered</option>
                        @else
                            @foreach($clientWebsites as $site)
                                <option value="{{ $site->id }}">{{ $site->site_name }} ({{ parse_url($site->url, PHP_URL_HOST) ?? $site->url }})</option>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>

            @if(!$selectedWebsiteId)
                <div class="border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center bg-slate-50/20 dark:bg-slate-950/10">
                    <svg class="w-12 h-12 text-slate-350 dark:text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" />
                    </svg>
                    <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm mb-1">No Website Selected</h4>
                    <p class="text-xs text-slate-450 dark:text-slate-550">Please register or select a website from the list above to configure its third-party app integrations.</p>
                </div>
            @else
                <div x-data="{ showAllIntegrations: false }">
                    <div class="mb-4 flex justify-end" x-show="!showAllIntegrations">
                        <button type="button" x-on:click="showAllIntegrations = true" class="flex items-center gap-2 py-2 px-4 rounded-xl font-bold text-xs bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"></path>
                            </svg>
                            Add New Integration
                        </button>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
                        @foreach ($clientIntegrations as $integration)
                            @php
                                $isNotConfigured = $integration['status'] === 'not_configured';
                            $isConfigured = $integration['status'] === 'credentials_configured';
                            $isConnected = $integration['status'] === 'connected';
                            $isDegraded = $integration['status'] === 'degraded';

                            $cardTheme = match($integration['id']) {
                                'ga4' => [
                                    'iconBg' => 'bg-orange-50 dark:bg-orange-950/20',
                                    'hoverBorder' => 'hover:border-orange-500/35 dark:hover:border-orange-500/25',
                                    'hoverShadow' => 'hover:shadow-orange-500/5',
                                    'svg' => '<svg class="w-5 h-5 text-orange-500 dark:text-orange-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>'
                                ],
                                'gsc' => [
                                    'iconBg' => 'bg-blue-50 dark:bg-blue-950/20',
                                    'hoverBorder' => 'hover:border-blue-500/35 dark:hover:border-blue-500/25',
                                    'hoverShadow' => 'hover:shadow-blue-500/5',
                                    'svg' => '<svg class="w-5 h-5 text-blue-500 dark:text-blue-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>'
                                ],
                                'gads' => [
                                    'iconBg' => 'bg-emerald-50 dark:bg-emerald-950/20',
                                    'hoverBorder' => 'hover:border-emerald-500/35 dark:hover:border-emerald-500/25',
                                    'hoverShadow' => 'hover:shadow-emerald-500/5',
                                    'svg' => '<svg class="w-5 h-5 text-emerald-600 dark:text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 6l-9.5 9.5-5-5L1 18"></path><polyline points="17 6 23 6 23 12"></polyline></svg>'
                                ],
                                'youtube' => [
                                    'iconBg' => 'bg-red-50 dark:bg-red-950/20',
                                    'hoverBorder' => 'hover:border-red-500/35 dark:hover:border-red-500/25',
                                    'hoverShadow' => 'hover:shadow-red-500/5',
                                    'svg' => '<svg class="w-5 h-5 text-red-600 dark:text-red-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.42a2.78 2.78 0 0 0-1.94 2C1 8.14 1 12 1 12s0 3.86.46 5.58a2.78 2.78 0 0 0 1.94 2C5.12 20 12 20 12 20s6.88 0 8.6-.42a2.78 2.78 0 0 0 1.94-2C23 15.86 23 12 23 12s0-3.86-.46-5.58z"></path><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"></polygon></svg>'
                                ],
                                'facebook' => [
                                    'iconBg' => 'bg-blue-50 dark:bg-blue-950/20',
                                    'hoverBorder' => 'hover:border-blue-600/35 dark:hover:border-blue-600/25',
                                    'hoverShadow' => 'hover:shadow-blue-600/5',
                                    'svg' => '<svg class="w-5 h-5 text-blue-600 dark:text-blue-500" viewBox="0 0 24 24" fill="currentColor"><path d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z"/></svg>'
                                ],
                                'linkedin' => [
                                    'iconBg' => 'bg-sky-50 dark:bg-sky-950/20',
                                    'hoverBorder' => 'hover:border-sky-600/35 dark:hover:border-sky-600/25',
                                    'hoverShadow' => 'hover:shadow-sky-600/5',
                                    'svg' => '<svg class="w-5 h-5 text-sky-600 dark:text-sky-500" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>'
                                ],
                                default => [
                                    'iconBg' => 'bg-slate-50 dark:bg-slate-800/40',
                                    'hoverBorder' => 'hover:border-indigo-500/35 dark:hover:border-indigo-500/25',
                                    'hoverShadow' => 'hover:shadow-indigo-500/5',
                                    'svg' => '<svg class="w-5 h-5 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="21" x2="9" y2="9"></line><line x1="3" y1="14" x2="21" y2="14"></line></svg>'
                                ]
                            };
                        @endphp
                        <div x-show="showAllIntegrations || !{{ json_encode($isNotConfigured) }}" x-transition.opacity.duration.300ms wire:key="integration-card-{{ $integration['id'] }}" class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-3xl p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:hover:shadow-none {{ $cardTheme['hoverBorder'] }} {{ $cardTheme['hoverShadow'] }} {{ $isNotConfigured ? 'opacity-70 bg-slate-50/20 dark:bg-slate-950/10' : '' }}" style="display: {{ $isNotConfigured ? 'none' : 'flex' }};">
                            <div>
                                <!-- Top Row: Logo, Name/Category, Status Badge -->
                                <div class="flex items-start justify-between mb-6">
                                    <div class="flex items-center gap-3">
                                        <!-- Circular icon container (Custom per integration) -->
                                        <div class="w-10 h-10 rounded-full {{ $cardTheme['iconBg'] }} flex items-center justify-center shrink-0">
                                            {!! $cardTheme['svg'] !!}
                                        </div>
                                        <div>
                                            <h4 class="text-[15px] font-bold text-slate-900 dark:text-white leading-tight">
                                                {{ $integration['name'] }}
                                            </h4>
                                            <div class="mt-1.5 flex flex-wrap items-center gap-2">
                                                <span class="text-xs text-slate-400 dark:text-slate-500">{{ $integration['category'] }}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Status Badge -->
                                    <div>
                                        @if ($isNotConfigured)
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-450 dark:bg-slate-800 dark:text-slate-500">
                                                Not Configured
                                            </span>
                                        @elseif ($isConfigured)
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-500/10 text-indigo-650 dark:text-indigo-400">
                                                Keys Configured
                                            </span>
                                        @elseif ($isDegraded)
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/10 text-amber-600 dark:text-amber-400">
                                                Degraded
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/10 text-emerald-600 dark:text-emerald-450">
                                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse"></span>
                                                Connected
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <!-- Middle: Stats columns (Modern card sub-containers) -->
                                <div class="grid grid-cols-2 gap-4 mb-6">
                                    <div class="bg-slate-50/50 dark:bg-slate-900/30 border border-slate-100/50 dark:border-slate-850/50 p-3.5 rounded-2xl transition hover:bg-slate-100/30 dark:hover:bg-slate-850/20">
                                        <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">API health</span>
                                        <span class="text-base font-extrabold text-slate-800 dark:text-slate-200">
                                            {{ $isConnected ? $integration['api_health'] . '%' : '—' }}
                                        </span>
                                    </div>
                                    <div class="bg-slate-50/50 dark:bg-slate-900/30 border border-slate-100/50 dark:border-slate-850/50 p-3.5 rounded-2xl transition hover:bg-slate-100/30 dark:hover:bg-slate-850/20">
                                        <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Last sync</span>
                                        <span class="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate block mt-0.5" title="{{ $integration['last_sync'] }}">
                                            {{ $integration['last_sync'] }}
                                        </span>
                                    </div>
                                </div>
                            @if ($integration['id'] === 'ga4' && $isConnected)
                                @if (!$integration['property_id'])
                                    <div class="mt-4 p-3 bg-indigo-50/30 dark:bg-indigo-950/10 rounded-xl border border-indigo-100/30 dark:border-indigo-900/20 mb-4">
                                        <span class="text-[10px] font-bold text-indigo-650 dark:text-indigo-400 block mb-1.5 uppercase tracking-wider">Select GA4 Property</span>
                                        <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                            <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="property-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm">
                                                <option value="">Select Property...</option>
                                                @foreach ($this->getGA4Properties() as $prop)
                                                    <option value="{{ $prop['id'] }}">{{ $prop['name'] }}</option>
                                                @endforeach
                                            </select>
                                            <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGA4Property" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                <span>Save</span>
                                            </button>
                                        </div>
                                    </div>
                                @else
                                    <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                        <span class="text-slate-455 dark:text-slate-550 font-medium">GA4 Property ID</span>
                                        <span class="font-bold text-slate-755 dark:text-slate-300">{{ $integration['property_id'] }}</span>
                                    </div>
                                @endif
                            @endif

                            @if ($integration['id'] === 'gsc' && $isConnected)
                                @if (!$integration['property_id'])
                                    <div class="mt-4 p-3 bg-teal-50/30 dark:bg-teal-950/10 rounded-xl border border-teal-100/30 dark:border-teal-900/20 mb-4">
                                        <span class="text-[10px] font-bold text-teal-650 dark:text-teal-400 block mb-1.5 uppercase tracking-wider">Select GSC Site</span>
                                        <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                            <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="gsc-site-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-teal-500 shadow-sm">
                                                <option value="">Select Site...</option>
                                                @foreach ($this->getGSCSites() as $site)
                                                    <option value="{{ $site['id'] }}">{{ $site['name'] }}</option>
                                                @endforeach
                                            </select>
                                            <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGSCSite('gsc')" wire:key="save-btn-gsc" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                <span>Save</span>
                                            </button>
                                        </div>
                                    </div>
                                @else
                                    <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                        <span class="text-slate-455 dark:text-slate-550 font-medium">GSC Site</span>
                                        <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                    </div>
                                @endif
                            @endif

                            @if ($integration['id'] === 'youtube' && $isConnected)
                                @if (!$integration['property_id'])
                                    <div class="mt-4 p-3 bg-red-50/30 dark:bg-red-950/10 rounded-xl border border-red-100/30 dark:border-red-900/20 mb-4">
                                        <span class="text-[10px] font-bold text-red-650 dark:text-red-400 block mb-1.5 uppercase tracking-wider">Select YouTube Channel</span>
                                        <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                            <select wire:model="youtubeChannelId" x-on:change="hasVal = $event.target.value !== ''" wire:key="youtube-channel-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-red-500 shadow-sm">
                                                <option value="">Select Channel...</option>
                                                @foreach ($this->getYoutubeChannels() as $channel)
                                                    <option value="{{ $channel['id'] }}">{{ $channel['name'] }}</option>
                                                @endforeach
                                            </select>
                                            <button type="button" x-show="hasVal" style="display: none;" wire:click="saveYoutubeChannel" wire:key="save-btn-youtube" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                <span>Save</span>
                                            </button>
                                        </div>
                                    </div>
                                @else
                                    <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                        <span class="text-slate-455 dark:text-slate-550 font-medium">YouTube Channel</span>
                                        <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                    </div>
                                @endif
                            @endif

                            @if ($integration['id'] === 'keyword' && $isConnected)
                                @if (!$integration['property_id'])
                                    <div class="mt-4 p-3 bg-purple-50/30 dark:bg-purple-950/10 rounded-xl border border-purple-100/30 dark:border-purple-900/20 mb-4">
                                        <span class="text-[10px] font-bold text-purple-650 dark:text-purple-400 block mb-1.5 uppercase tracking-wider">Select Keyword Project</span>
                                        <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                            <select wire:model="keywordProjectId" x-on:change="hasVal = $event.target.value !== ''" wire:key="keyword-project-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-purple-500 shadow-sm">
                                                <option value="">Select Project...</option>
                                                @foreach ($this->getKeywordProjects() as $project)
                                                    <option value="{{ $project['id'] }}">{{ $project['name'] }}</option>
                                                @endforeach
                                            </select>
                                            <button type="button" x-show="hasVal" style="display: none;" wire:click="saveKeywordProject" wire:key="save-btn-keyword" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                <span>Save</span>
                                            </button>
                                        </div>
                                    </div>
                                @else
                                    <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                        <span class="text-slate-455 dark:text-slate-550 font-medium">Keyword Project ID</span>
                                        <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                    </div>
                                @endif
                            @endif
                            
                                @if ($integration['id'] === 'gtm' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-teal-50/30 dark:bg-teal-950/10 rounded-xl border border-teal-100/30 dark:border-teal-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-teal-650 dark:text-teal-400 block mb-1.5 uppercase tracking-wider">Select GTM Container</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="gtmContainerId" x-on:change="hasVal = $event.target.value !== ''" wire:key="gtm-container-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-teal-500 shadow-sm">
                                                    <option value="">Select Container...</option>
                                                    @foreach ($this->getGtmContainers() as $container)
                                                        <option value="{{ $container['id'] }}">{{ $container['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGtmContainer" wire:key="save-btn-gtm" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">GTM Container ID</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif

                                @if ($integration['id'] === 'gbp' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-blue-50/30 dark:bg-blue-950/10 rounded-xl border border-blue-100/30 dark:border-blue-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-blue-650 dark:text-blue-400 block mb-1.5 uppercase tracking-wider">GBP Location ID</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="gbp-location-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 shadow-sm">
                                                    <option value="">Select Location...</option>
                                                    @foreach ($this->getGBPLocations() as $location)
                                                        <option value="{{ $location['id'] }}">{{ $location['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="savePropertyId('gbp')" wire:key="save-btn-gbp" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">GBP Location ID</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif
                                
                                @if ($integration['id'] === 'gads' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-emerald-50/30 dark:bg-emerald-950/10 rounded-xl border border-emerald-100/30 dark:border-emerald-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-emerald-650 dark:text-emerald-400 block mb-1.5 uppercase tracking-wider">Select Google Ads Account</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <input type="text" wire:model.defer="googleAdsAccountId" x-on:input="hasVal = $event.target.value.length >= 10" placeholder="e.g. 123-456-7890" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-sm">
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGoogleAdsAccount" wire:key="save-btn-gads" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">Google Ads Account ID</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif
                                </div>

                            <!-- Footer Actions -->
                            <div class="flex items-center gap-3 mt-auto">
                                @if ($isNotConfigured)
                                    <!-- Configure credentials first -->
                                    <button type="button" 
                                            wire:click="openConfigModal('{{ $integration['id'] }}')"
                                            class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition active:scale-95">
                                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                                        </svg>
                                        Configure Credentials
                                    </button>
                                @elseif ($isConfigured)
                                    <!-- Auth stage -->
                                    <a href="{{ route('admin.integrations.google.redirect', $integration['db_id']) }}"
                                       class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-indigo-600 hover:bg-indigo-750 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95 text-center flex items-center justify-center">
                                        <svg class="w-4 h-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                                        </svg>
                                        Sign in with Google
                                    </a>
                                    <button type="button" 
                                            wire:click="removeCredentials('{{ $integration['id'] }}')"
                                            wire:confirm="Are you sure you want to remove the credentials for this integration?"
                                            class="px-3 py-2.5 bg-slate-100 hover:bg-red-50 dark:bg-slate-800 dark:hover:bg-red-955/20 text-slate-500 hover:text-red-650 dark:text-slate-400 dark:hover:text-red-400 font-bold text-xs rounded-xl transition active:scale-95"
                                            title="Remove Credentials">
                                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                @else
                                    <!-- Connected stage -->
                                    <div class="w-full flex flex-col gap-2.5 mt-auto">
                                        @if (in_array($integration['id'], ['ga4', 'gsc', 'youtube', 'keyword', 'gtm', 'gbp', 'gads', 'facebook', 'linkedin']) && !empty($integration['property_id']))
                                            <a href="{{ route('admin.clients.report', ['id' => $selectedClientDetailId, 'integration' => $integration['id'], 'website' => $selectedWebsiteId]) }}"
                                                    class="w-full py-2.5 px-3 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 text-indigo-650 dark:text-indigo-400 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 active:scale-95">
                                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M21.21 15.89A10 10 0 1 1 8 2.83M22 12A10 10 0 0 0 12 2v10z"/>
                                                </svg>
                                                View Full Report
                                            </a>
                                        @endif
                                        <div class="flex items-center gap-3">
                                            <button type="button" 
                                                    wire:click="refreshIntegration('{{ $integration['id'] }}')"
                                                    wire:loading.attr="disabled"
                                                    wire:target="refreshIntegration('{{ $integration['id'] }}')"
                                                    class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-white dark:bg-slate-850 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-slate-700 dark:text-slate-350 font-bold text-xs rounded-xl transition shadow-sm active:scale-95">
                                                <svg wire:loading.class="animate-spin" wire:target="refreshIntegration('{{ $integration['id'] }}')" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                                </svg>
                                                Refresh
                                            </button>
                                            <button type="button" 
                                                    wire:click="disconnectIntegration('{{ $integration['id'] }}')"
                                                    wire:loading.attr="disabled"
                                                    wire:confirm="Are you sure you want to disconnect {{ $integration['name'] }}?"
                                                    class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-white dark:bg-slate-850 hover:bg-red-50 dark:hover:bg-red-955/20 border border-slate-200/80 dark:border-slate-700/80 hover:border-red-200 dark:hover:border-red-900/40 text-slate-750 hover:text-red-650 dark:text-slate-300 dark:hover:text-red-400 font-bold text-xs rounded-xl transition shadow-sm active:scale-95">
                                                <svg class="w-4 h-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" stroke-linecap="round"/>
                                                    <path d="M18.364 5.636L5.636 18.364" stroke="red" stroke-width="2" stroke-linecap="round"/>
                                                </svg>
                                                Disconnect
                                            </button>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
                </div>
            @endif

            <!-- Credentials Upload Modal -->
            @if ($showConfigModal)
                <div class="fixed inset-0 z-50 flex items-center justify-center overflow-x-hidden overflow-y-auto outline-none focus:outline-none bg-slate-905/60 backdrop-blur-sm animate-fadeIn">
                    <div class="relative w-full max-w-lg mx-auto my-6 p-4">
                        <div class="relative flex flex-col w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl outline-none focus:outline-none">
                            <!-- Modal Header -->
                            <div class="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800/60 rounded-t-3xl">
                                <h3 class="text-base font-bold text-slate-900 dark:text-white">
                                    @if($activeConfigIntegrationId === 'ga4')
                                        Configure Google Analytics 4
                                    @elseif($activeConfigIntegrationId === 'gsc')
                                        Configure Google Search Console
                                    @else
                                        Configure {{ strtoupper($activeConfigIntegrationId) }}
                                    @endif
                                </h3>
                                <button type="button" wire:click="closeConfigModal" class="text-slate-400 hover:text-slate-650 dark:hover:text-slate-200 focus:outline-none transition">
                                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                            
                            <!-- Modal Body -->
                            <form wire:submit.prevent="saveCredentials">
                                <div class="p-6 flex-auto">
                                    @if($activeConfigIntegrationId === 'keyword')
                                        <div class="mb-5">
                                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Keyword.com API Token</label>
                                            <input type="text" wire:model="apiKey" placeholder="Enter your Keyword.com API Token" class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                            @error('apiKey') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                        </div>
                                        <div class="text-[11px] text-slate-450 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                            Note: Your API key will be securely stored and used only to fetch your keyword ranking data.
                                        </div>
                                    @elseif($activeConfigIntegrationId === 'facebook')
                                        <div class="space-y-4">
                                            <div>
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">System User Access Token</label>
                                                <input type="text" wire:model="facebookAccessToken" placeholder="EAAG..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('facebookAccessToken') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                            <div>
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">Page ID</label>
                                                <input type="text" wire:model="facebookPageId" placeholder="10493..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('facebookPageId') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                            <div>
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">Ad Account ID</label>
                                                <input type="text" wire:model="facebookAdAccountId" placeholder="act_..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('facebookAdAccountId') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                        </div>
                                        <div class="mt-4 text-[11px] text-slate-450 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                            Note: You need to create a System User in Facebook Business Manager and generate an access token with ads_read and pages_read_engagement permissions.
                                        </div>
                                    @elseif($activeConfigIntegrationId === 'linkedin')
                                        <div class="space-y-4">
                                            <div>
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">LinkedIn Access Token</label>
                                                <input type="text" wire:model="linkedinAccessToken" placeholder="AQW..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('linkedinAccessToken') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                            <div>
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">Organization ID (URN)</label>
                                                <input type="text" wire:model="linkedinOrganizationId" placeholder="e.g. 12345678" class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('linkedinOrganizationId') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                        </div>
                                        <div class="mt-4 text-[11px] text-slate-450 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                            Note: Generate a LinkedIn Developer Token with Organization stats permissions.
                                        </div>
                                    @else
                                        <div class="mb-5">
                                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Google OAuth Credentials (.json)</label>
                                            <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-200 dark:border-slate-800 border-dashed rounded-2xl hover:border-indigo-500/50 dark:hover:border-indigo-400/50 transition-colors relative">
                                                <div class="space-y-1 text-center">
                                                    <svg class="mx-auto h-12 w-12 text-slate-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                    <div class="flex text-xs text-slate-600 dark:text-slate-400 justify-center">
                                                        <label for="credentials-upload" class="relative cursor-pointer bg-white dark:bg-slate-900 rounded-md font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 focus-within:outline-none">
                                                            <span>Upload a file</span>
                                                            <input id="credentials-upload" name="credentials-upload" type="file" wire:model="credentialsFile" class="sr-only">
                                                        </label>
                                                        <p class="pl-1">or drag and drop</p>
                                                    </div>
                                                    <p class="text-[10px] text-slate-400">JSON keys only up to 2MB</p>
                                                </div>
                                            </div>
                                            @if($credentialsFile)
                                                <div class="mt-3 flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-950/20 border border-slate-200/50 dark:border-slate-800/50 rounded-xl">
                                                    <span class="text-xs text-slate-600 dark:text-slate-400 truncate max-w-[200px]" title="{{ $credentialsFile->getClientOriginalName() }}">
                                                        {{ $credentialsFile->getClientOriginalName() }}
                                                    </span>
                                                    <button type="button" wire:click="$set('credentialsFile', null)" class="text-red-500 text-xs font-bold hover:underline">Remove</button>
                                                </div>
                                            @endif
                                            @error('credentialsFile') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                        </div>
                                        @if($activeConfigIntegrationId === 'gads')
                                            <div class="mb-5">
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Google Ads Developer Token</label>
                                                <input type="text" wire:model="googleAdsDeveloperToken" placeholder="Enter Developer Token" class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('googleAdsDeveloperToken') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                        @endif

                                        <div class="text-[11px] text-slate-450 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                            Note: We securely encrypt and store your credentials file. Your OAuth Client details are isolated and only used for your integration.
                                        </div>
                                    @endif
                                </div>
                                
                                <!-- Modal Footer -->
                                <div class="flex items-center justify-end p-4 border-t border-slate-100 dark:border-slate-800/60 rounded-b-3xl gap-2">
                                    <button type="button" wire:click="closeConfigModal" class="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-330 font-bold text-xs rounded-xl transition hover:bg-slate-200">
                                        Cancel
                                    </button>
                                    <button type="submit" wire:loading.attr="disabled" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-755 text-white font-bold text-xs rounded-xl transition shadow-sm active:scale-95">
                                        <span wire:loading.remove>Save & Configure</span>
                                        <span wire:loading>Processing...</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            @endif

            <!-- View Report Modal -->
            @if ($showReportModal)
                <div x-data x-show="$wire.showReportModal" class="fixed inset-0 z-50 flex items-center justify-center overflow-x-hidden overflow-y-auto outline-none focus:outline-none bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
                    <div class="relative w-full max-w-4xl mx-auto my-6 p-4">
                        <div class="relative flex flex-col w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl outline-none focus:outline-none max-h-[90vh] overflow-y-auto">
                            <!-- Modal Header -->
                            <div class="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800/60 rounded-t-3xl sticky top-0 bg-white dark:bg-slate-900 z-10">
                                <div>
                                    <h3 class="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <svg class="w-5 h-5 text-indigo-650 dark:text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                                        </svg>
                                        @if($activeReportIntegrationId === 'gsc')
                                            Google Search Console - Detailed Report
                                        @elseif($activeReportIntegrationId === 'youtube')
                                            YouTube - Detailed Report
                                        @elseif($activeReportIntegrationId === 'keyword')
                                            Keyword.com - Detailed Report
                                        @elseif($activeReportIntegrationId === 'gtm')
                                            Google Tag Manager - Container Summary
                                        @elseif($activeReportIntegrationId === 'gbp')
                                            Google Business Profile - Detailed Report
                                        @else
                                            Google Analytics 4 - Detailed Report
                                        @endif
                                    </h3>
                                    <p class="text-[11px] text-slate-400 mt-1">
                                        Property ID: <span class="font-semibold text-slate-655 dark:text-slate-350">{{ !empty($activeReportPropertyId) ? $activeReportPropertyId : ($activeReportData['metadata']['property_id'] ?? '—') }}</span> &bull; Source: <span class="text-slate-655 dark:text-slate-350">{{ $activeReportIntegrationId ? strtoupper($activeReportIntegrationId) : ($activeReportData['metadata']['source'] ?? '—') }}</span>
                                    </p>
                                </div>
                                <div class="flex items-center gap-3">
                                     @include('partials.marketing-report-send-modal')
                                     <!-- GA4 Style Date Range Picker Popover -->
                                     @php
                                         $minDateBound = \Carbon\Carbon::now()->subDays(90)->format('Y-m-d');
                                         $maxDateBound = \Carbon\Carbon::now()->format('Y-m-d');
                                     @endphp
                                     @include('partials.ga4-date-picker', ['minDateBound' => $minDateBound, 'maxDateBound' => $maxDateBound])
                                    <button type="button" x-on:click="$wire.showReportModal = false;" class="text-slate-400 hover:text-slate-650 dark:hover:text-slate-250 focus:outline-none transition p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Modal Body -->
                            <div class="p-6">
                                @if (empty($activeReportData))
                                    <div class="py-12 text-center">
                                        <div wire:loading class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                                        <div wire:loading.remove>
                                            <svg class="w-12 h-12 text-slate-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path></svg>
                                            <p class="text-sm font-bold text-slate-600 dark:text-slate-400">No data available</p>
                                            <p class="text-xs text-slate-400 mt-1">Try selecting a different date range or sync your integration.</p>
                                        </div>
                                    </div>
                                @else
                                    @if ($activeReportIntegrationId === 'gsc')
                                        <!-- 1. Stats Summary Widgets (GSC) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Clicks</span>
                                                <span class="text-lg font-extrabold text-indigo-600 dark:text-indigo-400">
                                                    {{ $this->formatAbbreviated($activeReportData['summary']['clicks'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Impressions</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ $this->formatAbbreviated($activeReportData['summary']['impressions'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg. CTR</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ $activeReportData['summary']['ctr'] ?? 0 }}%
                                                </span>
                                            </div>
                                            <div class="p-4 bg-amber-50/20 dark:bg-amber-950/10 border border-amber-100/30 dark:border-amber-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg. Position</span>
                                                <span class="text-lg font-extrabold text-amber-600 dark:text-amber-400">
                                                    {{ $activeReportData['summary']['position'] ?? 0 }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. Top Queries Table (GSC) -->
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Search Queries</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">Query</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach ($activeReportData['top_queries'] ?? [] as $query)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-bold truncate max-w-[150px]" title="{{ $query['query'] }}">{{ $query['query'] }}</td>
                                                                    <td class="py-2.5 text-right font-bold">{{ number_format($query['clicks'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($query['impressions'] ?? 0) }}</td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Ranking URLs</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">URL</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach ($activeReportData['top_pages'] ?? [] as $page)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-bold truncate max-w-[150px] text-indigo-600" title="{{ $page['page'] }}">
                                                                        <a href="{{ $page['page'] }}" target="_blank" class="hover:underline">{{ str_replace('https://', '', $page['page']) }}</a>
                                                                    </td>
                                                                    <td class="py-2.5 text-right font-bold">{{ number_format($page['clicks'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($page['impressions'] ?? 0) }}</td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- 3. Devices and Countries -->
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Device Breakdown</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">Device</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach ($activeReportData['devices'] ?? [] as $device)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-bold capitalize">{{ strtolower($device['device']) }}</td>
                                                                    <td class="py-2.5 text-right font-bold">{{ number_format($device['clicks'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($device['impressions'] ?? 0) }}</td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Countries</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">Country</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach ($activeReportData['countries'] ?? [] as $country)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-bold capitalize">{{ strtolower(strlen($country['country']) === 3 ? $country['country'] : $country['country']) }}</td>
                                                                    <td class="py-2.5 text-right font-bold">{{ number_format($country['clicks'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($country['impressions'] ?? 0) }}</td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif ($activeReportIntegrationId === 'linkedin')
                                        <!-- LinkedIn Report Section -->
                                        @php
                                        $reportSets = [];
                                        $baseData = $activeReportData ?? [];
                                        if (!empty($baseData)) {
                                            $reportSets[] = ['title' => (!empty($this->dateFrom) && !empty($this->dateTo)) ? \Carbon\Carbon::parse($this->dateFrom)->format('M d, Y') . ' - ' . \Carbon\Carbon::parse($this->dateTo)->format('M d, Y') : 'Current Period', 'data' => $baseData];
                                        }
                                        if (!empty($baseData['compare_data'])) {
                                            $reportSets[] = ['title' => (!empty($this->compareDateFrom) && !empty($this->compareDateTo)) ? \Carbon\Carbon::parse($this->compareDateFrom)->format('M d, Y') . ' - ' . \Carbon\Carbon::parse($this->compareDateTo)->format('M d, Y') : 'Previous Period', 'data' => $baseData['compare_data']];
                                        }
                                        @endphp
                                        
                                        @if(count($reportSets) > 1)
                                        <div wire:key="li-wrapper-1-multi" class="flex flex-col lg:flex-row gap-6 mb-6">
                                        @else
                                        <div wire:key="li-wrapper-1-single" class="flex flex-col gap-6 mb-6">
                                        @endif
                                        @foreach($reportSets as $idx => $rSet)
                                        <div wire:key="li-section-1-{{ $idx }}" class="flex-1 w-full overflow-hidden">
                                            @php $reportDataScope = $rSet['data']; @endphp
                                            @if(count($reportSets) > 1)
                                                <div class="col-span-full mb-3 mt-4">
                                                    <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                        {{ $rSet['title'] }}
                                                    </span>
                                                </div>
                                            @endif
                                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                                <div class="p-4 bg-sky-50/20 dark:bg-sky-950/10 border border-sky-100/30 dark:border-sky-900/20 rounded-2xl">
                                                    <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Followers</span>
                                                    <span class="text-lg font-extrabold text-sky-600 dark:text-sky-400">
                                                        {{ number_format($reportDataScope['summary']['followers'] ?? 0) }}
                                                    </span>
                                                </div>
                                                <div class="p-4 bg-slate-50/50 dark:bg-slate-900/30 border border-slate-200/50 dark:border-slate-800/50 rounded-2xl">
                                                    <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Impressions</span>
                                                    <span class="text-lg font-extrabold text-slate-700 dark:text-slate-200">
                                                        {{ number_format($reportDataScope['summary']['impressions'] ?? 0) }}
                                                    </span>
                                                </div>
                                                <div class="p-4 bg-slate-50/50 dark:bg-slate-900/30 border border-slate-200/50 dark:border-slate-800/50 rounded-2xl">
                                                    <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Clicks</span>
                                                    <span class="text-lg font-extrabold text-slate-700 dark:text-slate-200">
                                                        {{ number_format($reportDataScope['summary']['clicks'] ?? 0) }}
                                                    </span>
                                                </div>
                                                <div class="p-4 bg-emerald-50/30 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                    <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Engagement</span>
                                                    <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-400">
                                                        {{ number_format($reportDataScope['summary']['engagements'] ?? 0) }}
                                                    </span>
                                                </div>
                                            </div>

                                            <!-- LI Graph Area -->
                                            <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/50 p-5 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 mb-6">
                                                <div class="flex items-center justify-between mb-4">
                                                    <div class="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">
                                                        <div class="w-1.5 h-1.5 rounded-full bg-sky-500"></div> Impressions & Engagements
                                                    </div>
                                                </div>
                                                <div class="w-full">
                                                    <div class="h-64" wire:key="li-chart-{{ $idx }}-{{ md5(json_encode($activeReportData)) }}" x-data="{
                                                        init() {
                                                            const ctx = document.getElementById('li-chart-{{ $idx }}').getContext('2d');
                                                            let rawData = {{ json_encode($idx === 0 ? $activeReportData : ($activeReportData['compare_data'] ?? null)) }};
                                                            let dt = (rawData && rawData.daily_traffic) ? rawData.daily_traffic : [];
                                                            
                                                            let labels = dt.map(d => {
                                                                let dateStr = d.date;
                                                                return dateStr.length === 8 && !dateStr.includes('-') 
                                                                    ? dateStr.substring(4,6)+'/'+dateStr.substring(6,8) 
                                                                    : dateStr.split('-').slice(1).join('/');
                                                            });
                                                            let impressions = dt.map(d => d.impressions || 0);
                                                            let engagements = dt.map(d => d.engagements || 0);

                                                            new Chart(ctx, {
                                                                type: 'line',
                                                                data: {
                                                                    labels: labels,
                                                                    datasets: [
                                                                        {
                                                                            label: 'Impressions',
                                                                            data: impressions,
                                                                            borderColor: '#0284c7',
                                                                            backgroundColor: 'rgba(2, 132, 199, 0.1)',
                                                                            borderWidth: 2,
                                                                            fill: true,
                                                                            tension: 0.4,
                                                                            pointRadius: 0,
                                                                            pointHoverRadius: 4,
                                                                            yAxisID: 'y'
                                                                        },
                                                                        {
                                                                            label: 'Engagements',
                                                                            data: engagements,
                                                                            borderColor: '#10b981',
                                                                            backgroundColor: 'transparent',
                                                                            borderWidth: 2,
                                                                            borderDash: [5, 5],
                                                                            tension: 0.4,
                                                                            pointRadius: 0,
                                                                            pointHoverRadius: 4,
                                                                            yAxisID: 'y1'
                                                                        }
                                                                    ]
                                                                },
                                                                options: {
                                                                    responsive: true, maintainAspectRatio: false,
                                                                    interaction: { mode: 'index', intersect: false },
                                                                    plugins: { legend: { display: true, position: 'top', align: 'end', labels: { boxWidth: 10, usePointStyle: true } } },
                                                                    scales: {
                                                                        y: { type: 'linear', display: true, position: 'left', beginAtZero: true, grid: { color: document.documentElement.classList.contains('dark') ? '#1e293b' : '#f1f5f9' }, border: { dash: [4, 4] } },
                                                                        y1: { type: 'linear', display: true, position: 'right', beginAtZero: true, grid: { display: false } },
                                                                        x: { grid: { display: false } }
                                                                    }
                                                                }
                                                            });
                                                        }
                                                    }"><canvas id="li-chart-{{ $idx }}"></canvas></div>
                                                </div>
                                            </div>

                                            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                                <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/50 p-5 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300">
                                                    <div class="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-4">
                                                        <div class="w-1.5 h-1.5 rounded-full bg-indigo-500"></div> Top Followers By Job Title
                                                    </div>
                                                    <div class="overflow-x-auto">
                                                        <table class="w-full text-sm text-left">
                                                            <thead>
                                                                <tr class="text-[10px] uppercase tracking-wider text-slate-400 dark:text-slate-500 border-b-2 border-slate-100 dark:border-slate-800/50">
                                                                    <th class="py-2 font-bold">Job Title</th>
                                                                    <th class="py-2 text-right font-bold">Count</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                @foreach (array_slice($reportDataScope['followers_by_job'] ?? [], 0, 5) as $job)
                                                                    <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                        <td class="py-2.5 font-bold truncate max-w-[200px]" title="{{ $job['name'] ?? '' }}">{{ $job['name'] ?? '' }}</td>
                                                                        <td class="py-2.5 text-right font-bold text-sky-600 dark:text-sky-400">{{ number_format($job['count'] ?? 0) }}</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                
                                                <div class="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/50 p-5 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300">
                                                    <div class="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-4">
                                                        <div class="w-1.5 h-1.5 rounded-full bg-sky-500"></div> Follower Demographics
                                                    </div>
                                                    <div class="flex flex-col items-center">
                                                        @php
                                                            $demoItems = [];
                                                            foreach (array_slice($reportDataScope['demographics'] ?? [], 0, 5) as $item) {
                                                                $demoItems[] = [
                                                                    'label' => $item['region'] ?? 'Unknown',
                                                                    'value' => (float) str_replace('%', '', $item['percentage'] ?? '0')
                                                                ];
                                                            }
                                                        @endphp
                                                        <div class="relative w-40 h-40 mb-6">
                                                            <canvas id="li-demo-chart-{{ $idx }}" x-data="{
                                                                init() {
                                                                    const ctx = this.$el.getContext('2d');
                                                                    let items = {{ json_encode($demoItems) }};
                                                                    if (items.length > 0) {
                                                                        let labels = items.map(e => e.label);
                                                                        let data = items.map(e => e.value);
                                                                        let colors = ['#38bdf8','#818cf8','#34d399','#fbbf24','#a78bfa'];
                                                                        new Chart(ctx, {
                                                                            type: 'doughnut',
                                                                            data: {
                                                                                labels: labels,
                                                                                datasets: [{ data: data, backgroundColor: colors, borderWidth: 0 }]
                                                                            },
                                                                            options: { responsive: true, maintainAspectRatio: false, cutout: '70%', plugins: { legend: { display: false } } }
                                                                        });
                                                                    }
                                                                }
                                                            }"></canvas>
                                                        </div>
                                                        <div class="flex flex-col gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 w-full pr-4">
                                                            @php $colors = ['bg-sky-400', 'bg-indigo-400', 'bg-emerald-400', 'bg-yellow-400', 'bg-purple-400']; @endphp
                                                            @foreach($demoItems as $index => $item)
                                                                <div class="flex items-center justify-between w-full">
                                                                    <div class="flex items-center gap-2">
                                                                        <div class="w-2 h-2 {{ $colors[$index % count($colors)] }} rounded-full"></div>
                                                                        <span>{{ $item['label'] }}</span>
                                                                    </div>
                                                                    <span class="font-bold text-slate-700 dark:text-slate-300">{{ $item['value'] }}%</span>
                                                                </div>
@endforeach
</div>
</div>
</div>
                                            </div>
                                        </div>
                                        @endforeach
                                        </div>
                                    @elseif ($activeReportIntegrationId === 'gbp')
                                        <!-- GBP Report Section -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Views</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ number_format($activeReportData['summary']['views'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-slate-50/50 dark:bg-slate-900/30 border border-slate-200/50 dark:border-slate-800/50 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Searches</span>
                                                <span class="text-lg font-extrabold text-slate-700 dark:text-slate-200">
                                                    {{ number_format($activeReportData['summary']['searches'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-slate-50/50 dark:bg-slate-900/30 border border-slate-200/50 dark:border-slate-800/50 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Interactions</span>
                                                <span class="text-lg font-extrabold text-slate-700 dark:text-slate-200">
                                                    {{ number_format($activeReportData['summary']['interactions'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/30 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Calls</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-400">
                                                    {{ number_format($activeReportData['summary']['calls'] ?? 0) }}
                                                </span>
                                            </div>
                                        </div>

                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mb-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Google Business Profile Data Dump</h4>
                                            <div class="overflow-x-auto">
                                                <pre class="text-[10px] text-slate-600 dark:text-slate-400 whitespace-pre-wrap">{{ json_encode($activeReportData, JSON_PRETTY_PRINT) }}</pre>
                                            </div>
                                        </div>
                                    @elseif ($activeReportIntegrationId === 'ga4')
@php
                                        
                                        $reportSets = [];
                                        $baseData = $activeReportData ?? [];
                                        
                                        $primaryTitle = (isset($dateFrom) && isset($dateTo)) 
                                            ? \Carbon\Carbon::parse($dateFrom)->format('M d, Y') . ' - ' . \Carbon\Carbon::parse($dateTo)->format('M d, Y') 
                                            : 'Primary Date Range';
                                            
                                        $reportSets[] = [
                                            'title' => $primaryTitle,
                                            'data' => $baseData,
                                        ];
                                        
                                        $hasCompare = !empty($baseData['compare_data']);
                                        
                                        if ($hasCompare) {
                                            $compareTitle = (isset($compareDateFrom) && isset($compareDateTo) && $compareDateFrom && $compareDateTo) 
                                                ? \Carbon\Carbon::parse($compareDateFrom)->format('M d, Y') . ' - ' . \Carbon\Carbon::parse($compareDateTo)->format('M d, Y') 
                                                : 'Compare Date Range';
                                                
                                            $reportSets[] = [
                                                'title' => $compareTitle,
                                                'data' => $baseData['compare_data']
                                            ];
                                        }
                                        
                                        $calculateDelta = function($val1, $val2, $format) {
                                            $v1 = (float)$val1;
                                            $v2 = (float)$val2;
                                            if ($v2 == 0) return ['value' => $v1 > 0 ? '100%' : '0%', 'trend' => $v1 > 0 ? 'up' : 'flat'];
                                            
                                            $diff = $v1 - $v2;
                                            if ($diff == 0) return ['value' => $format === 'absolute' ? '0' : '0%', 'trend' => 'flat'];
                                            
                                            $trend = $diff > 0 ? 'up' : 'down';
                                            if ($format === 'absolute') {
                                                return ['value' => number_format(abs($diff)), 'trend' => $trend];
                                            } else {
                                                $pct = round((abs($diff) / $v2) * 100, 1);
                                                return ['value' => $pct . '%', 'trend' => $trend];
                                            }
                                        };
                                        
                                        $format = $compareFormat ?? 'percentage';
                                    @endphp

<!-- 1. Stats Summary Widgets -->
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-1-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                                        <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Active Users</span>
                                            <span class="text-lg font-extrabold text-indigo-600 dark:text-indigo-400">
                                                {{ $this->formatAbbreviated($reportDataScope['overall_summary']['active_users'] ?? 0) }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Page Views</span>
                                            <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                {{ $this->formatAbbreviated($reportDataScope['overall_summary']['pageviews'] ?? 0) }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Sessions</span>
                                            <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                {{ $this->formatAbbreviated($reportDataScope['overall_summary']['sessions'] ?? 0) }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-amber-50/20 dark:bg-amber-950/10 border border-amber-100/30 dark:border-amber-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Bounce Rate</span>
                                            <span class="text-lg font-extrabold text-amber-600 dark:text-amber-400">
                                                {{ $reportDataScope['overall_summary']['bounce_rate'] ?? '—' }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-rose-50/20 dark:bg-rose-950/10 border border-rose-100/30 dark:border-rose-900/20 rounded-2xl col-span-2 md:col-span-1">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg Session Duration</span>
                                            <span class="text-lg font-extrabold text-rose-600 dark:text-rose-400">
                                                {{ $reportDataScope['overall_summary']['avg_session_duration'] ?? '—' }}
                                            </span>
                                        </div>
                                    </div>
</div>
                                    @endforeach

<!-- 1. GA4 Charts Grid (Traffic by Channel & Visitors by Channel) -->
@if(count($reportSets) == 1)
<div wire:key="wrapper-19-single" class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
@else
<div wire:key="wrapper-19-multi" class="grid grid-cols-1 gap-6 mb-6">
@endif

    <!-- Left: Traffic by Channel / Events Distribution -->
    <div>
        @if(count($reportSets) > 1)
        <div wire:key="wrapper-8-multi" class="flex flex-col lg:flex-row gap-6">
        @else
        <div wire:key="wrapper-8-single" class="flex flex-col gap-6">
        @endif
        @foreach($reportSets as $idx => $rSet)
        <div wire:key="ga4-section-2-{{ $idx }}" class="flex-1 w-full overflow-hidden">
            @php $reportDataScope = $rSet['data']; @endphp
            @if(count($reportSets) > 1)
                <div class="col-span-full mb-3 mt-4">
                    <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                        {{ $rSet['title'] }}
                    </span>
                </div>
            @endif
            <div class="bg-white border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all duration-300 w-full mb-6 rounded-2xl">
                @php
                    $donutTitle = !empty($reportDataScope['key_events']) ? 'Events Distribution' : 'Traffic by Channel';
                    $donutItems = !empty($reportDataScope['key_events'])
                        ? array_map(fn($e) => ['label' => str_replace('_', ' ', $e['event_name']), 'value' => $e['event_count']], array_slice($reportDataScope['key_events'], 0, 8))
                        : array_map(fn($s) => ['label' => $s['source_medium'], 'value' => $s['sessions']], array_slice($reportDataScope['traffic_sources'] ?? [], 0, 8));
                    $donutTotal = array_sum(array_column($donutItems, 'value'));
                    $donutTotalLabel = !empty($reportDataScope['key_events']) ? 'Events' : 'Sessions';
                @endphp
                <div class="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">
                    <div class="w-1.5 h-1.5 rounded-full bg-yellow-400"></div> {{ $donutTitle }}
                </div>
                <div class="flex flex-col sm:flex-row items-center justify-center sm:justify-start gap-8">
                    <div class="relative w-48 h-48 shrink-0" wire:ignore>
                        <div x-data="{
                            chart: null,
                            init() {
                                if (!this.$refs.donutCanvas) return;
                                if (this.chart) {
                                    this.chart.destroy();
                                }
                                const ctx = this.$refs.donutCanvas.getContext('2d');
                                let rawData = {{ $idx === 0 ? '$wire.activeReportData' : '($wire.activeReportData && $wire.activeReportData.compare_data ? $wire.activeReportData.compare_data : null)' }};
                                let items = [];
                                let usingFallback = false;
                                if (rawData && rawData.key_events && rawData.key_events.length > 0) {
                                    items = rawData.key_events.map(e => ({ label: e.event_name, value: e.event_count }));
                                } else if (rawData && rawData.traffic_sources && rawData.traffic_sources.length > 0) {
                                    items = rawData.traffic_sources.slice(0, 8).map(e => ({ label: e.source_medium, value: e.sessions }));
                                    usingFallback = true;
                                } else {
                                    items = [{ label: 'No Data', value: 1 }];
                                }
                                let labels = items.map(e => e.label);
                                let data = items.map(e => e.value);
                                let colors = ['#3b82f6','#10b981','#f59e0b','#ec4899','#6366f1','#94a3b8','#8b5cf6','#0ea5e9'];
                                this.chart = new Chart(ctx, {
                                    type: 'doughnut',
                                    data: {
                                        labels: labels,
                                        datasets: [{ data: data, backgroundColor: colors.slice(0, data.length), borderWidth: 0 }]
                                    },
                                    options: { responsive: true, maintainAspectRatio: false, cutout: '75%', plugins: { legend: { display: false } } }
                                });
                            }
                        }">
                            <canvas x-ref="donutCanvas" id="donut-key-events-{{ $idx }}"></canvas>
                        </div>
                        <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span class="text-3xl font-black text-slate-800">
                                {{ number_format($donutTotal) }}
                            </span>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">{{ $donutTotalLabel }}</span>
                        </div>
                    </div>
                    <div class="flex flex-col gap-2 text-xs font-medium text-slate-500 w-full pr-4">
                        @php
                            $colors = ['bg-blue-500', 'bg-emerald-500', 'bg-yellow-500', 'bg-pink-500', 'bg-indigo-500', 'bg-slate-400', 'bg-purple-500', 'bg-sky-500'];
                        @endphp
                        @foreach($donutItems as $index => $item)
                            @php $percent = $donutTotal > 0 ? round(($item['value'] / $donutTotal) * 100, 1) : 0; @endphp
                            <div class="flex items-center justify-between w-full p-2 hover:bg-slate-50 rounded-lg transition-colors">
                                <div class="flex items-center gap-2">
                                    <div class="w-2 h-2 {{ $colors[$index % count($colors)] }} rounded-full"></div>
                                    <span class="capitalize text-slate-600">{{ $item['label'] }}</span>
                                </div>
                                <div class="flex items-center gap-3">
                                    <span class="font-bold text-slate-800">{{ number_format($item['value']) }}</span>
                                    <span class="text-slate-400 text-[10px] w-8 text-right">{{ $percent }}%</span>
                                </div>
                            </div>
@endforeach
</div>
</div>
</div>
        </div>
        @endforeach
        </div>
    </div>

    <!-- Right: Visitors by Channel Bar Chart -->
    <div>
        @if(count($reportSets) > 1)
        <div wire:key="wrapper-9-multi" class="flex flex-col lg:flex-row gap-6">
        @else
        <div wire:key="wrapper-9-single" class="flex flex-col gap-6">
        @endif
        @foreach($reportSets as $idx => $rSet)
        <div wire:key="ga4-section-3-{{ $idx }}" class="flex-1 w-full overflow-hidden">
            @php $reportDataScope = $rSet['data']; @endphp
            @if(count($reportSets) > 1)
                <div class="col-span-full mb-3 mt-4">
                    <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                        {{ $rSet['title'] }}
                    </span>
                </div>
            @endif
            <div class="bg-white border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all duration-300 w-full mb-6 rounded-2xl">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest">
                        <div class="w-1.5 h-1.5 rounded-full bg-yellow-400"></div> Visitors by Channel
                    </div>
                </div>
                <div class="h-64" wire:ignore x-data="{
                    chart: null,
                    init() {
                        if (!this.$refs.barCanvas) return;
                        if (this.chart) {
                            this.chart.destroy();
                        }
                        const ctx = this.$refs.barCanvas.getContext('2d');
                        let rawData = {{ $idx === 0 ? '$wire.activeReportData' : '($wire.activeReportData && $wire.activeReportData.compare_data ? $wire.activeReportData.compare_data : null)' }};
                        let sources = (rawData && rawData.traffic_sources) ? rawData.traffic_sources : [];
                        let labels = sources.map(c => c.source_medium).slice(0, 6);
                        let data = sources.map(c => c.sessions).slice(0, 6);
                        
                        if (labels.length === 0) {
                            labels = ['Organic Search', 'Paid Search', 'Direct', 'Unassigned', 'Organic Social', 'Referral'];
                            data = [620, 480, 310, 180, 40, 20];
                        }

                        this.chart = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: labels,
                                datasets: [{
                                    data: data,
                                    backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#93c5fd', '#f472b6', '#a78bfa'],
                                    borderWidth: 0,
                                    barPercentage: 0.5,
                                    categoryPercentage: 0.5
                                }]
                            },
                            options: {
                                responsive: true, maintainAspectRatio: false,
                                plugins: { legend: { display: false } },
                                scales: {
                                    y: { beginAtZero: true, grid: { color: '#f1f5f9' }, border: { dash: [4, 4] } },
                                    x: { grid: { display: false } }
                                }
                            }
                        });
                    }
                }">
                    <canvas x-ref="barCanvas" id="bar-channels-{{ $idx }}"></canvas>
                </div>
            </div>
        </div>
@endforeach
</div>
</div>
</div>

<!-- 2. Tables Grid -->
<div class="grid grid-cols-1 gap-6 mb-6">
<!-- Pageviews by Page Path -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-4-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50" x-data="{ showAllPages: false }">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Viewed Pages</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold w-1/2">Page Path</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Views</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Users</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach (array_slice($reportDataScope['pages_report'] ?? [], 0, 6) as $page)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-mono text-[10px] max-w-[220px] truncate w-1/2" title="{{ $page['page_path'] }}">{{ $page['page_path'] }}</td>
                                                                <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['pageviews'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['users'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            @if (count($reportDataScope['pages_report'] ?? []) > 6)
                                                <div class="transition-all duration-500 ease-in-out overflow-hidden"
                                                     :style="showAllPages ? 'max-height: 1000px; opacity: 100;' : 'max-height: 0px; opacity: 0;'">
                                                    <div class="overflow-x-auto">
                                                        <table class="w-full text-left text-xs">
                                                            <tbody>
                                                                @foreach (array_slice($reportDataScope['pages_report'] ?? [], 6) as $page)
                                                                    <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                        <td class="py-2.5 font-mono text-[10px] max-w-[220px] truncate w-1/2" title="{{ $page['page_path'] }}">{{ $page['page_path'] }}</td>
                                                                        <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['pageviews'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                                        <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['users'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="text-center mt-3 pt-2 border-t border-slate-200/20 dark:border-slate-800/40">
                                                    <button type="button" @click="showAllPages = !showAllPages" class="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition focus:outline-none">
                                                        <span x-text="showAllPages ? 'Show Less' : 'View Full'"></span>
                                                        <svg class="w-3.5 h-3.5 transform transition-transform duration-200" :class="showAllPages ? 'rotate-180' : ''" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            @endif
                                        </div>
</div>
                                    @endforeach
</div>
<!-- Traffic Sources & Channels -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-5-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50" x-data="{ showAllSources: false }">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Traffic Sources / Mediums</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold w-1/2">Source / Medium</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Count</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Bounce Rate</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach (array_slice($reportDataScope['traffic_sources'] ?? [], 0, 6) as $source)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-700 dark:text-slate-300">
                                                                <td class="py-2.5 font-bold w-1/2">{{ $source['source_medium'] }}</td>
                                                                <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($source['sessions'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ $source['bounce_rate'] ?? '—' }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            @if (count($reportDataScope['traffic_sources'] ?? []) > 6)
                                                <div class="transition-all duration-500 ease-in-out overflow-hidden"
                                                     :style="showAllSources ? 'max-height: 1000px; opacity: 100;' : 'max-height: 0px; opacity: 0;'">
                                                    <div class="overflow-x-auto">
                                                        <table class="w-full text-left text-xs">
                                                            <tbody>
                                                                @foreach (array_slice($reportDataScope['traffic_sources'] ?? [], 6) as $source)
                                                                    <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-700 dark:text-slate-300">
                                                                        <td class="py-2.5 font-bold w-1/2">{{ $source['source_medium'] }}</td>
                                                                        <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($source['sessions'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                                        <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ $source['bounce_rate'] ?? '—' }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="text-center mt-3 pt-2 border-t border-slate-200/20 dark:border-slate-800/40">
                                                    <button type="button" @click="showAllSources = !showAllSources" class="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition focus:outline-none">
                                                        <span x-text="showAllSources ? 'Show Less' : 'View Full'"></span>
                                                        <svg class="w-3.5 h-3.5 transform transition-transform duration-200" :class="showAllSources ? 'rotate-180' : ''" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            @endif
                                        </div>
                                    
</div>
                                    @endforeach
</div>
</div>

<!-- 3. Lower Grid: Demographics, Geography -->
<div class="grid grid-cols-1 gap-6 mb-6">
<!-- Devices -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-6-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">Device Breakdowns</h4>
                                            <div class="space-y-4">
                                                @foreach ($reportDataScope['device_demographics'] ?? [] as $device)
                                                    <div>
                                                        <div class="flex justify-between text-xs mb-1">
                                                            <span class="font-bold text-slate-700 dark:text-slate-300">{{ $device['device'] }}</span>
                                                            <span class="text-slate-400 dark:text-slate-500 font-bold">
{{ $device['percentage'] }}
@if($hasCompare)
                                                                @php
                                                                    $keyToUse = isset($baseData['device_demographics'][0]['active_users']) ? 'active_users' : 'sessions';
                                                                    $myVal = $device[$keyToUse] ?? 0;
                                                                    $compareVal = 0;
                                                                    $otherArr = $idx == 0 ? ($baseData['compare_data']['device_demographics'] ?? []) : ($baseData['device_demographics'] ?? []);
                                                                    foreach($otherArr as $od) {
                                                                        if($od['device'] === $device['device']) { $compareVal = $od[$keyToUse] ?? 0; break; }
                                                                    }
                                                                    $delta = $calculateDelta($myVal, $compareVal, $format);
                                                                @endphp
                                                                <span class="text-[10px] {{ $delta['trend'] === 'up' ? 'text-emerald-500' : ($delta['trend'] === 'down' ? 'text-rose-500' : 'text-slate-400') }} ml-1.5 inline-flex items-center">
                                                                    @if($delta['trend'] !== 'flat')
                                                                        <svg class="w-2.5 h-2.5 {{ $delta['trend'] === 'down' ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg>
                                                                    @endif
                                                                    {{ $delta['value'] }}
                                                                </span>
                                                            @endif
</span>
                                                        </div>
                                                        <div class="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                                                            <div class="bg-indigo-600 dark:bg-indigo-400 h-1.5 rounded-full" style="width: {{ $device['percentage'] }}"></div>
                                                        </div>
                                                    </div>
@endforeach
</div>
</div>
</div>
                                    @endforeach
</div>
<!-- Geographic Country Sources -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-7-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<!-- Events Charts -->
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 col-span-2">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">Events</h4>
                                            
                                            <div class="flex flex-col gap-6">
                                                @php
                                                    $eventsData = $reportDataScope['events_report'] ?? [];
                                                    if (isset($eventsData[0]) && isset($eventsData[0]['event_name'])) {
                                                        $newFormat = [];
                                                        foreach ($eventsData as $item) {
                                                            if (!isset($newFormat[$item['event_name']])) {
                                                                $newFormat[$item['event_name']] = [];
                                                            }
                                                            $newFormat[$item['event_name']][] = [
                                                                'channel' => $item['channel'] ?? 'Unknown',
                                                                'count' => $item['count'] ?? 0
                                                            ];
                                                        }
                                                        $eventsData = $newFormat;
                                                    }
                                                    $colors = ['#3b82f6', '#a855f7', '#f59e0b', '#10b981', '#ec4899', '#6366f1'];
                                                @endphp
                                                
                                                @forelse($eventsData as $eventName => $channels)
                                                    @php
                                                        $totalEvents = array_sum(array_column($channels, 'count'));
                                                        usort($channels, function($a, $b) { return $b['count'] <=> $a['count']; });
                                                    @endphp
                                                    <div class="bg-white dark:bg-slate-800 rounded-xl p-4 border border-slate-100 dark:border-slate-700 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6"><div class="relative w-28 h-28 shrink-0">
                                                            <svg viewBox="0 0 36 36" class="w-full h-full transform -rotate-90">
                                                                @php
                                                                    $cumulativePercent = 0;
                                                                    $colorIndex = 0;
                                                                @endphp
                                                                @foreach($channels as $channel)
                                                                    @if($totalEvents > 0)
                                                                        @php
                                                                            $percent = ($channel['count'] / $totalEvents) * 100;
                                                                            $dashArray = $percent . " " . (100 - $percent);
                                                                            $dashOffset = 100 - $cumulativePercent;
                                                                            $cumulativePercent += $percent;
                                                                            $currentColor = $colors[$colorIndex % count($colors)];
                                                                            $colorIndex++;
                                                                        @endphp
                                                                        <circle cx="18" cy="18" r="15.91549430918954" fill="transparent" stroke="{{ $currentColor }}" stroke-width="4" stroke-dasharray="{{ $dashArray }}" stroke-dashoffset="{{ $dashOffset }}"></circle>
                                                                    @endif
                                                                @endforeach
                                                            </svg>
                                                            <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                                                                <span class="text-xl font-extrabold text-slate-800 dark:text-white">{{ number_format($totalEvents) }}</span>
                                                                <span class="text-[9px] text-slate-400 font-bold uppercase tracking-widest text-center leading-tight">Key<br>Events</span>
                                                            </div>
                                                        </div>
                                                        <div class="w-full">
                                                            <h5 class="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3 border-b border-slate-100 dark:border-slate-700 pb-2 flex items-center justify-between">
                                                                {{ $eventName }}
                                                                @php
                                                                    $compareEvents = $activeReportData['compare_data']['events_report'] ?? [];
                                                                    // Fix structure if needed
                                                                    if (isset($compareEvents[0]) && isset($compareEvents[0]['event_name'])) {
                                                                        $newFormat = [];
                                                                        foreach ($compareEvents as $item) {
                                                                            if (!isset($newFormat[$item['event_name']])) $newFormat[$item['event_name']] = [];
                                                                            $newFormat[$item['event_name']][] = ['count' => $item['count'] ?? 0];
                                                                        }
                                                                        $compareEvents = $newFormat;
                                                                    }
                                                                    $pastTotal = 0;
                                                                    if (isset($compareEvents[$eventName])) {
                                                                        $pastTotal = array_sum(array_column($compareEvents[$eventName], 'count'));
                                                                    }
                                                                    
                                                                    $showBadge = false;
                                                                    $percentChange = 0;
                                                                    $isPositive = true;
                                                                    
                                                                    if (isset($activeReportData['compare_data'])) {
                                                                        $showBadge = true;
                                                                        if ($pastTotal > 0) {
                                                                            $percentChange = (($totalEvents - $pastTotal) / $pastTotal) * 100;
                                                                        } else if ($totalEvents > 0) {
                                                                            $percentChange = 100;
                                                                        }
                                                                        $isPositive = $percentChange >= 0;
                                                                    }
                                                                @endphp
                                                                @if($showBadge)
                                                                <span class="text-[10px] px-1.5 py-0.5 rounded flex items-center gap-0.5 {{ $isPositive ? 'text-emerald-500 bg-emerald-50 dark:bg-emerald-900/30' : 'text-red-500 bg-red-50 dark:bg-red-900/30' }}">
                                                                    @if($isPositive)
                                                                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                                                                    @else
                                                                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13 17h8m0 0v-8m0 8l-8-8-4 4-6-6" /></svg>
                                                                    @endif
                                                                    {{ number_format(abs($percentChange), 1) }}%
                                                                </span>
                                                                @endif
                                                            </h5>
                                                            <ul class="space-y-2">
                                                                @php $colorIndex = 0; @endphp
                                                                @foreach(array_slice($channels, 0, 5) as $channel)
                                                                    <li class="flex items-center justify-between text-xs">
                                                                        <div class="flex items-center gap-2">
                                                                            <span class="w-2.5 h-2.5 rounded-full" style="background-color: {{ $colors[$colorIndex % count($colors)] }}"></span>
                                                                            <span class="text-slate-600 dark:text-slate-400 truncate max-w-[100px]" title="{{ $channel['channel'] }}">{{ $channel['channel'] }}</span>
                                                                        </div>
                                                                        <div class="flex items-center gap-2">
                                                                            <span class="font-bold text-slate-800 dark:text-slate-200">{{ number_format($channel['count']) }}</span>
                                                                            <span class="text-[10px] text-slate-400 w-10 text-right">
                                                                                @if($totalEvents > 0)
                                                                                    ({{ number_format(($channel['count'] / $totalEvents) * 100, 1) }}%)
                                                                                @else
                                                                                    (0%)
                                                                                @endif
                                                                            </span>
                                                                        </div>
                                                                    </li>
                                                                    @php $colorIndex++; @endphp
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    
                                                        </div>
                                                @empty
                                                    <div class="col-span-full py-10 text-center text-slate-400 text-xs">No Events recorded in this period.</div>
                                                @endforelse
                                            </div>
                                        </div>
                                    @endforeach
</div>
</div>

                                    @elseif ($activeReportIntegrationId === 'youtube')
                                        <!-- 1. Stats Summary Widgets (YouTube) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-red-50/20 dark:bg-red-950/10 border border-red-100/30 dark:border-red-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Views</span>
                                                <span class="text-lg font-extrabold text-red-600 dark:text-red-400">
                                                    {{ number_format($activeReportData['summary']['views'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-orange-50/20 dark:bg-orange-950/10 border border-orange-100/30 dark:border-orange-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Watch Time (hrs)</span>
                                                <span class="text-lg font-extrabold text-orange-600 dark:text-orange-400">
                                                    {{ number_format($activeReportData['summary']['watch_time'] ?? 0, 1) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Subscribers</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ number_format($activeReportData['summary']['subscribers'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg Duration</span>
                                                <span class="text-lg font-extrabold text-indigo-600 dark:text-indigo-400">
                                                    {{ $activeReportData['summary']['avg_view_duration'] ?? '0s' }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. Top Videos Table (YouTube) -->
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mb-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Performing Videos</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Video Title</th>
                                                            <th class="py-2 text-right font-bold">Views</th>
                                                            <th class="py-2 text-right font-bold">Watch Time</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @forelse ($activeReportData['top_videos'] ?? [] as $video)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate max-w-[200px]" title="{{ $video['title'] }}">{{ $video['title'] }}</td>
                                                                <td class="py-2.5 text-right font-bold">{{ number_format($video['views'] ?? 0) }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($video['watch_time'] ?? 0, 1) }} hrs</td>
                                                            </tr>
                                                        @empty
                                                            <tr>
                                                                <td colspan="3" class="py-4 text-center text-slate-500">No video data available.</td>
                                                            </tr>
                                                        @endforelse
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    @elseif($activeReportIntegrationId === 'keyword')
                                        <!-- 1. Summary Cards (Keyword) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-purple-50/20 dark:bg-purple-950/10 border border-purple-100/30 dark:border-purple-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Keywords</span>
                                                <span class="text-lg font-extrabold text-purple-600 dark:text-purple-400">
                                                    {{ number_format($activeReportData['summary']['total_keywords'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Top 10 Rankings</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ number_format($activeReportData['summary']['top_10'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Up Movements</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ number_format($activeReportData['summary']['up_movements'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-orange-50/20 dark:bg-orange-950/10 border border-orange-100/30 dark:border-orange-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Share of Voice</span>
                                                <span class="text-lg font-extrabold text-orange-600 dark:text-orange-400">
                                                    {{ $activeReportData['summary']['share_of_voice'] ?? '0%' }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. Keywords and Pages Tables (Keyword) -->
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                            <!-- Top Keyword Rankings -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Keyword Rankings</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">Keyword</th>
                                                                <th class="py-2 text-right font-bold">Position</th>
                                                                <th class="py-2 text-right font-bold">Change</th>
                                                                <th class="py-2 text-right font-bold">Volume</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @forelse ($activeReportData['keywords'] ?? [] as $kw)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-bold truncate max-w-[200px]" title="{{ $kw['keyword'] }}">{{ $kw['keyword'] }}</td>
                                                                    <td class="py-2.5 text-right font-bold">#{{ $kw['position'] ?? '-' }}</td>
                                                                    <td class="py-2.5 text-right {{ (strpos($kw['change'], '+') !== false) ? 'text-emerald-500' : ((strpos($kw['change'], '-') !== false) ? 'text-red-500' : 'text-slate-400') }} font-bold">
                                                                        {{ $kw['change'] ?? '0' }}
                                                                    </td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($kw['volume'] ?? 0) }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="4" class="py-4 text-center text-slate-500">No keyword data available.</td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                            <!-- Top Ranking URLs -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Ranking URLs</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">URL</th>
                                                                <th class="py-2 text-right font-bold">Keywords</th>
                                                                <th class="py-2 text-right font-bold">Total Volume</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @forelse ($activeReportData['pages'] ?? [] as $pg)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 truncate max-w-[250px]" title="{{ $pg['url'] }}">{{ $pg['path'] }}</td>
                                                                    <td class="py-2.5 text-right font-bold">{{ number_format($pg['keyword_count'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($pg['total_volume'] ?? 0) }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="3" class="py-4 text-center text-slate-500">No URL data available.</td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <!-- Top Pages -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-5">
                                                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Pages</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-xs">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2 font-bold">URL</th>
                                                                <th class="py-2 text-right font-bold">Keywords</th>
                                                                <th class="py-2 text-right font-bold">Avg. Rank</th>
                                                                <th class="py-2 text-right font-bold">Total Search Volume</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @forelse ($activeReportData['pages'] ?? [] as $pg)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 truncate max-w-[250px]" title="{{ $pg['url'] }}">
                                                                        <a href="{{ $pg['url'] }}" target="_blank" class="hover:text-indigo-500 hover:underline">
                                                                            {{ $pg['url'] }}
                                                                        </a>
                                                                    </td>
                                                                    <td class="py-2.5 text-right font-bold">{{ number_format($pg['keyword_count'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right font-bold text-emerald-600 dark:text-emerald-400">{{ isset($pg['avg_rank']) ? $pg['avg_rank'] : 0 }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($pg['total_volume'] ?? 0) }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="4" class="py-4 text-center text-slate-500">No URL data available.</td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($activeReportIntegrationId === 'gtm')
                                        <!-- 1. Stats Summary Widgets (GTM) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Workspace</span>
                                                <span class="text-base font-extrabold text-indigo-600 dark:text-indigo-400 truncate block">
                                                    {{ $activeReportData['summary']['workspace_name'] ?? 'Unknown' }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Tags</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ number_format($activeReportData['summary']['tags_count'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-amber-50/20 dark:bg-amber-950/10 border border-amber-100/30 dark:border-amber-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Triggers</span>
                                                <span class="text-lg font-extrabold text-amber-600 dark:text-amber-400">
                                                    {{ number_format($activeReportData['summary']['triggers_count'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Variables</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ number_format($activeReportData['summary']['variables_count'] ?? 0) }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. GTM Tags Table -->
                                        @if(!empty($activeReportData['tags_list']))
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">All Tags</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Tag Name</th>
                                                            <th class="py-2 text-right font-bold">Type</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($activeReportData['tags_list'] as $tag)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate" title="{{ $tag['name'] }}">{{ $tag['name'] }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ $tag['type'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        @endif

                                        <!-- 3. GTM Triggers Table -->
                                        @if(!empty($activeReportData['triggers_list']))
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">All Triggers</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Trigger Name</th>
                                                            <th class="py-2 text-right font-bold">Type</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($activeReportData['triggers_list'] as $trigger)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate" title="{{ $trigger['name'] ?? '' }}">{{ $trigger['name'] ?? 'Unknown' }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ $trigger['type'] ?? 'Unknown' }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        @endif

                                        <!-- 4. GTM Variables Table -->
                                        @if(!empty($activeReportData['variables_list']))
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">All Variables</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Variable Name</th>
                                                            <th class="py-2 text-right font-bold">Type</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($activeReportData['variables_list'] as $variable)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate" title="{{ $variable['name'] ?? '' }}">{{ $variable['name'] ?? 'Unknown' }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ $variable['type'] ?? 'Unknown' }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        @endif
                                    @endif
                                @endif
                            </div>
                            
                            <!-- Modal Footer -->
                            <div class="flex items-center justify-end p-4 border-t border-slate-100 dark:border-slate-800/60 rounded-b-3xl sticky bottom-0 bg-white dark:bg-slate-900 z-10">
                                <button type="button" x-on:click="$wire.showReportModal = false;" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition">
                                    Close Report
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        @elseif ($activeTab === 'settings')
            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6 shadow-sm animate-fadeIn">
                <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4">Quick Settings</h3>
                <p class="text-xs text-slate-450 dark:text-slate-500 mb-6">Manage administrative state settings for this client's workspace.</p>
                <div class="flex flex-wrap gap-3">
                    <button type="button" wire:click="editClient({{ $clientDetails->id }})" class="px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-350 font-bold text-xs rounded-xl active:scale-95 transition">
                        Edit Full Profile Settings
                    </button>
                    @if ($clientDetails->status === 'active')
                        <button type="button" wire:click="toggleClientStatus({{ $clientDetails->id }}, 'inactive')" wire:confirm="Are you sure you want to deactivate this account?" class="px-4 py-2.5 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800/30 font-bold text-xs rounded-xl active:scale-95 transition">
                            Deactivate Account
                        </button>
                    @else
                        <button type="button" wire:click="toggleClientStatus({{ $clientDetails->id }}, 'active')" class="px-4 py-2.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/30 font-bold text-xs rounded-xl active:scale-95 transition">
                            Activate Account
                        </button>
                    @endif
                </div>
            </div>
        @endif

    @else
        {{-- ══════════════════════════════════════════════
             PAGE HEADER — Title + Add Client button
             ══════════════════════════════════════════════ --}}
        <div class="flex items-center justify-between gap-4 mb-5">
            <p class="text-xs text-slate-400 dark:text-slate-500 font-medium">
                Manage and track all your client accounts
            </p>

            <div class="flex items-center gap-2">
                <a href="{{ route('admin.clients.plans') }}"
                   class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 hover:bg-slate-200/50 dark:hover:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-sm font-semibold transition-all duration-150 active:scale-95 shrink-0 whitespace-nowrap">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    Manage Plans
                </a>

                {{-- Add Client button --}}
                <button type="button" @click="$dispatch('open-modal', { name: 'add-client-modal' })"
        style="background: linear-gradient(90deg, #105166 0%, #529daa 100%);"
        class="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-white text-sm font-semibold shadow-lg transition-all duration-300">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
        </svg>
        Add Client
    </button>
            </div>
        </div>

        {{-- ══════════════════════════════════════════════
             STATISTICS SUMMARY GRID
             ══════════════════════════════════════════════ --}}
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {{-- Card 1: Total Clients --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Total Clients</p>
                    <h3 class="text-3xl font-extrabold text-slate-800 dark:text-white mt-1">{{ $totalClientsCount }}</h3>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 font-semibold mt-1.5 flex items-center gap-1">
                        <span class="text-emerald-500 font-bold">{{ $activeClientsCount }} active</span>
                        <span>•</span>
                        <span class="text-slate-400 font-bold">{{ $inactiveClientsCount }} inactive</span>
                    </p>
                </div>
                <div class="p-3 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                </div>
            </div>

            {{-- Card 2: Active Clients --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Active Clients</p>
                    <h3 class="text-3xl font-extrabold text-slate-800 dark:text-white mt-1">{{ $activeClientsCount }}</h3>
                    <p class="text-[11px] text-emerald-500 dark:text-emerald-400 font-semibold mt-1.5">active accounts</p>
                </div>
                <div class="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>

            {{-- Card 3: Inactive Clients --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Inactive Clients</p>
                    <h3 class="text-3xl font-extrabold text-slate-800 dark:text-white mt-1">{{ $inactiveClientsCount }}</h3>
                    <p class="text-[11px] text-slate-400 dark:text-slate-500 font-semibold mt-1.5">inactive / paused</p>
                </div>
                <div class="p-3 bg-amber-50 dark:bg-amber-950/20 text-amber-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                </div>
            </div>

            {{-- Card 4: Total Websites --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Total Websites</p>
                    <h3 class="text-3xl font-extrabold text-slate-800 dark:text-white mt-1">{{ $totalWebsitesCount }}</h3>
                    <p class="text-[11px] text-indigo-500 dark:text-indigo-400 font-semibold mt-1.5 flex items-center gap-1">
                        <span class="text-emerald-500 font-bold">{{ $activeWebsitesCount }} active</span>
                        <span>•</span>
                        <span class="text-slate-400 font-bold">{{ $inactiveWebsitesCount }} inactive</span>
                    </p>
                </div>
                <div class="p-3 bg-sky-50 dark:bg-sky-950/20 text-sky-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                    </svg>
                </div>
            </div>
        </div>

        {{-- ══════════════════════════════════════════════
             FILTERS — Responsive grid
             ══════════════════════════════════════════════ --}}
        <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-4 mb-5 shadow-sm">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-3">

                {{-- Search --}}
                <div class="relative flex items-center">
                    <svg wire:loading.remove wire:target="search" class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <div wire:loading wire:target="search" class="absolute left-3 pointer-events-none shrink-0 z-10 flex items-center">
                        <svg class="animate-spin w-4 h-4 text-indigo-600 dark:text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </div>
                    <input wire:model.live.debounce.300ms="search"
                           type="text"
                           autocomplete="off"
                           placeholder="Search by name, email, or company..."
                           class="block w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 text-sm transition duration-150" />
                </div>

                {{-- Status Filter --}}
                <div class="relative flex items-center">
                    <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
                    </svg>
                    <select wire:model.live="statusFilter"
                            class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 text-sm transition duration-150 appearance-none">
                        <option value="" class="dark:bg-slate-900">All Statuses</option>
                        <option value="active" class="dark:bg-slate-900">Active</option>
                        <option value="inactive" class="dark:bg-slate-900">Inactive</option>
                    </select>
                    <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </div>

                {{-- Plan Filter --}}
                <div class="relative flex items-center">
                    <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    <select wire:model.live="planFilter"
                            class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 text-sm transition duration-150 appearance-none">
                        <option value="" class="dark:bg-slate-900">All Plans</option>
                        @foreach($plans as $planOpt)
                            @php
                                $pId = is_object($planOpt) ? $planOpt->id : (is_array($planOpt) ? ($planOpt['id'] ?? '') : $planOpt);
                                $pName = is_object($planOpt) ? $planOpt->name : (is_array($planOpt) ? ($planOpt['name'] ?? '') : $planOpt);
                            @endphp
                            <option value="{{ $pId }}" class="dark:bg-slate-900">{{ $pName }}</option>
                        @endforeach
                    </select>
                    <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </div>

                {{-- Per Page Filter --}}
                <div class="relative flex items-center">
                    <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                    </svg>
                    <select wire:model.live="perPage"
                            class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 text-sm transition duration-150 appearance-none">
                        <option value="20" class="dark:bg-slate-900">20 per page</option>
                        <option value="50" class="dark:bg-slate-900">50 per page</option>
                        <option value="100" class="dark:bg-slate-900">100 per page</option>
                    </select>
                    <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </div>
            </div>

            {{-- Clear Filters row — only shown when a filter is active --}}
            @if($hasActiveFilters)
                <div class="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between">
                    <span class="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Filters active — showing filtered results
                    </span>
                    <button type="button" wire:click="clearFilters"
                            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 border border-red-200/60 dark:border-red-800/30 hover:bg-red-100 dark:hover:bg-red-500/20 text-xs font-bold transition-all duration-150 active:scale-95">
                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        Clear Filters
                    </button>
                </div>
            @endif
        </div>

        <!-- Success Message Alert -->
        @if (session('success'))
            <x-admin.alert type="success" class="mb-6" :message="session('success')" />
        @endif

        <!-- Clients Table Card -->
        <x-admin.card class="w-full max-w-full overflow-hidden">

            {{-- Bulk Action Bar (visible only when items are selected) --}}
            @if(count($selectedClients) > 0)
                <div class="flex items-center justify-between gap-3 mb-4 px-1 py-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-200/60 dark:border-indigo-700/30">
                    <span class="text-xs font-bold text-indigo-700 dark:text-indigo-400 flex items-center gap-2 pl-2">
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
                        </svg>
                        Selected {{ count($selectedClients) }} item(s)
                    </span>
                    <div class="flex items-center gap-2 pr-2">
                        <button type="button" wire:click="bulkActivate" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition active:scale-95">
                            Activate
                        </button>
                        <button type="button" wire:click="bulkDeactivate" class="px-3 py-1.5 bg-slate-600 hover:bg-slate-700 text-white text-xs font-bold rounded-lg transition active:scale-95">
                            Deactivate
                        </button>
                        <button type="button" wire:click="clearSelection" class="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg transition active:scale-95">
                            Cancel
                        </button>
                    </div>
                </div>
            @endif

            @if($clients->isEmpty())
                <div class="text-center py-12">
                    <svg class="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    <h3 class="text-base font-bold text-slate-800 dark:text-slate-300 mb-1">No Clients Found</h3>
                    <p class="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">Try refining your search keyword or create a new client profile above.</p>
                </div>
            @else
                {{-- Custom table with checkbox column --}}
                <div id="clientsListTableTop" class="overflow-x-auto custom-scrollbar w-full rounded-2xl border border-slate-200/50 dark:border-slate-800/50" x-data="{
                    init() {
                        Livewire.on('scroll-to-top', () => {
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                        });
                    }
                }">
                    <table class="w-full text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                        <thead>
                            <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                {{-- Select All checkbox --}}
                                <th class="px-3 py-3.5 w-10 text-center">
                                    <input type="checkbox"
                                           wire:model="selectAll"
                                             x-on:change="const isChecked = $event.target.checked; Array.from(document.querySelectorAll('input[type=checkbox]')).filter(cb => cb.getAttribute('wire:model') && cb.getAttribute('wire:model').startsWith('selected')).forEach(cb => { if(cb.checked !== isChecked) { cb.checked = isChecked; cb.dispatchEvent(new window.Event('change')); } });"
                                           class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500/40 focus:ring-2 cursor-pointer transition" />
                                </th>
                                <th class="px-3 py-3.5">Client Details</th>
                                <th class="px-3 py-3.5">Company Name</th>
                                <th class="px-3 py-3.5">Plans</th>
                                <th class="px-3 py-3.5 text-center cursor-pointer select-none" wire:click="sortBy('websites_count')">
                                    <div class="inline-flex items-center gap-1 justify-center">
                                        <span>Websites</span>
                                        @if($sortField === 'websites_count')
                                            @if($sortDirection === 'asc')
                                                <svg class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7" /></svg>
                                            @else
                                                <svg class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" /></svg>
                                            @endif
                                        @else
                                            <svg class="w-3 h-3 text-slate-300 hover:text-slate-400 dark:text-slate-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 9l4-4 4 4m0 6l-4 4-4-4" /></svg>
                                        @endif
                                    </div>
                                </th>
                                <th class="px-3 py-3.5 hidden xl:table-cell">Phone Numbers</th>
                                <th class="px-3 py-3.5 text-center">Status</th>
                                <th class="px-3 py-3.5 text-center hidden lg:table-cell">Last Login</th>
                                <th class="px-3 py-3.5 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody wire:loading.class="hidden" wire:target="search, statusFilter, planFilter, perPage, sortBy, nextPage, previousPage, gotoPage" class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                            @foreach($clients as $client)
                                <tr wire:key="client-{{ $client->id }}" class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors {{ in_array($client->id, $selectedClients) ? 'bg-indigo-50/40 dark:bg-indigo-900/10' : '' }}">
                                    {{-- Row Checkbox --}}
                                    <td class="px-3 py-3.5 w-10 text-center">
                                        <input type="checkbox"
                                               wire:model="selectedClients"
                                               value="{{ $client->id }}"
                                               class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500/40 focus:ring-2 cursor-pointer transition" />
                                    </td>
                                    <td class="px-3 py-3.5">
                                        <div class="flex items-center gap-3">
                                            <a href="{{ route('admin.clients.detail', ['id' => $client->id]) }}" wire:navigate class="shrink-0 cursor-pointer">
                                                @if($client->profile_image)
                                                    <img src="{{ asset('storage/' . $client->profile_image) }}" alt="{{ $client->user->name }}" class="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-800" onerror="this.outerHTML=`<div class='w-9 h-9 rounded-full bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-xs font-bold text-indigo-600 dark:text-indigo-400'>{{ $client->getInitials() }}</div>`" />
                                                @else
                                                    <div class="w-9 h-9 rounded-full bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-xs font-bold text-indigo-600 dark:text-indigo-400">
                                                        {{ $client->getInitials() }}
                                                    </div>
                                                @endif
                                            </a>
                                            <div class="min-w-0 flex-1">
                                                <a href="{{ route('admin.clients.detail', ['id' => $client->id]) }}" wire:navigate class="font-bold text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer transition truncate max-w-[160px] sm:max-w-[200px] lg:max-w-none lg:whitespace-normal block" title="{{ $client->user->name ?? 'Deleted User' }}">
                                                    {{ $client->user->name ?? 'Deleted User' }}
                                                </a>
                                                <div class="text-xs text-slate-400 dark:text-slate-500 truncate max-w-[160px] sm:max-w-[200px] lg:max-w-none lg:whitespace-normal" title="{{ $client->user->email ?? 'N/A' }}">{{ $client->user->email ?? 'N/A' }}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-3 py-3.5 text-slate-700 dark:text-slate-350 font-semibold">
                                        <a href="{{ route('admin.clients.detail', ['id' => $client->id]) }}" wire:navigate class="hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                            {{ $client->company_name ?: '—' }}
                                        </a>
                                    </td>
                                    <td class="px-3 py-3.5">
                                        @if($client->plans->isNotEmpty())
                                            <div class="flex flex-wrap gap-1">
                                                @foreach($client->plans as $pl)
                                                    <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-{{ $pl->color }}-500/10 text-{{ $pl->color }}-600 dark:text-{{ $pl->color }}-400 tracking-wider">
                                                        {{ $pl->name }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @else
                                            —
                                        @endif
                                    </td>
                                    <td class="px-3 py-3.5 text-center">
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50">
                                        <svg class="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                        </svg>
                                        {{ $client->websites_count }}
                                    </span>
                                </td>

                                <td class="px-3 py-3.5 hidden xl:table-cell text-slate-500 dark:text-slate-400 font-medium text-xs">
                                    @if($client->phones->isEmpty())
                                        {{ $client->phone ?: '—' }}
                                    @else
                                        <div class="space-y-1">
                                            @foreach($client->phones as $phoneRec)
                                                <div><span class="font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest text-[9px] mr-1">{{ $phoneRec->label }}:</span> {{ $phoneRec->phone }}</div>
                                            @endforeach
                                        </div>
                                    @endif
                                </td>
                                <td class="px-3 py-3.5 text-center">
                                    <span class="px-2.5 py-1 text-xs font-bold rounded-lg
                                          {{ $client->status === 'active'
                                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                              : 'bg-slate-500/10 text-slate-500 dark:text-slate-400' }}">
                                        {{ ucfirst($client->status) }}
                                    </span>
                                </td>
                                <td class="px-3 py-3.5 text-center hidden lg:table-cell text-xs text-slate-500 dark:text-slate-400 font-semibold">
                                    {{ $client->last_login_at ? $client->last_login_at->diffForHumans() : 'Never' }}
                                </td>
                                <td class="px-3 py-3.5 text-center whitespace-nowrap">
                                    @php
                                        $clientEditData = [
                                            'id' => $client->id,
                                            'user_id' => $client->user_id,
                                            'name' => $client->user->name ?? '',
                                            'email' => $client->user->email ?? '',
                                            'company_name' => $client->company_name ?? '',
                                            'profile_image' => $client->profile_image ?? '',
                                            'status' => $client->status ?? 'active',
                                            'notes' => $client->notes ?? '',
                                            'address' => $client->address ?? '',
                                            'landmark' => $client->landmark ?? '',
                                            'state' => $client->state ?? '',
                                            'country' => $client->country ?? '',
                                            'region' => $client->region ?? '',
                                            'zip_code' => $client->zip_code ?? '',
                                            'phones' => $client->phones->isNotEmpty() 
                                                ? $client->phones->map(fn($p) => ['phone' => $p->phone, 'label' => $p->label])->toArray() 
                                                : [['phone' => '', 'label' => 'Work']],
                                            'plan_ids' => $client->plans->pluck('id')->toArray(),
                                            'assigned_staff_id' => $client->assignedStaff->first()?->id,
                                        ];

                                        $clickUpFolderIds = $client->clickUpFolders->pluck('id')->map(fn($id) => (string)$id)->toArray();
                                    @endphp
                                    @php
                                        $clientMappingData = [
                                            'id' => $client->id,
                                            'name' => $client->user->name ?? 'Client',
                                            'email' => $client->user->email ?? '',
                                            'company_name' => $client->company_name ?? '',
                                            'initials' => $client->getInitials(),
                                        ];
                                    @endphp
                                    <div class="inline-flex items-center justify-center gap-1.5 shrink-0">
                                        @if(!empty($clickUpFolderIds))
                                            <button type="button"
                                                    wire:click="disconnectClickUpMapping({{ $client->id }})"
                                                    wire:confirm="Are you sure you want to disconnect ClickUp from {{ $client->company_name ?: ($client->user->name ?? 'this client') }}?"
                                                    class="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-rose-50 dark:bg-rose-500/10 border border-rose-200/80 dark:border-rose-800/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 shadow-sm transition-all duration-150 active:scale-95 shrink-0"
                                                    title="Disconnect ClickUp from {{ $client->user->name ?? 'Client' }}">
                                                <span class="hidden 2xl:inline">Disconnect</span>
                                                <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                                            </button>
                                        @else
                                            <button type="button" 
                                                    @click="
                                                        $dispatch('open-clickup-modal', { client: {{ Js::from($clientMappingData) }}, folderIds: {{ Js::from($clickUpFolderIds) }} });
                                                        $dispatch('open-modal', { name: 'clickup-client-mapping-modal' });
                                                    "
                                                    class="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-sm transition-all duration-150 active:scale-95 shrink-0"
                                                    title="Map ClickUp Folders to this Client">
                                                    <span class="hidden 2xl:inline">Map With</span>
                                                <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                                            </button>
                                        @endif

                                        @if($client->user_id)
                                            <a href="{{ route('impersonate.start', $client->user_id) }}"
                                               class="inline-flex items-center justify-center p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150 active:scale-90 shrink-0"
                                               title="Login as {{ $client->user->name ?? 'this client' }}"
                                               onclick="return confirm('Are you sure you want to login as {{ $client->user->name ?? 'this client' }}?')">
                                                <img src="{{ asset('aspire-hub-staff-switch.svg') }}" class="w-6 h-6 shrink-0 opacity-80 hover:opacity-100 transition-opacity" alt="Switch Account" />
                                            </a>
                                        @endif

                                        <button type="button" 
                                                @click="
                                                    const data = {{ Js::from($clientEditData) }};
                                                    $wire.editingClientId = data.id;
                                                    $wire.editingUserId = data.user_id;
                                                    $wire.name = data.name;
                                                    $wire.email = data.email;
                                                    $wire.password = '';
                                                    $wire.company_name = data.company_name;
                                                    $wire.existing_profile_image = data.profile_image;
                                                    $wire.profile_image = '';
                                                    $wire.status = data.status;
                                                    $wire.notes = data.notes;
                                                    $wire.address = data.address;
                                                    $wire.landmark = data.landmark;
                                                    $wire.state = data.state;
                                                    $wire.country = data.country;
                                                    $wire.region = data.region;
                                                    $wire.zip_code = data.zip_code;
                                                    $wire.phones = data.phones;
                                                    $wire.plan_ids = data.plan_ids;
                                                    $wire.assigned_staff_id = data.assigned_staff_id;
                                                    $dispatch('open-modal', { name: 'edit-client-modal' });
                                                "
                                                class="inline-flex items-center gap-1.5 p-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-all duration-150 active:scale-95 shrink-0"
                                                title="Edit Client Profile">
                                            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                            </svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tbody wire:loading.class.remove="hidden" wire:target="search, statusFilter, planFilter, perPage, sortBy, nextPage, previousPage, gotoPage" class="hidden divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                        @for($i = 0; $i < $perPage; $i++)
                            <tr class="animate-pulse bg-white/20 dark:bg-slate-900/5">
                                <td class="px-3 py-4 w-10 text-center"><div class="w-4 h-4 rounded bg-slate-200 dark:bg-slate-700 mx-auto"></div></td>
                                <td class="px-3 py-4"><div class="flex items-center gap-3"><div class="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-700 shrink-0"></div><div class="space-y-2 flex-1"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-32"></div><div class="h-3 bg-slate-200 dark:bg-slate-700 rounded w-24"></div></div></div></td>
                                <td class="px-3 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-28"></div></td>
                                <td class="px-3 py-4"><div class="flex gap-1"><div class="h-5 bg-slate-200 dark:bg-slate-700 rounded w-16"></div><div class="h-5 bg-slate-200 dark:bg-slate-700 rounded w-16"></div></div></td>
                                <td class="px-3 py-4"><div class="h-6 bg-slate-200 dark:bg-slate-700 rounded-full w-12 mx-auto"></div></td>
                                <td class="px-3 py-4 hidden xl:table-cell"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-28"></div></td>
                                <td class="px-3 py-4"><div class="h-6 bg-slate-200 dark:bg-slate-700 rounded-lg w-16 mx-auto"></div></td>
                                <td class="px-3 py-4 hidden lg:table-cell"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-20 mx-auto"></div></td>
                                <td class="px-3 py-4"><div class="flex items-center justify-center gap-2"><div class="w-20 h-7 rounded-xl bg-slate-200 dark:bg-slate-700"></div><div class="w-8 h-7 rounded-xl bg-slate-200 dark:bg-slate-700"></div></div></td>
                            </tr>
                        @endfor
                    </tbody>
                </table>
            </div>

            <div class="mt-6">
                {{ $clients->links() }}
            </div>
        @endif
    </x-admin.card>
    @endif

    <!-- Add Client Modal -->
    <x-admin.modal name="add-client-modal" title="Add New Client" maxWidth="max-w-3xl">
        <div class="space-y-6 mt-2">
            
            <!-- Section 1: Profile & Basic Details -->
            <div class="space-y-4">
                <div class="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Basic Profile</h4>
                </div>

                <!-- Profile Image -->
                <div>
                    <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Profile Image') }}</label>
                    <div class="flex items-center gap-3">
                        @if ($profile_image)
                            <img src="{{ Str::startsWith($profile_image, 'http') ? $profile_image : asset('storage/' . $profile_image) }}" class="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/30 shadow-sm" onerror="this.outerHTML=`<div class='w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold'>{{ strtoupper(substr($name ?? 'C', 0, 2)) }}</div>`" />
                        @else
                            <div class="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 flex items-center justify-center text-slate-400">
                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                        @endif
                        
                        <button type="button" @click="Livewire.dispatch('open-media-picker', { field: 'profile_image' })" class="px-4 py-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:text-indigo-300 font-bold text-xs rounded-xl transition-colors border border-indigo-200/80 dark:border-indigo-800/60">
                            Choose from Media Library
                        </button>

                        @if ($profile_image)
                            <button type="button" wire:click="removeProfileImage" class="px-3 py-2 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 border border-red-200/60 dark:border-red-900/40 rounded-xl hover:bg-red-100 transition">
                                Remove
                            </button>
                        @endif
                    </div>
                    <x-input-error :messages="$errors->get('profile_image')" class="mt-1" />
                </div>

                <!-- 2-Column Grid: Name & Email -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label for="name" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Full Name') }}</label>
                        <input wire:model="name" id="name" type="text" required autocomplete="new-name" placeholder="e.g. John Doe"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('name')" class="mt-1" />
                    </div>

                    <div>
                        <label for="client_email" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Email Address') }}</label>
                        <input wire:model="email" id="client_email" type="email" required autocomplete="new-email" placeholder="john.doe@example.com"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('email')" class="mt-1" />
                    </div>
                </div>

                <!-- 2-Column Grid: Password & Company Name -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label for="client_password" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Password') }}</label>
                        <input wire:model="password" id="client_password" type="password" required autocomplete="new-password" placeholder="Min 8 characters"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('password')" class="mt-1" />
                    </div>

                    <div>
                        <label for="company_name" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Company Name') }}</label>
                        <input wire:model="company_name" id="company_name" type="text" placeholder="e.g. Acme Corp"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('company_name')" class="mt-1" />
                    </div>
                </div>
            </div>

            <!-- Section 2: Contact Numbers -->
            <div x-data="{
                    phones: $wire.entangle('phones'),
                    addPhone() {
                        if (!this.phones) this.phones = [];
                        if (this.phones.length < 5) {
                            this.phones.push({ label: 'Work', phone: '' });
                        }
                    },
                    removePhone(index) {
                        if (this.phones.length > 1) {
                            this.phones.splice(index, 1);
                        }
                    }
                 }" class="space-y-3 pt-2">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Phone Numbers</h4>
                    </div>
                    <template x-if="phones && phones.length < 5">
                        <button type="button" @click="addPhone()" class="text-xs font-bold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 transition flex items-center gap-1.5 active:scale-95">
                            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                            Add Phone
                        </button>
                    </template>
                    <template x-if="phones && phones.length >= 5">
                        <span class="text-[10px] font-semibold text-amber-500 flex items-center gap-1">
                            Max 5 reached
                        </span>
                    </template>
                </div>
                
                <div class="space-y-3">
                    <template x-for="(phoneItem, index) in phones" :key="index">
                        <div class="flex items-start gap-3">
                            <div class="w-1/3">
                                <select x-model="phoneItem.label" class="block w-full px-3 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 transition duration-150">
                                    <option value="Work">Work</option>
                                    <option value="Mobile">Mobile</option>
                                    <option value="Home">Home</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="flex-1">
                                <input x-model="phoneItem.phone" type="tel" placeholder="e.g. +1 555-0199" max="20" maxlength="20"
                                       oninput="this.value = this.value.replace(/[^0-9+\-\s()]/g, '')"
                                       class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                            </div>
                            <template x-if="phones.length > 1">
                                <button type="button" @click="removePhone(index)" class="p-2.5 text-slate-400 hover:text-red-500 dark:hover:text-red-400 transition-colors duration-150 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 self-center">
                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </template>
                        </div>
                    </template>
                </div>
            </div>

            <!-- Section 3: Account Assignment & Status -->
            <div class="space-y-4 pt-2">
                <div class="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Assignment & Plans</h4>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <!-- Assign Staff -->
                    <div>
                        <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Assign Account Manager</label>
                        <div class="grid grid-cols-1 gap-2 p-2 rounded-xl bg-slate-50/50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 max-h-36 overflow-y-auto custom-scrollbar">
                            @foreach($staffMembers as $staffOpt)
                                <label class="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 hover:border-indigo-300 dark:hover:border-indigo-600 transition duration-150 cursor-pointer">
                                    <input type="radio" wire:model="assigned_staff_id" value="{{ $staffOpt['id'] }}"
                                           class="rounded-full border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500/40">
                                    <div class="flex flex-col truncate">
                                        <span class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{{ $staffOpt['name'] }}</span>
                                        <span class="text-[10px] font-semibold text-slate-400 dark:text-slate-500 truncate">{{ $staffOpt['role'] ?: 'Staff Member' }}</span>
                                    </div>
                                </label>
                            @endforeach
                        </div>
                        <x-input-error :messages="$errors->get('assigned_staff_id')" class="mt-1" />
                    </div>

                    <!-- Plans Selection -->
                    <div>
                        <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Subscribed Plans</label>
                        <div class="grid grid-cols-1 gap-2 p-2 rounded-xl bg-slate-50/50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 max-h-36 overflow-y-auto custom-scrollbar">
                            @foreach($plans as $planOpt)
                                @php
                                    $pId = is_object($planOpt) ? $planOpt->id : (is_array($planOpt) ? ($planOpt['id'] ?? '') : $planOpt);
                                    $pName = is_object($planOpt) ? $planOpt->name : (is_array($planOpt) ? ($planOpt['name'] ?? '') : $planOpt);
                                @endphp
                                <label class="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 hover:border-indigo-300 dark:hover:border-indigo-600 transition duration-150 cursor-pointer">
                                    <input type="checkbox" wire:model="plan_ids" value="{{ $pId }}"
                                           class="rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500/40">
                                    <span class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{{ $pName }}</span>
                                </label>
                            @endforeach
                        </div>
                        <x-input-error :messages="$errors->get('plan_ids')" class="mt-1" />
                    </div>
                </div>

                <!-- Status Select -->
                <div>
                    <label for="client_status" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Account Status') }}</label>
                    <select wire:model="status" id="client_status" 
                            class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 transition duration-150">
                        <option value="active" class="dark:bg-slate-900">Active</option>
                        <option value="inactive" class="dark:bg-slate-900">Inactive</option>
                    </select>
                    <x-input-error :messages="$errors->get('status')" class="mt-1" />
                </div>
            </div>

            <!-- Section 4: Address Details -->
            <div class="space-y-4 pt-2">
                <div class="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Address Details</h4>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div class="md:col-span-2">
                        <label for="address" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Street Address</label>
                        <textarea wire:model="address" id="address" rows="2" placeholder="Street Address"
                                  class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150"></textarea>
                        <x-input-error :messages="$errors->get('address')" class="mt-1" />
                    </div>
                    <div>
                        <label for="landmark" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Landmark</label>
                        <input wire:model="landmark" id="landmark" type="text" placeholder="Near Hospital, Mall etc."
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('landmark')" class="mt-1" />
                    </div>
                    <div>
                        <label for="state" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">State / Province</label>
                        <input wire:model="state" id="state" type="text" placeholder="State/Province"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('state')" class="mt-1" />
                    </div>
                    <div>
                        <label for="country" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Country</label>
                        <input wire:model="country" id="country" type="text" placeholder="Country"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('country')" class="mt-1" />
                    </div>
                    <div>
                        <label for="region" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Region</label>
                        <input wire:model="region" id="region" type="text" placeholder="Region"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('region')" class="mt-1" />
                    </div>
                    <div>
                        <label for="zip_code" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Zip / Postal Code</label>
                        <input wire:model="zip_code" id="zip_code" type="text" placeholder="Postal Code"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('zip_code')" class="mt-1" />
                    </div>
                </div>
            </div>

            <!-- Section 5: Notes -->
            <div class="space-y-2 pt-2">
                <label for="notes" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Notes') }}</label>
                <textarea wire:model="notes" id="notes" rows="3" placeholder="Enter any additional details about the client..."
                          class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150"></textarea>
                <x-input-error :messages="$errors->get('notes')" class="mt-1" />
            </div>

            <!-- Actions Footer -->
            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button type="button" @click="$dispatch('close-modal', { name: 'add-client-modal' })" 
                        class="px-4 py-2.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition-all duration-150">
                    Cancel
                </button>
                <x-admin.button type="button" wire:click="saveClient" size="sm" variant="primary" wire:loading.attr="disabled" class="space-x-1.5">
                    <svg wire:loading wire:target="saveClient" class="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Save Client</span>
                </x-admin.button>
            </div>
        </div>
    </x-admin.modal>

    <!-- Edit Client Modal -->
    <x-admin.modal name="edit-client-modal" title="Edit Client" maxWidth="max-w-3xl">
        <div class="space-y-6 mt-2">
            
            <!-- Section 1: Profile & Basic Details -->
            <div class="space-y-4">
                <div class="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Basic Profile</h4>
                </div>

                <!-- Profile Image -->
                <div x-data="{
                    get imgUrl() {
                        const path = $wire.profile_image || $wire.existing_profile_image;
                        if (!path) return '';
                        if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('/')) {
                            return path;
                        }
                        return '/storage/' + path;
                    }
                }">
                    <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Profile Image') }}</label>
                    <div class="flex items-center gap-3">
                        <template x-if="imgUrl">
                            <img :src="imgUrl" class="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/30 shadow-sm" />
                        </template>
                        <template x-if="!imgUrl">
                            <div class="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 flex items-center justify-center text-slate-400">
                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                        </template>
                        
                        <button type="button" @click="Livewire.dispatch('open-media-picker', { field: 'profile_image' })" class="px-4 py-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:text-indigo-300 font-bold text-xs rounded-xl transition-colors border border-indigo-200/80 dark:border-indigo-800/60">
                            Choose from Media Library
                        </button>

                        <template x-if="imgUrl">
                            <button type="button" @click="$wire.profile_image = ''; $wire.existing_profile_image = '';" class="px-3 py-2 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 border border-red-200/60 dark:border-red-900/40 rounded-xl hover:bg-red-100 transition">
                                Remove
                            </button>
                        </template>
                    </div>
                    <x-input-error :messages="$errors->get('profile_image')" class="mt-1" />
                </div>

                <!-- 2-Column Grid: Name & Email -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label for="edit_name" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Full Name') }}</label>
                        <input wire:model="name" id="edit_name" type="text" required placeholder="e.g. John Doe"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('name')" class="mt-1" />
                    </div>

                    <div>
                        <label for="edit_client_email" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Email Address') }}</label>
                        <input wire:model="email" id="edit_client_email" type="email" required placeholder="john.doe@example.com"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('email')" class="mt-1" />
                    </div>
                </div>

                <!-- 2-Column Grid: Password & Company Name -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label for="edit_client_password" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Password (Leave blank to keep current)') }}</label>
                        <input wire:model="password" id="edit_client_password" type="password" placeholder="Min 8 characters" autocomplete="new-password"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('password')" class="mt-1" />
                    </div>

                    <div>
                        <label for="edit_company_name" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Company Name') }}</label>
                        <input wire:model="company_name" id="edit_company_name" type="text" placeholder="e.g. Acme Corp"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('company_name')" class="mt-1" />
                    </div>
                </div>
            </div>

            <!-- Section 2: Contact Numbers -->
            <div x-data="{
                    phones: $wire.entangle('phones'),
                    addPhone() {
                        if (!this.phones) this.phones = [];
                        if (this.phones.length < 5) {
                            this.phones.push({ label: 'Work', phone: '' });
                        }
                    },
                    removePhone(index) {
                        if (this.phones.length > 1) {
                            this.phones.splice(index, 1);
                        }
                    }
                 }" class="space-y-3 pt-2">
                <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-2">
                        <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Phone Numbers</h4>
                    </div>
                    <template x-if="phones && phones.length < 5">
                        <button type="button" @click="addPhone()" class="text-xs font-bold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 transition flex items-center gap-1.5 active:scale-95">
                            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" /></svg>
                            Add Phone
                        </button>
                    </template>
                    <template x-if="phones && phones.length >= 5">
                        <span class="text-[10px] font-semibold text-amber-500 flex items-center gap-1">
                            Max 5 reached
                        </span>
                    </template>
                </div>
                
                <div class="space-y-3">
                    <template x-for="(phoneItem, index) in phones" :key="index">
                        <div class="flex items-start gap-3">
                            <div class="w-1/3">
                                <select x-model="phoneItem.label" class="block w-full px-3 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 transition duration-150">
                                    <option value="Work">Work</option>
                                    <option value="Mobile">Mobile</option>
                                    <option value="Home">Home</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="flex-1">
                                <input x-model="phoneItem.phone" type="tel" placeholder="e.g. +1 555-0199" max="20" maxlength="20"
                                       oninput="this.value = this.value.replace(/[^0-9+\-\s()]/g, '')"
                                       class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                            </div>
                            <template x-if="phones.length > 1">
                                <button type="button" @click="removePhone(index)" class="p-2.5 text-slate-400 hover:text-red-500 dark:hover:text-red-400 transition-colors duration-150 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 self-center">
                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </template>
                        </div>
                    </template>
                </div>
            </div>

            <!-- Section 3: Account Assignment & Status -->
            <div class="space-y-4 pt-2">
                <div class="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Assignment & Plans</h4>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <!-- Assign Staff -->
                    <div>
                        <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Assign Account Manager</label>
                        <div class="grid grid-cols-1 gap-2 p-2 rounded-xl bg-slate-50/50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 max-h-36 overflow-y-auto custom-scrollbar">
                            @foreach($staffMembers as $staffOpt)
                                <label class="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 hover:border-indigo-300 dark:hover:border-indigo-600 transition duration-150 cursor-pointer">
                                    <input type="radio" wire:model="assigned_staff_id" value="{{ $staffOpt['id'] }}"
                                           class="rounded-full border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500/40">
                                    <div class="flex flex-col truncate">
                                        <span class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{{ $staffOpt['name'] }}</span>
                                        <span class="text-[10px] font-semibold text-slate-400 dark:text-slate-500 truncate">{{ $staffOpt['role'] ?: 'Staff Member' }}</span>
                                    </div>
                                </label>
                            @endforeach
                        </div>
                        <x-input-error :messages="$errors->get('assigned_staff_id')" class="mt-1" />
                    </div>

                    <!-- Plans Selection -->
                    <div>
                        <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Subscribed Plans</label>
                        <div class="grid grid-cols-1 gap-2 p-2 rounded-xl bg-slate-50/50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 max-h-36 overflow-y-auto custom-scrollbar">
                            @foreach($plans as $planOpt)
                                @php
                                    $pId = is_object($planOpt) ? $planOpt->id : (is_array($planOpt) ? ($planOpt['id'] ?? '') : $planOpt);
                                    $pName = is_object($planOpt) ? $planOpt->name : (is_array($planOpt) ? ($planOpt['name'] ?? '') : $planOpt);
                                @endphp
                                <label class="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 hover:border-indigo-300 dark:hover:border-indigo-600 transition duration-150 cursor-pointer">
                                    <input type="checkbox" wire:model="plan_ids" value="{{ $pId }}"
                                           class="rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500/40">
                                    <span class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{{ $pName }}</span>
                                </label>
                            @endforeach
                        </div>
                        <x-input-error :messages="$errors->get('plan_ids')" class="mt-1" />
                    </div>
                </div>

                <!-- Status Select -->
                <div>
                    <label for="edit_client_status" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Account Status') }}</label>
                    <select wire:model="status" id="edit_client_status" 
                            class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 transition duration-150">
                        <option value="active" class="dark:bg-slate-900">Active</option>
                        <option value="inactive" class="dark:bg-slate-900">Inactive</option>
                    </select>
                    <x-input-error :messages="$errors->get('status')" class="mt-1" />
                </div>
            </div>

            <!-- Section 4: Address Details -->
            <div class="space-y-4 pt-2">
                <div class="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <svg class="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <h4 class="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">Address Details</h4>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div class="md:col-span-2">
                        <label for="edit_address" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Street Address</label>
                        <textarea wire:model="address" id="edit_address" rows="2" placeholder="Street Address"
                                  class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150"></textarea>
                        <x-input-error :messages="$errors->get('address')" class="mt-1" />
                    </div>
                    <div>
                        <label for="edit_landmark" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Landmark</label>
                        <input wire:model="landmark" id="edit_landmark" type="text" placeholder="Near Hospital, Mall etc."
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('landmark')" class="mt-1" />
                    </div>
                    <div>
                        <label for="edit_state" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">State / Province</label>
                        <input wire:model="state" id="edit_state" type="text" placeholder="State/Province"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('state')" class="mt-1" />
                    </div>
                    <div>
                        <label for="edit_country" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Country</label>
                        <input wire:model="country" id="edit_country" type="text" placeholder="Country"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('country')" class="mt-1" />
                    </div>
                    <div>
                        <label for="edit_region" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Region</label>
                        <input wire:model="region" id="edit_region" type="text" placeholder="Region"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('region')" class="mt-1" />
                    </div>
                    <div>
                        <label for="edit_zip_code" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Zip / Postal Code</label>
                        <input wire:model="zip_code" id="edit_zip_code" type="text" placeholder="Postal Code"
                               class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150" />
                        <x-input-error :messages="$errors->get('zip_code')" class="mt-1" />
                    </div>
                </div>
            </div>

            <!-- Section 5: Notes -->
            <div class="space-y-2 pt-2">
                <label for="edit_notes" class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">{{ __('Notes') }}</label>
                <textarea wire:model="notes" id="edit_notes" rows="3" placeholder="Enter any additional details about the client..."
                          class="block w-full px-4 py-2.5 rounded-xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 text-sm font-semibold transition duration-150"></textarea>
                <x-input-error :messages="$errors->get('notes')" class="mt-1" />
            </div>

            <!-- Actions Footer -->
            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button type="button" @click="$dispatch('close-modal', { name: 'edit-client-modal' })" 
                        class="px-4 py-2.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition-all duration-150">
                    Cancel
                </button>
                <x-admin.button type="button" wire:click="updateClient" size="sm" variant="primary" wire:loading.attr="disabled" class="space-x-1.5">
                    <svg wire:loading wire:target="updateClient" class="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Update Client</span>
                </x-admin.button>
            </div>
        </div>
    </x-admin.modal>

    <!-- ClickUp Folder Mapping Modal -->
    @php
        $formattedFolders = $allClickUpFolders->map(function($f) {
            return [
                'id' => (string) $f->id,
                'name' => $f->name,
                'clickup_space_id' => (string) $f->clickup_space_id,
                'client_id' => $f->client_id ? (string) $f->client_id : null,
                'client_name' => $f->client ? ($f->client->company_name ?: ($f->client->user->name ?? 'Client #'.$f->client_id)) : null,
            ];
        })->values()->toArray();

        $formattedSpaces = $clickUpSpaces->map(function($s) {
            return [
                'id' => (string) $s->id,
                'name' => $s->name,
                'color' => $s->color ?: '#135266',
                'folders_count' => $s->folders_count ?? count($s->folders),
            ];
        })->values()->toArray();
    @endphp

    <x-admin.modal name="clickup-client-mapping-modal" title="Map ClickUp Folders to Client" maxWidth="max-w-3xl">
        <div x-data="{
                mappingClient: null,
                clickUpSpaceId: '',
                clickUpFolderSearch: '',
                selectedClickUpFolderIds: [],
                allFolders: {{ Js::from($formattedFolders) }},
                clickUpSpaces: {{ Js::from($formattedSpaces) }},

                get filteredFolders() {
                    if (!this.clickUpSpaceId) return [];
                    const search = this.clickUpFolderSearch.trim().toLowerCase();
                    return this.allFolders.filter(f => {
                        const spaceMatch = String(f.clickup_space_id) === String(this.clickUpSpaceId);
                        const searchMatch = !search || f.name.toLowerCase().includes(search);
                        return spaceMatch && searchMatch;
                    });
                },

                toggleFolder(folderId) {
                    const idStr = String(folderId);
                    const idx = this.selectedClickUpFolderIds.indexOf(idStr);
                    if (idx > -1) {
                        this.selectedClickUpFolderIds.splice(idx, 1);
                    } else {
                        this.selectedClickUpFolderIds.push(idStr);
                    }
                },

                saveMapping() {
                    if (!this.mappingClient) return;
                    $wire.saveClickUpMapping(this.mappingClient.id, this.selectedClickUpFolderIds);
                }
             }"
             @open-clickup-modal.window="
                mappingClient = $event.detail.client;
                selectedClickUpFolderIds = ($event.detail.folderIds || []).map(String);
                clickUpFolderSearch = '';

                let autoSpaceId = '';
                if (selectedClickUpFolderIds.length > 0) {
                    const assignedFolder = allFolders.find(f => selectedClickUpFolderIds.includes(String(f.id)));
                    if (assignedFolder && assignedFolder.clickup_space_id) {
                        autoSpaceId = String(assignedFolder.clickup_space_id);
                    }
                }
                if (!autoSpaceId && clickUpSpaces.length > 0) {
                    autoSpaceId = String(clickUpSpaces[0].id);
                }
                clickUpSpaceId = autoSpaceId;
             ">
            
            <template x-if="mappingClient">
                <div class="space-y-5">
                    <!-- Client Header Banner -->
                    <div class="bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-[#135266]/10 text-[#135266] dark:bg-[#135266]/30 dark:text-teal-300 flex items-center justify-center font-bold text-sm"
                                 x-text="mappingClient.initials || 'CL'">
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-800 dark:text-white text-base" x-text="mappingClient.company_name || mappingClient.name || 'Client'">
                                </h4>
                                <p class="text-xs text-slate-400 dark:text-slate-400">
                                    <span x-text="mappingClient.name"></span> (<span x-text="mappingClient.email"></span>)
                                </p>
                            </div>
                        </div>

                        <button type="button" wire:click="syncClickUpApi" wire:loading.attr="disabled"
                                class="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-200/70 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition">
                            <svg wire:loading.class="animate-spin" wire:target="syncClickUpApi" class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                            </svg>
                            <span wire:loading.remove wire:target="syncClickUpApi">Sync ClickUp API</span>
                            <span wire:loading wire:target="syncClickUpApi">Syncing...</span>
                        </button>
                    </div>

                    <!-- ClickUp Spaces Selection Grid -->
                    <div class="space-y-2.5">
                        <div class="flex items-center justify-between">
                            <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                                <svg class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                                </svg>
                                Select ClickUp Space
                            </label>
                            <span class="text-[10px] font-extrabold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-2.5 py-0.5 rounded-full border border-slate-200/60 dark:border-slate-700/60"
                                  x-text="(clickUpSpaces.length || 0) + ' Spaces'">
                            </span>
                        </div>

                        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-52 overflow-y-auto pr-1 custom-scrollbar">
                            <template x-for="space in clickUpSpaces" :key="space.id">
                                <button type="button" 
                                        @click="clickUpSpaceId = space.id"
                                        :class="clickUpSpaceId === space.id ? 'bg-gradient-to-br from-indigo-50/90 to-slate-50 dark:from-slate-800 dark:to-slate-850 border-indigo-500 dark:border-indigo-400 shadow-md ring-2 ring-indigo-500/20' : 'bg-white dark:bg-slate-800/70 border-slate-200/80 dark:border-slate-700/70 hover:border-indigo-300 dark:hover:border-indigo-600 hover:shadow-sm'"
                                        class="group relative text-left p-3 rounded-2xl border transition-all duration-200 flex flex-col justify-between gap-2.5 overflow-hidden">
                                    
                                    <div class="flex items-start justify-between gap-1.5">
                                        <div class="flex items-center gap-2 min-w-0">
                                            <span class="w-3 h-3 rounded-full shrink-0 shadow-sm border border-black/10" :style="'background-color: ' + space.color"></span>
                                            <h5 class="text-xs font-bold truncate transition-colors"
                                                :class="clickUpSpaceId === space.id ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400'"
                                                x-text="space.name">
                                            </h5>
                                        </div>
                                        <template x-if="clickUpSpaceId === space.id">
                                            <span class="w-4 h-4 rounded-full bg-indigo-600 text-white text-[9px] font-black flex items-center justify-center shrink-0 shadow-sm">✓</span>
                                        </template>
                                    </div>

                                    <div class="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-400 font-medium pt-1.5 border-t border-slate-100 dark:border-slate-750/50">
                                        <span class="flex items-center gap-1 font-semibold">
                                            <svg class="w-3 h-3 text-amber-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                            </svg>
                                            <span x-text="space.folders_count + ' folders'"></span>
                                        </span>
                                        <template x-if="clickUpSpaceId === space.id">
                                            <span class="text-indigo-600 dark:text-indigo-400 font-extrabold uppercase tracking-wider text-[9px]">Selected</span>
                                        </template>
                                    </div>
                                </button>
                            </template>
                        </div>
                    </div>

                    <!-- Folders Live Search Input -->
                    <template x-if="clickUpSpaceId">
                        <div class="relative">
                            <svg class="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                            <input x-model="clickUpFolderSearch"
                                   type="text"
                                   placeholder="Search ClickUp folder name in this space..."
                                   class="block w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#135266]/40 focus:border-[#135266]" />
                        </div>
                    </template>

                    <!-- Folders List Container with Checkboxes -->
                    <div class="border border-slate-200/80 dark:border-slate-700/80 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
                        <div class="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 custom-scrollbar">
                            <template x-if="!clickUpSpaceId">
                                <div class="px-6 py-10 text-center">
                                    <svg class="w-10 h-10 text-[#135266]/40 dark:text-teal-500/40 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                                    </svg>
                                    <p class="text-xs font-bold text-slate-700 dark:text-slate-300">No Space Selected</p>
                                    <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">Please click on a ClickUp Space tab above to view and assign folders.</p>
                                </div>
                            </template>
                            <template x-if="clickUpSpaceId">
                                <div>
                                    <template x-for="folder in filteredFolders" :key="folder.id">
                                        <label class="flex items-center justify-between px-4 py-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 cursor-pointer transition"
                                               :class="selectedClickUpFolderIds.includes(String(folder.id)) ? 'bg-indigo-50/40 dark:bg-indigo-950/20' : ''">
                                            <div class="flex items-center gap-3">
                                                <input type="checkbox"
                                                       @change="toggleFolder(folder.id)"
                                                       :checked="selectedClickUpFolderIds.includes(String(folder.id))"
                                                       class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-[#135266] focus:ring-[#135266]/40 focus:ring-2 cursor-pointer" />
                                                
                                                <div>
                                                    <div class="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                                                        <svg class="w-4 h-4 text-amber-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                        </svg>
                                                        <span x-text="folder.name"></span>
                                                    </div>
                                                    <div class="text-[11px] text-slate-400 font-mono" x-text="'ID: ' + folder.id"></div>
                                                </div>
                                            </div>

                                            <!-- Status Badge -->
                                            <div>
                                                <template x-if="selectedClickUpFolderIds.includes(String(folder.id))">
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                                        Assigned to this Client
                                                    </span>
                                                </template>
                                                <template x-if="mappingClient && !selectedClickUpFolderIds.includes(String(folder.id)) && folder.client_id && folder.client_id !== String(mappingClient.id)">
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400" :title="'Assigned to ' + folder.client_name">
                                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                                        <span x-text="'Assigned: ' + folder.client_name"></span>
                                                    </span>
                                                </template>
                                                <template x-if="mappingClient && !selectedClickUpFolderIds.includes(String(folder.id)) && (!folder.client_id || folder.client_id === String(mappingClient.id))">
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                                                        Unassigned
                                                    </span>
                                                </template>
                                            </div>
                                        </label>
                                    </template>
                                    <template x-if="filteredFolders.length === 0">
                                        <div class="px-6 py-8 text-center text-slate-400 dark:text-slate-500 text-xs">
                                            No ClickUp folders found in this space matching your search.
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    <!-- Footer Summary & Actions -->
                    <div class="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                        <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            Selected <span class="font-extrabold text-[#135266] dark:text-teal-400" x-text="selectedClickUpFolderIds.length"></span> folder(s) for this client
                        </div>

                        <div class="flex items-center gap-3">
                            <template x-if="mappingClient && selectedClickUpFolderIds.length > 0">
                                <button type="button" 
                                        @click="if (confirm('Are you sure you want to disconnect ClickUp from ' + (mappingClient.company_name || mappingClient.name) + '?')) { $wire.disconnectClickUpMapping(mappingClient.id); }"
                                        class="px-4 py-2 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-800/40 hover:bg-rose-100 dark:hover:bg-rose-500/20 transition duration-150">
                                    Disconnect ClickUp
                                </button>
                            </template>

                            <button type="button" @click="$dispatch('close-modal', { name: 'clickup-client-mapping-modal' })"
                                    class="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition duration-150">
                                Cancel
                            </button>

                            <button type="button" @click="saveMapping()"
                                    class="px-5 py-2 bg-[#135266] hover:bg-[#0f4152] text-white text-xs font-bold rounded-xl shadow transition duration-150">
                                Save ClickUp Mapping
                            </button>
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </x-admin.modal>
</div>
