<?php

namespace App\Modules\CRM\Clients\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Url;
use App\Modules\CRM\Clients\Models\Client;
use App\Modules\CRM\Websites\Models\Website;
use App\Traits\LoadsMarketingReports;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

#[Layout('layouts.admin')]
class AdminClientReport extends Component
{
    use LoadsMarketingReports;

    public int $clientId = 0;
    #[Url]
    public int $websiteId = 0;
    public string $integration = '';

    public array $activeReportData = [];
    public string $activeReportIntegrationId = '';
    public string $activeReportPropertyId = '';

    public ?Client $client = null;
    public ?Website $website = null;
    public string $clientName = '';
    public string $websiteName = '';
    public bool $hideHeader = false;

    public function mount(
        int $id, 
        string $integration, 
        $websiteId = null, 
        bool $hideHeader = false, 
        ?string $dateFrom = null, 
        ?string $dateTo = null,
        ?string $compareDateFrom = null,
        ?string $compareDateTo = null
    ): void
    {
        $this->clientId = $id;
        $this->integration = $integration;
        $this->activeReportIntegrationId = $integration;
        $this->websiteId = $websiteId ?? (int) request('website', 0);
        $this->hideHeader = $hideHeader;

        // Prioritize explicit date parameters passed from parent, then request, then session, then default
        if (!empty($dateFrom)) {
            $this->dateFrom = $dateFrom;
            session(['marketing_date_from' => $dateFrom]);
        } elseif (empty($this->dateFrom)) {
            $this->dateFrom = request('from', session('marketing_date_from', Carbon::now()->subDays(28)->format('Y-m-d')));
        }

        if (!empty($dateTo)) {
            $this->dateTo = $dateTo;
            session(['marketing_date_to' => $dateTo]);
        } elseif (empty($this->dateTo)) {
            $this->dateTo = request('to', session('marketing_date_to', Carbon::now()->subDays(1)->format('Y-m-d')));
        }

        if ($compareDateFrom !== null) {
            $this->compareDateFrom = $compareDateFrom;
        } elseif (empty($this->compareDateFrom)) {
            $this->compareDateFrom = request('cfrom', '');
        }

        if ($compareDateTo !== null) {
            $this->compareDateTo = $compareDateTo;
        } elseif (empty($this->compareDateTo)) {
            $this->compareDateTo = request('cto', '');
        }

        if (empty($this->compareFormat)) $this->compareFormat = request('format', 'percentage');

        $this->initDateRange();

        $this->loadReport();
    }

    public function updatedDateFrom(): void { $this->initDateRange(); $this->loadReport(); }
    public function updatedDateTo(): void { $this->initDateRange(); $this->loadReport(); }
    public function updatedCompareDateFrom(): void { $this->loadReport(); }
    public function updatedCompareDateTo(): void { $this->loadReport(); }
    public function updatedCompareFormat(): void { } // re-render only

    #[\Livewire\Attributes\On('update-report-dates')]
    public function onUpdateReportDates(string $dateFrom, string $dateTo): void
    {
        $this->dateFrom = $dateFrom;
        $this->dateTo = $dateTo;
        $this->initDateRange();
        $this->loadReport();
    }

    public function loadReport(): void
    {
        try {
            $this->client = Client::with('user')->findOrFail($this->clientId);
            $this->clientName = $this->client->user->name ?? 'Client';

            if ($this->websiteId) {
                $this->website = Website::where('client_id', $this->clientId)->where('id', $this->websiteId)->first();
            }
            if (!$this->website) {
                $websites = Website::where('client_id', $this->clientId)->get();
                $this->website = $websites->first();
            }

            if ($this->website) {
                $this->websiteName = $this->website->site_name ?? '';
                
                $integrationRecord = \App\Modules\CRM\Websites\Models\WebsiteIntegration::where('website_id', $this->website->id)
                    ->where('integration_type', $this->integration)
                    ->first();
                    
                if ($integrationRecord) {
                    $creds = $integrationRecord->auth_credentials ?? [];
                    $this->activeReportPropertyId = $creds['property_id'] ?? ($creds['site_url'] ?? ($creds['channel_id'] ?? ($creds['project_id'] ?? ($creds['container_id'] ?? ($creds['location_id'] ?? '')))));
                } else {
                    $integrations = json_decode($this->website->integrations ?? '[]', true);
                    foreach ($integrations as $intg) {
                        if (($intg['id'] ?? '') === $this->integration && !empty($intg['property_id'])) {
                            $this->activeReportPropertyId = $intg['property_id'] ?? '';
                            break;
                        }
                    }
                }
            }

            if (!$this->website) return;

            $userName = Str::slug(Str::lower($this->client->user->name ?? 'client'));
            $emailParts = explode('@', $this->client->user->email ?? '');
            $emailPrefix = Str::slug(Str::lower($emailParts[0] ?? ''));
            $clientFolder = "{$userName}-{$emailPrefix}";

            $websiteFolder = Str::slug(Str::lower($this->website->site_name ?? ''));
            if (empty($websiteFolder)) {
                $websiteFolder = 'site-' . $this->website->id;
            }

            $this->activeReportData = $this->loadIntegrationJsonData($clientFolder, $websiteFolder, $this->integration, $this->dateFrom, $this->dateTo);

            if (!empty($this->compareDateFrom) && !empty($this->compareDateTo)) {
                $compareData = $this->loadIntegrationJsonData($clientFolder, $websiteFolder, $this->integration, $this->compareDateFrom, $this->compareDateTo);
                $this->activeReportData['compare_summary'] = $compareData['overall_summary'] ?? ($compareData['summary'] ?? []);
                $this->activeReportData['compare_data'] = $compareData;
            }

            $this->syncDefaultReportModalData();

        } catch (\Exception $e) {
            Log::error('AdminClientReport: Error loading report: ' . $e->getMessage());
        }
    }

    public function render()
    {
        if (empty($this->activeReportData)) {
            $this->loadReport();
        }

        return view('modules.crm.clients.client-report', [
            'client' => $this->client,
            'website' => $this->website,
            'pageTitle' => $this->clientName . ' — ' . strtoupper($this->integration) . ' Report',
            'activeReportData' => $this->activeReportData,
        ]);
    }
}
