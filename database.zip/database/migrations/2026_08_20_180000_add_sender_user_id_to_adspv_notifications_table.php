<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('adspv_notifications', function (Blueprint $table) {
            $table->foreignId('sender_user_id')->nullable()->after('sender_type')->constrained('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::table('adspv_notifications', function (Blueprint $table) {
            $table->dropForeign(['sender_user_id']);
            $table->dropColumn('sender_user_id');
        });
    }
};
