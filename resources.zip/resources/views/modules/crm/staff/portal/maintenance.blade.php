@section('page_title', 'Maintenance Reports')

<div>
    {{-- Breadcrumbs --}}
    <x-admin.breadcrumbs :items="['Maintenance Reports' => null]" />

    {{-- Page Header --}}
    <div class="flex items-center justify-between gap-4 mb-5">
        <p class="text-xs text-slate-400 dark:text-slate-500 font-medium">
            Manage, review, and compile monthly website maintenance reports for your assigned clients
        </p>

        <a href="{{ route('staff.maintenance.create') }}"
           class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white text-sm font-semibold shadow-sm transition-all duration-150 active:scale-95 shrink-0 whitespace-nowrap">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" />
            </svg>
            Add New Report
        </a>
    </div>

    {{-- Summary Statistics Grid --}}
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {{-- Card 1: Total Reports --}}
        <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
            <div>
                <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Total Reports</p>
                <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $totalReportsCount }}</h3>
            </div>
            <div class="p-3 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-500 rounded-xl">
                <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
            </div>
        </div>

        {{-- Card 2: Completed --}}
        <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
            <div>
                <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Completed</p>
                <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $completedReportsCount }}</h3>
            </div>
            <div class="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500 rounded-xl">
                <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
        </div>

        {{-- Card 3: Pending --}}
        <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
            <div>
                <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Pending (Draft)</p>
                <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $pendingReportsCount }}</h3>
            </div>
            <div class="p-3 bg-amber-50 dark:bg-amber-950/20 text-amber-500 rounded-xl">
                <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
        </div>
    </div>

    {{-- Filter panel --}}
    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-4 mb-5 shadow-sm">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {{-- Search input --}}
            <div class="relative flex items-center col-span-1">
                <svg wire:loading.remove wire:target="search" class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <div wire:loading wire:target="search" class="absolute left-3 pointer-events-none shrink-0 z-10 flex items-center">
                    <svg class="animate-spin w-4 h-4 text-pink-500" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                </div>
                <input wire:model.live.debounce.300ms="search" type="text" placeholder="Search report, client, web..."
                       class="block w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 text-sm transition duration-150" />
            </div>

            {{-- Client Filter --}}
            <div class="relative flex items-center">
                <select wire:model.live="clientFilter" class="block w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 transition duration-150">
                    <option value="">All Clients</option>
                    @foreach($clients as $c)
                        <option value="{{ $c->id }}">{{ $c->company_name }}</option>
                    @endforeach
                </select>
            </div>

            {{-- Status Filter --}}
            <div class="relative flex items-center">
                <select wire:model.live="statusFilter" class="block w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 transition duration-150">
                    <option value="">All Statuses</option>
                    <option value="draft">Draft</option>
                    <option value="completed">Completed</option>
                </select>
            </div>

            {{-- Month Filter --}}
            <div class="relative flex items-center">
                <select wire:model.live="monthFilter" class="block w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 transition duration-150">
                    <option value="">All Months</option>
                    @foreach($availableMonths as $month)
                        <option value="{{ $month }}">{{ $month }}</option>
                    @endforeach
                </select>
            </div>

            {{-- Send Status Filter --}}
            <div class="relative flex items-center">
                <select wire:model.live="sendFilter" class="block w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-400 transition duration-150">
                    <option value="">All Send Status</option>
                    <option value="sent">Sent</option>
                    <option value="unsent">Unsent</option>
                </select>
            </div>

            {{-- Per Page Filter --}}
            <div class="relative flex items-center">
                <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                </svg>
                <select wire:model.live="perPage" class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/50 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 transition duration-150 appearance-none cursor-pointer">
                    <option value="20" class="dark:bg-slate-900">20 per page</option>
                    <option value="50" class="dark:bg-slate-900">50 per page</option>
                    <option value="100" class="dark:bg-slate-900">100 per page</option>
                </select>
                <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </div>

            {{-- Tag / Priority Filter --}}
            <div class="relative flex items-center">
                <select wire:model.live="tagFilter" class="block w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 transition duration-150">
                    <option value="">All Tags / Priority</option>
                    <option value="normal">Normal</option>
                    <option value="warning">Warning</option>
                    <option value="critical">Critical</option>
                </select>
            </div>
        </div>

        @if($hasActiveFilters)
            <div class="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between">
                <span class="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
                    <svg class="w-3.5 h-3.5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Filters active — showing filtered reports
                </span>
                <button type="button" wire:click="clearFilters"
                        class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 dark:bg-red-500/10 text-red-650 dark:text-red-400 border border-red-200/60 dark:border-red-800/30 hover:bg-red-100 dark:hover:bg-red-500/20 text-xs font-bold transition-all duration-150 active:scale-95">
                    Clear Filters
                </button>
            </div>
        @endif
    </div>    {{-- Reports Data Table --}}
    <x-admin.card class="relative">
        {{-- Skeleton Loader for Entire Card (Shown while any filter is loading) --}}
        <div wire:loading wire:target="search, clientFilter, websiteFilter, statusFilter, tagFilter, monthFilter, sendFilter, perPage, nextPage, previousPage, gotoPage, clearFilters" class="w-full">
            <div id="staffMaintenanceReportsTableLoading" class="overflow-x-auto rounded-2xl border border-slate-200/50 dark:border-slate-800/50">
                <table class="w-full text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                    <thead>
                        <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-bse !font-normal text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                            <th class="px-4 py-4 font-semibold text-left">Report ID</th>
                            <th class="px-4 py-4 font-semibold text-left">Client</th>
                            <th class="px-4 py-4 font-semibold text-left">Website</th>
                            <th class="px-4 py-4 font-semibold text-left">Month</th>
                            <th class="px-4 py-4 font-semibold text-left">Developer</th>
                            <th class="px-4 py-4 font-semibold text-left">Status</th>
                            <th class="px-4 py-4 font-semibold text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                        @for($i = 0; $i < min($perPage, 10); $i++)
                            <tr class="animate-pulse bg-white/20 dark:bg-slate-900/5">
                                <td class="px-4 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-12"></div></td>
                                <td class="px-4 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-32 mb-2"></div><div class="h-3 bg-slate-200 dark:bg-slate-700 rounded w-24"></div></td>
                                <td class="px-4 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-32 mb-2"></div><div class="h-3 bg-slate-200 dark:bg-slate-700 rounded w-48"></div></td>
                                <td class="px-4 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-24"></div></td>
                                <td class="px-4 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-24"></div></td>
                                <td class="px-4 py-4"><div class="h-6 bg-slate-200 dark:bg-slate-700 rounded-lg w-20"></div></td>
                                <td class="px-4 py-4"><div class="flex items-center justify-center gap-1.5"><div class="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-700"></div><div class="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-700"></div><div class="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-700"></div><div class="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-700"></div><div class="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-700"></div></div></td>
                            </tr>
                        @endfor
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Actual Content (Hidden while any filter is loading) --}}
        <div wire:loading.remove wire:target="search, clientFilter, websiteFilter, statusFilter, tagFilter, monthFilter, sendFilter, perPage, nextPage, previousPage, gotoPage, clearFilters">
            @if($reports->isEmpty())
                <div class="text-center py-16">
                    <svg class="w-14 h-14 text-slate-300 dark:text-slate-700 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <h3 class="text-base font-bold text-slate-800 dark:text-slate-300 mb-1">No Reports Found</h3>
                    <p class="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">Create a monthly audit report for your assigned client sites.</p>
                </div>
            @else
                <div id="staffMaintenanceReportsTableTop" class="overflow-x-auto rounded-2xl border border-slate-200/50 dark:border-slate-800/50" x-data="{
                    init() {
                        Livewire.on('scroll-to-top', () => {
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                        });
                    }
                }">
                    <table class="w-full text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                        <thead>
                            <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-base font-normal text-slate-400 dark:text-slate-500 capitalize tracking-wider">
                                <th class="px-4 py-4 font-semibold text-left">Report ID</th>
                                <th class="px-4 py-4 font-semibold text-left">Client</th>
                                <th class="px-4 py-4 font-semibold text-left">Website</th>
                                <th class="px-4 py-4 font-semibold text-left">Month</th>
                                <th class="px-4 py-4 font-semibold text-left">Developer</th>
                                <th class="px-4 py-4 font-semibold text-left">Status</th>
                                <th class="px-4 py-4 font-semibold text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-base">
                    @foreach($reports as $report)
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                            <td class="px-4 py-4 font-bold text-slate-900 dark:text-white text-sm">
                                #{{ $report->id }}
                            </td>
                            <td class="px-4 py-4">
                                <a href="{{ route('staff.clients.detail', ['id' => $report->client->id]) }}" wire:navigate class="no-underline group">
                                    <div class="font-semibold text-slate-800 dark:text-slate-200 group-hover:text-indigo-650 dark:group-hover:text-indigo-400">
                                        {{ $report->client->user->name }}
                                    </div>
                                    <div class="text-sm text-slate-400 dark:text-slate-500">
                                        {{ $report->client->company_name }}
                                    </div>
                                </a>
                            </td>
                            <td class="px-4 py-4">
                                <div class="font-semibold">
                                    <a href="{{ route('staff.websites.detail', ['id' => $report->website_id]) }}" wire:navigate class="text-slate-800 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                        {{ $report->website->site_name }}
                                    </a>
                                </div>
                                <div class="text-sm mt-0.5 text-indigo-500 hover:text-indigo-600 dark:text-indigo-400 dark:hover:text-indigo-300 font-medium underline">
                                    <a href="{{ $report->website->url }}" target="_blank">{{ $report->website->url }}</a>
                                </div>
                            </td>
                            <td class="px-4 py-4 text-slate-550 dark:text-slate-400 font-semibold text-sm">
                                {{ $report->maintenance_month }}
                            </td>
                            <td class="px-4 py-4 text-slate-600 dark:text-slate-300 text-sm">
                                {{ $report->developer->name }}
                            </td>
                            <td class="px-4 py-4">
                                <div class="flex items-center gap-1.5 flex-wrap">
                                    <span class="px-2.5 py-1 text-[10px] font-extrabold rounded-lg uppercase tracking-wider
                                          {{ $report->status === 'completed'
                                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                              : 'bg-amber-500/10 text-amber-600 dark:text-amber-400' }}">
                                        {{ $report->status }}
                                    </span>
                                    @if($report->tag === 'critical')
                                        <span class="px-2 py-0.5 text-[9px] font-extrabold rounded-md uppercase tracking-wider bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/20" title="{{ $report->critical_reason ?? 'Critical' }}">
                                            Critical
                                        </span>
                                    @elseif($report->tag === 'warning')
                                        <span class="px-2 py-0.5 text-[9px] font-extrabold rounded-md uppercase tracking-wider bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                                            Warning
                                        </span>
                                    @endif
                                </div>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <div class="inline-flex items-center gap-1 justify-center">
                                    {{-- View button --}}
                                    <a href="{{ route('staff.maintenance.view', $report->id) }}" wire:navigate
                                       class="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="View Report">
                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                        </svg>
                                    </a>

                                    {{-- Edit button --}}
                                    <a href="{{ route('staff.maintenance.edit', $report->id) }}" wire:navigate
                                       class="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="Edit Report">
                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                    </a>

                                    {{-- PDF button --}}
                                    <a href="{{ route('staff.maintenance.pdf', $report->id) }}" target="_blank"
                                       class="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="Download PDF">
                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                        </svg>
                                    </a>

                                    {{-- Email button --}}
                                    <button type="button" 
                                            wire:click="emailReport({{ $report->id }})"
                                            wire:confirm="Send Maintenance Report #{{ $report->id }} to client's email ({{ $report->client->user->email }})?"
                                            wire:loading.attr="disabled"
                                            class="w-9 h-9 flex items-center justify-center rounded-xl transition-all duration-150 relative 
                                                   {{ $report->last_sent_at ? 'text-emerald-500 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/20' : 'text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50' }}" 
                                            title="{{ $report->last_sent_at ? 'Emailed to client on ' . $report->last_sent_at->format('d M, H:i') . ' (Click to send again)' : 'Email Report to Client' }}">
                                        <div wire:loading.remove wire:target="emailReport({{ $report->id }})">
                                            <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                            </svg>
                                        </div>
                                        <div wire:loading wire:target="emailReport({{ $report->id }})">
                                            <svg class="animate-spin w-5 h-5 text-emerald-600" fill="none" viewBox="0 0 24 24">
                                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                        </div>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="mt-6">
                    {{ $reports->links() }}
                </div>
            @endif
    </x-admin.card>
</div>
