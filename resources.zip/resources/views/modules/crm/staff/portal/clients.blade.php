@section('page_title', $clientDetails ? 'Client: ' . $clientDetails->company_name : 'My Clients')

<div>
    <!-- Breadcrumbs -->
    @if ($clientDetails)
        <x-admin.breadcrumbs :items="['My Clients' => route('staff.clients'), $clientDetails->user->name ?? 'Detail' => null]" />
    @else
        <x-admin.breadcrumbs :items="['My Clients' => null]" />
    @endif

    @if ($clientDetails)
        @if (session('success'))
            <x-admin.alert type="success" class="mb-5" :message="session('success')" />
        @endif
        @if (session('error'))
            <x-admin.alert type="danger" class="mb-5" :message="session('error')" />
        @endif

        {{-- ==========================================
             CLIENT DETAIL DASHBOARD VIEW
             ========================================== --}}
        <!-- Client Header Card -->
        <div class="bg-white/93 dark:bg-slate-900/60 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-4 sm:p-6 mb-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4 sm:gap-6 overflow-hidden">
            <div class="flex items-center gap-3 sm:gap-4 min-w-0 w-full">
                <div class="relative shrink-0">
                    @if($clientDetails->profile_image)
                        <img src="{{ Str::startsWith($clientDetails->profile_image, 'http') ? $clientDetails->profile_image : asset('storage/' . $clientDetails->profile_image) }}" alt="{{ $clientDetails->user->name }}" class="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-800" onerror="this.outerHTML=`<div class='w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-lg sm:text-xl font-bold text-indigo-600 dark:text-indigo-400'>{{ $clientDetails->getInitials() }}</div>`" />
                    @else
                        <div class="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-lg sm:text-xl font-bold text-indigo-600 dark:text-indigo-400">
                            {{ $clientDetails->getInitials() }}
                        </div>
                    @endif
                </div>
                <div class="min-w-0 flex-1">
                    <div class="flex items-center gap-2 sm:gap-3 flex-wrap">
                        <h1 class="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate">{{ $clientDetails->user->name }}</h1>
                        <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase {{ $clientDetails->status === 'active' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-slate-500/10 text-slate-600 dark:text-slate-400' }} tracking-wider">
                            {{ $clientDetails->status }}
                        </span>
                        @foreach($clientDetails->plans as $pl)
                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-{{ $pl->color }}-500/10 text-{{ $pl->color }}-600 dark:text-{{ $pl->color }}-400 tracking-wider">
                                {{ $pl->name }}
                            </span>
                        @endforeach
                    </div>
                    <div class="mt-1.5 sm:mt-2 flex flex-wrap gap-x-3 sm:gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
                        <span class="flex items-center gap-1.5 truncate max-w-full">
                            <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                            <span class="truncate">{{ $clientDetails->company_name ?: 'No Company' }}</span>
                        </span>
                        <span class="flex items-center gap-1.5 truncate max-w-full">
                            <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 00-2 2z" />
                            </svg>
                            <span class="truncate">{{ $clientDetails->user->email }}</span>
                        </span>
                        @if($clientDetails->phones->isNotEmpty())
                            <span class="flex items-center gap-1.5 truncate max-w-full">
                                <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.94.725l.548 2.2a1 1 0 01-.321.988l-1.305.98a10.582 10.582 0 004.872 4.872l.98-1.305a1 1 0 01.988-.321l2.2.548a1 1 0 01.725.94V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                </svg>
                                <span class="truncate">{{ $clientDetails->phones->first()->phone }}</span>
                            </span>
                        @endif
                    </div>
                </div>
            </div>
            @php
                $detailMappingData = [
                    'id' => $clientDetails->id,
                    'name' => $clientDetails->user->name ?? 'Client',
                    'email' => $clientDetails->user->email ?? '',
                    'company_name' => $clientDetails->company_name ?? '',
                    'initials' => $clientDetails->getInitials(),
                ];
                $detailClickUpFolderIds = $clientDetails->clickUpFolders->pluck('id')->map(fn($id) => (string)$id)->toArray();
            @endphp
            <div class="flex flex-wrap items-center gap-2 w-full sm:w-auto shrink-0 justify-end">
                @if(!empty($detailClickUpFolderIds))
                    <button type="button"
                            wire:click="disconnectClickUpMapping({{ $clientDetails->id }})"
                            wire:confirm="Are you sure you want to disconnect ClickUp from {{ $clientDetails->company_name ?: ($clientDetails->user->name ?? 'this client') }}?"
                            class="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-800/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
                            title="Disconnect ClickUp from this client">
                        <span>Disconnect</span>
                        <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                    </button>
                @else
                    <button type="button" 
                            @click="
                                $dispatch('open-clickup-modal', { client: {{ Js::from($detailMappingData) }}, folderIds: {{ Js::from($detailClickUpFolderIds) }} });
                                $dispatch('open-modal', { name: 'clickup-client-mapping-modal' });
                            " 
                            class="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-3.5 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-700 font-bold text-xs rounded-xl shadow-sm transition active:scale-95">
                        <span>Map With</span>
                        <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                    </button>
                @endif
            </div>
        </div>

        <!-- Tabs Navigation -->
        <div class="mb-6 bg-slate-100/80 dark:bg-slate-900/50 p-1.5 rounded-2xl overflow-x-auto no-scrollbar border border-slate-200/40 dark:border-slate-800/40">
            <nav class="flex flex-nowrap space-x-1 min-w-max" aria-label="Tabs">
                @php
                    $navTabs = [
                        'marketing' => 'Marketing',
                        'websites' => 'Websites',
                    ];
                    if ($isAssignedToStaff) {
                        $navTabs['integrations'] = 'Integrations';
                        $navTabs['clickup_tickets'] = 'ClickUp Tickets';
                    }
                    $navTabs['maintenance'] = 'Maintenance';
                    $navTabs['misc'] = 'Misc';
                @endphp
                @foreach($navTabs as $tabKey => $tabLabel)
                    @php
                        $isMiscActive = in_array($activeTab, ['overview', 'activity log', 'documents']);
                        $isActive = ($tabKey === 'misc' && $isMiscActive) || $activeTab === $tabKey;
                        $linkTab = $tabKey === 'misc' ? 'overview' : $tabKey;
                    @endphp
                    <a href="{{ route('staff.clients.detail', ['id' => $clientDetails->id, 'tab' => $linkTab]) }}" wire:navigate class="py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all duration-150 flex items-center gap-1.5 shrink-0 {{ $isActive ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 hover:text-slate-850 hover:bg-white/40 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800/30' }}">
                        <span>{{ $tabLabel }}</span>
                    </a>
                @endforeach
            </nav>
        </div>

        <!-- Secondary Tabs for Misc -->
        @if(in_array($activeTab, ['overview', 'activity log', 'documents']))
            <div class="mb-6 bg-slate-50/80 dark:bg-slate-900/30 p-1.5 rounded-2xl overflow-x-auto no-scrollbar border border-slate-200/30 dark:border-slate-800/30">
                <nav class="flex flex-nowrap space-x-1 min-w-max" aria-label="Sub Tabs">
                    @foreach([
                        'overview' => 'Overview',
                        'activity log' => 'Activity Log',
                        'documents' => 'Resources'
                    ] as $subTabKey => $subTabLabel)
                        <a href="{{ route('staff.clients.detail', ['id' => $clientDetails->id, 'tab' => $subTabKey]) }}" wire:navigate
                           class="py-2 px-4 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all duration-150 flex items-center gap-1.5 shrink-0 {{ $activeTab === $subTabKey ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400 shadow-sm' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-slate-300 dark:hover:bg-slate-800/50' }}">
                            <span>{{ $subTabLabel }}</span>
                        </a>
                    @endforeach
                </nav>
            </div>
        @endif

        {{-- Tab Content --}}
        <div>
            @if ($activeTab === 'overview')
                {{-- Overview content --}}
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fadeIn">
                    <!-- About Card -->
                    <div class="lg:col-span-2 bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4">About</h3>
                        <p class="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                            {{ $clientDetails->notes ?: 'No additional notes provided for this client.' }}
                        </p>
                    </div>

                    <!-- Reports & Integrations -->
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <div class="flex items-center justify-between gap-3 mb-4">
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Reports & Integrations</h3>
                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                                Analytics
                            </span>
                        </div>
                        <div class="space-y-4">
                            <p class="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                                View marketing performance, traffic analytics, and SEO rankings from connected third-party platforms.
                            </p>
                            
                            <div class="flex items-center gap-2 mb-4">
                                <div class="w-8 h-8 rounded-full bg-orange-50 dark:bg-orange-900/20 flex items-center justify-center text-orange-500 border border-orange-100 dark:border-orange-800/50" title="Google Analytics 4">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                                </div>
                                <div class="w-8 h-8 rounded-full bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-500 border border-blue-100 dark:border-blue-800/50" title="Google Search Console">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                                </div>
                                <div class="w-8 h-8 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-500 border border-emerald-100 dark:border-emerald-800/50" title="Google Ads">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 6l-9.5 9.5-5-5L1 18"></path><polyline points="17 6 23 6 23 12"></polyline></svg>
                                </div>
                                <div class="w-8 h-8 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 border border-slate-200 dark:border-slate-700 text-[10px] font-bold">
                                    +3
                                </div>
                            </div>

                            <a href="{{ route('staff.clients.detail', ['id' => $clientDetails->id, 'tab' => 'marketing']) }}" wire:navigate
                                class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-900/30 dark:hover:bg-indigo-900/50 text-indigo-650 dark:text-indigo-400 font-bold text-xs rounded-xl transition active:scale-95">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                                </svg>
                                View Integrations & Reports
                            </a>
                        </div>
                    </div>

                    <!-- Assigned Team Card -->
                    <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6">
                        <h3 class="text-base font-bold text-slate-900 dark:text-white mb-4">Assigned team</h3>
                        @if ($clientDetails->assignedStaff->isNotEmpty())
                            <div class="space-y-3">
                                @foreach($clientDetails->assignedStaff as $staff)
                                    <div class="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-xl">
                                        <div class="shrink-0">
                                            @if($staff->profile_image)
                                                <img src="{{ asset('storage/' . $staff->profile_image) }}" alt="Staff Avatar" class="w-10 h-10 rounded-full object-cover" />
                                            @else
                                                <div class="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-700 dark:text-slate-300">
                                                    {{ $staff->getInitials() }}
                                                </div>
                                            @endif
                                        </div>
                                        <div>
                                            <div class="font-bold text-sm text-slate-900 dark:text-white">{{ $staff->user->name ?? 'Deleted Staff' }}</div>
                                            <div class="text-[10px] font-extrabold uppercase text-slate-450 dark:text-slate-500 tracking-wider">
                                                {{ $staff->designations->pluck('name')->implode(', ') ?: 'Staff Member' }}
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="text-center py-6 text-sm text-slate-450 dark:text-slate-500 italic">
                                No team members assigned to this client yet.
                            </div>
                        @endif
                    </div>


                </div>

            @elseif ($activeTab === 'marketing')
                <div class="animate-fadeIn">
                    @livewire('admin-client-marketing-tab', ['clientId' => $clientDetails->id], key('staff-marketing-tab-'.$clientDetails->id))
                </div>

            @elseif ($activeTab === 'websites')
                <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl overflow-hidden shadow-sm animate-fadeIn">
                    @if ($clientWebsites->isEmpty())
                        <div class="text-center py-12 text-slate-500">No websites mapped yet.</div>
                    @else
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                    <th class="px-6 py-4">Site Name</th>
                                    <th class="px-6 py-4">URL</th>
                                    <th class="px-6 py-4">Latest Maintenance Score</th>
                                    <th class="px-6 py-4">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                                @foreach ($clientWebsites as $web)
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                        <td class="px-6 py-4 font-bold text-slate-800 dark:text-white">
                                            <a href="{{ route('staff.websites.detail', ['id' => $web->id]) }}" wire:navigate class="hover:text-indigo-600 dark:hover:text-indigo-400 hover:underline transition-colors">
                                                {{ $web->site_name }}
                                            </a>
                                        </td>
                                        <td class="px-6 py-4">
                                            <a href="{{ $web->url }}" target="_blank" class="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold">{{ $web->url }}</a>
                                        </td>
                                        <td class="px-6 py-4 font-bold text-slate-650 dark:text-slate-350">
                                            {{ $web->latestMaintenanceReport ? $web->latestMaintenanceReport->health_score . '%' : 'N/A' }}
                                        </td>
                                        <td class="px-6 py-4">
                                            <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">Online</span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                </div>

            @elseif ($activeTab === 'integrations')
                <!-- Website Selection Dropdown -->
                <div class="mb-6 flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50/50 dark:bg-slate-900/30 border border-slate-200/40 dark:border-slate-800/40 rounded-2xl">
                    <div>
                        <h3 class="text-sm font-bold text-slate-800 dark:text-slate-200">Manage Integrations</h3>
                        <p class="text-xs text-slate-500">Select a specific website to manage its third-party connection credentials.</p>
                    </div>
                    <div class="w-full sm:w-64">
                        <select wire:model.live="selectedWebsiteId" class="w-full text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-750 dark:text-slate-300 py-2.5 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500">
                            @if($clientWebsites->isEmpty())
                                <option value="">No websites registered</option>
                            @else
                                @foreach($clientWebsites as $site)
                                    <option value="{{ $site->id }}">{{ $site->site_name }} ({{ parse_url($site->url, PHP_URL_HOST) ?? $site->url }})</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                </div>

                @if(!$selectedWebsiteId)
                    <div class="border border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center bg-slate-50/20 dark:bg-slate-950/10">
                        <svg class="w-12 h-12 text-slate-350 dark:text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" />
                        </svg>
                        <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm mb-1">No Website Selected</h4>
                        <p class="text-xs text-slate-450 dark:text-slate-550">Please register or select a website from the list above to configure its third-party app integrations.</p>
                    </div>
                @else
                    <div x-data="{ showAllIntegrations: false }">
                        <div class="mb-4 flex justify-end" x-show="!showAllIntegrations">
                            <button type="button" x-on:click="showAllIntegrations = true" class="flex items-center gap-2 py-2 px-4 rounded-xl font-bold text-xs bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"></path>
                                </svg>
                                Add New Integration
                            </button>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn">
                            @foreach ($clientIntegrations as $integration)
                                @php
                                    $isNotConfigured = $integration['status'] === 'not_configured';
                                $isConfigured = $integration['status'] === 'credentials_configured';
                                $isConnected = $integration['status'] === 'connected';
                                $isDegraded = $integration['status'] === 'degraded';

                                $cardTheme = match($integration['id']) {
                                    'ga4' => [
                                        'iconBg' => 'bg-orange-50 dark:bg-orange-950/20',
                                        'hoverBorder' => 'hover:border-orange-500/35 dark:hover:border-orange-500/25',
                                        'hoverShadow' => 'hover:shadow-orange-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-orange-500 dark:text-orange-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>'
                                    ],
                                    'gsc' => [
                                        'iconBg' => 'bg-blue-50 dark:bg-blue-950/20',
                                        'hoverBorder' => 'hover:border-blue-500/35 dark:hover:border-blue-500/25',
                                        'hoverShadow' => 'hover:shadow-blue-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-blue-500 dark:text-blue-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>'
                                    ],
                                    'gads' => [
                                        'iconBg' => 'bg-emerald-50 dark:bg-emerald-950/20',
                                        'hoverBorder' => 'hover:border-emerald-500/35 dark:hover:border-emerald-500/25',
                                        'hoverShadow' => 'hover:shadow-emerald-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-emerald-600 dark:text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 6l-9.5 9.5-5-5L1 18"></path><polyline points="17 6 23 6 23 12"></polyline></svg>'
                                    ],
                                    'youtube' => [
                                        'iconBg' => 'bg-red-50 dark:bg-red-950/20',
                                        'hoverBorder' => 'hover:border-red-500/35 dark:hover:border-red-500/25',
                                        'hoverShadow' => 'hover:shadow-red-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-red-600 dark:text-red-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.42a2.78 2.78 0 0 0-1.94 2C1 8.14 1 12 1 12s0 3.86.46 5.58a2.78 2.78 0 0 0 1.94 2C5.12 20 12 20 12 20s6.88 0 8.6-.42a2.78 2.78 0 0 0 1.94-2C23 15.86 23 12 23 12s0-3.86-.46-5.58z"></path><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"></polygon></svg>'
                                    ],
                                    'keyword' => [
                                        'iconBg' => 'bg-slate-100 dark:bg-slate-800/60',
                                        'hoverBorder' => 'hover:border-slate-400/35 dark:hover:border-slate-500/25',
                                        'hoverShadow' => 'hover:shadow-slate-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-slate-600 dark:text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><rect x="7" y="7" width="3" height="9"></rect><rect x="14" y="7" width="3" height="5"></rect></svg>'
                                    ],
                                    'facebook' => [
                                        'iconBg' => 'bg-blue-50 dark:bg-blue-950/20',
                                        'hoverBorder' => 'hover:border-blue-600/35 dark:hover:border-blue-600/25',
                                        'hoverShadow' => 'hover:shadow-blue-600/5',
                                        'svg' => '<svg class="w-5 h-5 text-blue-600 dark:text-blue-500" viewBox="0 0 24 24" fill="currentColor"><path d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z"/></svg>'
                                    ],
                                    'linkedin' => [
                                        'iconBg' => 'bg-sky-50 dark:bg-sky-950/20',
                                        'hoverBorder' => 'hover:border-sky-600/35 dark:hover:border-sky-600/25',
                                        'hoverShadow' => 'hover:shadow-sky-600/5',
                                        'svg' => '<svg class="w-5 h-5 text-sky-600 dark:text-sky-500" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>'
                                    ],
                                    'gbp' => [
                                        'iconBg' => 'bg-blue-50 dark:bg-blue-950/20',
                                        'hoverBorder' => 'hover:border-blue-500/35 dark:hover:border-blue-500/25',
                                        'hoverShadow' => 'hover:shadow-blue-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-blue-500 dark:text-blue-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 012 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>'
                                    ],
                                    default => [
                                        'iconBg' => 'bg-slate-50 dark:bg-slate-800/40',
                                        'hoverBorder' => 'hover:border-indigo-500/35 dark:hover:border-indigo-500/25',
                                        'hoverShadow' => 'hover:shadow-indigo-500/5',
                                        'svg' => '<svg class="w-5 h-5 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="21" x2="9" y2="9"></line><line x1="3" y1="14" x2="21" y2="14"></line></svg>'
                                    ]
                                };
                            @endphp
                            <div x-show="showAllIntegrations || !{{ json_encode($isNotConfigured) }}" x-transition.opacity.duration.300ms wire:key="integration-card-{{ $integration['id'] }}" class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-3xl p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:hover:shadow-none {{ $cardTheme['hoverBorder'] }} {{ $cardTheme['hoverShadow'] }} {{ $isNotConfigured ? 'opacity-70 bg-slate-50/20 dark:bg-slate-950/10' : '' }}" style="display: {{ $isNotConfigured ? 'none' : 'flex' }};">
                                <div>
                                    <!-- Top Row: Logo, Name/Category, Status Badge -->
                                    <div class="flex items-start justify-between mb-6">
                                        <div class="flex items-center gap-3">
                                            <!-- Circular icon container (Custom per integration) -->
                                            <div class="w-10 h-10 rounded-full {{ $cardTheme['iconBg'] }} flex items-center justify-center shrink-0">
                                                {!! $cardTheme['svg'] !!}
                                            </div>
                                            <div>
                                                <h4 class="text-[18px] font-bold text-slate-900 dark:text-white leading-tight">
                                                    {{ $integration['name'] }}
                                                </h4>
                                                <div class="mt-1.5 flex flex-wrap items-center gap-2">
                                                    <span class="text-xs text-slate-400 dark:text-slate-500">{{ $integration['category'] }}</span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Status Badge -->
                                        <div>
                                            @if ($isNotConfigured)
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-450 dark:bg-slate-800 dark:text-slate-500">
                                                    Not Configured
                                                </span>
                                            @elseif ($isConfigured)
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-500/10 text-indigo-650 dark:text-indigo-400">
                                                    Keys Configured
                                                </span>
                                            @elseif ($isDegraded)
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/10 text-amber-600 dark:text-amber-400">
                                                    Degraded
                                                </span>
                                            @else
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/10 text-emerald-600 dark:text-emerald-455">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse"></span>
                                                    Connected
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    <!-- Middle: Stats columns (Modern card sub-containers) -->
                                    <div class="mb-6">
                                        <div class="bg-slate-50/50 dark:bg-slate-900/30 border border-slate-100/50 dark:border-slate-850/50 p-3.5 rounded-2xl transition hover:bg-slate-100/30 dark:hover:bg-slate-850/20">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Last sync</span>
                                            <span class="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate block mt-0.5" title="{{ $integration['last_sync'] }}">
                                                {{ $integration['last_sync'] }}
                                            </span>
                                        </div>
                                    </div>
                                @if ($integration['id'] === 'ga4' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-indigo-50/30 dark:bg-indigo-950/10 rounded-xl border border-indigo-100/30 dark:border-indigo-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-indigo-650 dark:text-indigo-400 block mb-1.5 uppercase tracking-wider">Select GA4 Property</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="property-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-sm">
                                                    <option value="">Select Property...</option>
                                                    @foreach ($this->getGA4Properties() as $prop)
                                                        <option value="{{ $prop['id'] }}">{{ $prop['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGA4Property" wire:key="property-save-btn-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">GA4 Property ID</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif

                                @if ($integration['id'] === 'gsc' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-teal-50/30 dark:bg-teal-950/10 rounded-xl border border-teal-100/30 dark:border-teal-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-teal-650 dark:text-teal-400 block mb-1.5 uppercase tracking-wider">Select GSC Site</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="gsc-site-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-teal-500 shadow-sm">
                                                    <option value="">Select Site...</option>
                                                    @foreach ($this->getGSCSites() as $site)
                                                        <option value="{{ $site['id'] }}">{{ $site['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGSCSite('gsc')" wire:key="save-btn-gsc-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">GSC Site</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif

                                @if ($integration['id'] === 'youtube' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-red-50/30 dark:bg-red-950/10 rounded-xl border border-red-100/30 dark:border-red-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-red-650 dark:text-red-400 block mb-1.5 uppercase tracking-wider">Select YouTube Channel</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="youtubeChannelId" x-on:change="hasVal = $event.target.value !== ''" wire:key="youtube-channel-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-red-500 shadow-sm">
                                                    <option value="">Select Channel...</option>
                                                    @foreach ($this->getYoutubeChannels() as $channel)
                                                        <option value="{{ $channel['id'] }}">{{ $channel['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveYoutubeChannel" wire:key="save-btn-youtube-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">YouTube Channel</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif

                                @if ($integration['id'] === 'keyword' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-purple-50/30 dark:bg-purple-950/10 rounded-xl border border-purple-100/30 dark:border-purple-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-purple-650 dark:text-purple-400 block mb-1.5 uppercase tracking-wider">Select Keyword Project</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="keywordProjectId" x-on:change="hasVal = $event.target.value !== ''" wire:key="keyword-project-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-purple-500 shadow-sm">
                                                    <option value="">Select Project...</option>
                                                    @foreach ($this->getKeywordProjects() as $project)
                                                        <option value="{{ $project['id'] }}">{{ $project['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveKeywordProject" wire:key="save-btn-keyword-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">Keyword Project ID</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif
                                
                                @if ($integration['id'] === 'gtm' && $isConnected)
                                    @if (!$integration['property_id'])
                                        <div class="mt-4 p-3 bg-teal-50/30 dark:bg-teal-950/10 rounded-xl border border-teal-100/30 dark:border-teal-900/20 mb-4">
                                            <span class="text-[10px] font-bold text-teal-650 dark:text-teal-400 block mb-1.5 uppercase tracking-wider">Select GTM Container</span>
                                            <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                <select wire:model="gtmContainerId" x-on:change="hasVal = $event.target.value !== ''" wire:key="gtm-container-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-teal-500 shadow-sm">
                                                    <option value="">Select Container...</option>
                                                    @foreach ($this->getGtmContainers() as $container)
                                                        <option value="{{ $container['id'] }}">{{ $container['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGtmContainer" wire:key="save-btn-gtm-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">GTM Container ID</span>
                                            <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                        </div>
                                    @endif
                                @endif

                                @if ($integration['id'] === 'gbp' && $isConnected)
                                    @if (!$integration['property_id'])
                                        @php $gbpLocations = $this->getGBPLocations(); @endphp
                                        <div class="mt-4 p-3 bg-blue-50/30 dark:bg-blue-950/10 rounded-xl border border-blue-100/30 dark:border-blue-900/20 mb-4" x-data="{ manual: {{ empty($gbpLocations) ? 'true' : 'false' }}, hasVal: false }">
                                            <div class="flex items-center justify-between mb-1.5">
                                                <span class="text-[10px] font-bold text-blue-650 dark:text-blue-400 block uppercase tracking-wider">GBP Location ID</span>
                                                @if(!empty($gbpLocations))
                                                    <button type="button" @click="manual = !manual; hasVal = false" class="text-[10px] text-blue-600 dark:text-blue-400 hover:underline">
                                                        <span x-show="!manual">Enter manually</span>
                                                        <span x-show="manual">Choose from list</span>
                                                    </button>
                                                @endif
                                            </div>

                                            <div x-show="!manual" class="flex gap-2 items-center">
                                                <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="gbp-location-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 shadow-sm">
                                                    <option value="">Select Location...</option>
                                                    @foreach ($gbpLocations as $location)
                                                        <option value="{{ $location['id'] }}">{{ $location['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="savePropertyId('gbp')" wire:key="save-btn-gbp-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>

                                            <div x-show="manual" class="flex gap-2 items-center">
                                                <input type="text" wire:model.defer="selectedPropertyId" x-on:input="hasVal = $event.target.value.trim() !== ''" placeholder="e.g. 1234567890123456789" wire:key="gbp-location-input-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 shadow-sm">
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="savePropertyId('gbp')" wire:key="save-btn-gbp-manual-{{ $integration['id'] }}" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                            <p x-show="manual" class="text-[10px] text-slate-400 mt-1.5 leading-tight">Tip: Go to Google Business Profile &gt; 3 dots &gt; Business Profile settings &gt; Advanced settings &gt; Copy the Business Profile ID.</p>
                                        </div>
                                    @else
                                        <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                            <span class="text-slate-455 dark:text-slate-550 font-medium">GBP Location ID</span>
                                            <div class="flex items-center gap-2">
                                                <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                                <button type="button" wire:click="clearPropertyId('gbp')" class="text-slate-400 hover:text-red-500 transition" title="Clear Location ID">
                                                    <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    @endif
                                                                 @endif

                                @if ($integration['id'] === 'gads' && $isConnected)
                                     @if (!$integration['property_id'])
                                         <div class="mt-4 p-3 bg-emerald-50/30 dark:bg-emerald-950/10 rounded-xl border border-emerald-100/30 dark:border-emerald-900/20 mb-4">
                                             <span class="text-[10px] font-bold text-emerald-650 dark:text-emerald-400 block mb-1.5 uppercase tracking-wider">Select Google Ads Account</span>
                                             <div class="flex gap-2 items-center" x-data="{ hasVal: false }">
                                                 <input type="text" wire:model.defer="googleAdsAccountId" x-on:input="hasVal = $event.target.value.length >= 10" placeholder="e.g. 123-456-7890" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-sm">
                                                 <button type="button" x-show="hasVal" style="display: none;" wire:click="saveGoogleAdsAccount" wire:key="save-btn-gads" class="py-2 px-4 border border-transparent bg-indigo-600 hover:bg-indigo-750 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                     <span>Save</span>
                                                 </button>
                                             </div>
                                         </div>
                                     @else
                                         <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                             <span class="text-slate-455 dark:text-slate-550 font-medium">Google Ads Account ID</span>
                                             <div class="flex items-center gap-2">
                                                 <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[200px] truncate" title="{{ $integration['property_id'] }}">
                                                     @if(strlen($integration['property_id']) == 20)
                                                         <span class="text-xs font-normal text-slate-400">MCC:</span> {{ substr($integration['property_id'], 0, 3) }}-{{ substr($integration['property_id'], 3, 3) }}-{{ substr($integration['property_id'], 6, 4) }} <br>
                                                         <span class="text-xs font-normal text-slate-400">Client:</span> {{ substr($integration['property_id'], 10, 3) }}-{{ substr($integration['property_id'], 13, 3) }}-{{ substr($integration['property_id'], 16, 4) }}
                                                     @elseif(strlen($integration['property_id']) == 10)
                                                         <span class="text-xs font-normal text-slate-400">Client:</span> {{ substr($integration['property_id'], 0, 3) }}-{{ substr($integration['property_id'], 3, 3) }}-{{ substr($integration['property_id'], 6, 4) }}
                                                     @else
                                                         {{ $integration['property_id'] }}
                                                     @endif
                                                 </span>
                                                 <button type="button" wire:click="clearPropertyId('gads')" class="text-slate-400 hover:text-red-500 transition" title="Clear Account ID">
                                                     <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                         <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                     </svg>
                                                 </button>
                                             </div>
                                         </div>
                                     @endif
                                 @endif

                                 @if ($integration['id'] === 'facebook' && $isConnected)
                                     <div class="mt-3 flex items-center justify-between text-xs p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4">
                                         <span class="text-slate-455 dark:text-slate-550 font-medium">Facebook Page ID</span>
                                         <div class="flex items-center gap-2">
                                             <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[120px] truncate" title="{{ $integration['property_id'] }}">{{ $integration['property_id'] }}</span>
                                             <button type="button" wire:click="clearPropertyId('facebook')" class="text-slate-400 hover:text-red-500 transition" title="Clear Facebook Page ID">
                                                 <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                     <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                 </svg>
                                             </button>
                                         </div>
                                     </div>
                                 @endif

                                @if ($integration['id'] === 'linkedin' && $isConnected)
                                    @if (!$integration['property_id'])
                                        @php $linkedInPages = $this->getLinkedInPages(); @endphp
                                        <div class="mt-4 p-3 bg-sky-50/40 dark:bg-sky-950/20 rounded-xl border border-sky-100/50 dark:border-sky-900/30 mb-4" x-data="{ manual: {{ empty($linkedInPages) ? 'true' : 'false' }}, hasVal: false }">
                                            <div class="flex items-center justify-between mb-1.5">
                                                <span class="text-[10px] font-bold text-sky-650 dark:text-sky-400 block uppercase tracking-wider">Select LinkedIn Page</span>
                                                @if(!empty($linkedInPages))
                                                    <button type="button" @click="manual = !manual; hasVal = false" class="text-[10px] text-sky-600 dark:text-sky-400 hover:underline">
                                                        <span x-show="!manual">Enter ID manually</span>
                                                        <span x-show="manual">Choose from list</span>
                                                    </button>
                                                @endif
                                            </div>

                                            <div x-show="!manual" class="flex gap-2 items-center">
                                                <select wire:model="selectedPropertyId" x-on:change="hasVal = $event.target.value !== ''" wire:key="staff-linkedin-page-select-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-sky-500 shadow-sm">
                                                    <option value="">Select Page / Company...</option>
                                                    @foreach ($linkedInPages as $page)
                                                        <option value="{{ $page['id'] }}">{{ $page['name'] }} (ID: {{ $page['id'] }})</option>
                                                    @endforeach
                                                </select>
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveLinkedInPage" wire:key="staff-save-btn-linkedin" class="py-2 px-4 border border-transparent bg-sky-600 hover:bg-sky-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>

                                            <div x-show="manual" class="flex gap-2 items-center">
                                                <input type="text" wire:model.defer="selectedPropertyId" x-on:input="hasVal = $event.target.value.trim() !== ''" placeholder="e.g. 12345678" wire:key="staff-linkedin-page-input-{{ $integration['id'] }}" class="flex-1 min-w-0 py-2 text-[11px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 px-3 focus:outline-none focus:ring-1 focus:ring-sky-500 shadow-sm">
                                                <button type="button" x-show="hasVal" style="display: none;" wire:click="saveLinkedInPage" wire:key="staff-save-btn-linkedin-manual" class="py-2 px-4 border border-transparent bg-sky-600 hover:bg-sky-700 text-white font-medium text-[11px] rounded-lg transition-all shrink-0 active:scale-95 shadow-sm">
                                                    <span>Save</span>
                                                </button>
                                            </div>
                                            @if(empty($linkedInPages))
                                                <p class="text-[10px] text-amber-600 dark:text-amber-400 mt-1.5 leading-tight">No organization pages returned via API. Enter your LinkedIn Organization ID manually above.</p>
                                            @endif
                                        </div>
                                    @else
                                        <div class="mt-3 p-2.5 bg-slate-50/50 dark:bg-slate-900/30 rounded-2xl border border-slate-200/50 dark:border-slate-850/50 mb-4" x-data="{ editingFollowers: false, followersVal: '{{ $integration['followers'] ?? 1195 }}' }">
                                            <div class="flex items-center justify-between text-xs mb-1.5">
                                                <span class="text-slate-455 dark:text-slate-550 font-medium">LinkedIn Page</span>
                                                <div class="flex items-center gap-2">
                                                    <span class="font-bold text-slate-755 dark:text-slate-300 max-w-[160px] truncate" title="{{ $integration['property_name'] ?? $integration['property_id'] }} (ID: {{ $integration['property_id'] }})">
                                                        {{ $integration['property_name'] ?? $integration['property_id'] }}
                                                        @if(!empty($integration['property_name']) && !empty($integration['property_id']))
                                                            <span class="text-[10px] text-slate-400 font-normal">({{ $integration['property_id'] }})</span>
                                                        @endif
                                                    </span>
                                                    <button type="button" wire:click="clearPropertyId('linkedin')" class="text-slate-400 hover:text-red-500 transition" title="Clear LinkedIn Page">
                                                        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endif
                                </div>

                                <!-- Footer Actions -->
                                <div class="flex items-center gap-3 mt-auto">
                                    @if ($isNotConfigured)
                                        <!-- Configure credentials first -->
                                        <button type="button" 
                                                wire:click="openConfigModal('{{ $integration['id'] }}')"
                                                class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition active:scale-95">
                                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                                            </svg>
                                            Configure Credentials
                                        </button>
                                    @elseif ($isConfigured)
                                        <!-- Auth stage -->
                                        @if ($integration['id'] === 'linkedin')
                                            <a href="{{ route('staff.integrations.linkedin.redirect', $integration['db_id']) }}"
                                               class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-[#0077b5] hover:bg-[#005f93] text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95 text-center flex items-center justify-center">
                                                <svg class="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                                                    <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/>
                                                </svg>
                                                Continue with LinkedIn
                                            </a>
                                        @else
                                            <a href="{{ route('staff.integrations.google.redirect', $integration['db_id']) }}"
                                               class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-indigo-600 hover:bg-indigo-755 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95 text-center flex items-center justify-center">
                                                <svg class="w-4 h-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                                                </svg>
                                                Sign in with Google
                                            </a>
                                        @endif
                                        <button type="button" 
                                                wire:click="removeCredentials('{{ $integration['id'] }}')"
                                                wire:confirm="Are you sure you want to remove the credentials for this integration?"
                                                class="px-3 py-2.5 bg-slate-100 hover:bg-red-50 dark:bg-slate-800 dark:hover:bg-red-955/20 text-slate-500 hover:text-red-650 dark:text-slate-400 dark:hover:text-red-400 font-bold text-xs rounded-xl transition active:scale-95"
                                                title="Remove Credentials">
                                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </button>
                                    @else
                                        <!-- Connected stage -->
                                        <div class="w-full flex flex-col gap-2.5 mt-auto">

                                            <div class="flex items-center gap-3">
                                                <button type="button" 
                                                        wire:click="refreshIntegration('{{ $integration['id'] }}')"
                                                        wire:loading.attr="disabled"
                                                        wire:target="refreshIntegration('{{ $integration['id'] }}')"
                                                        class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-white dark:bg-slate-850 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-slate-700 dark:text-slate-350 font-bold text-xs rounded-xl transition shadow-sm active:scale-95">
                                                    <svg wire:loading.class="animate-spin" wire:target="refreshIntegration('{{ $integration['id'] }}')" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                                    </svg>
                                                    Refresh
                                                </button>
                                                <button type="button" 
                                                        wire:click="disconnectIntegration('{{ $integration['id'] }}')"
                                                        wire:loading.attr="disabled"
                                                        wire:confirm="Are you sure you want to disconnect {{ $integration['name'] }}?"
                                                        class="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2.5 bg-white dark:bg-slate-850 hover:bg-red-50 dark:hover:bg-red-955/20 border border-slate-200/80 dark:border-slate-700/80 hover:border-red-200 dark:hover:border-red-900/40 text-slate-750 hover:text-red-650 dark:text-slate-300 dark:hover:text-red-400 font-bold text-xs rounded-xl transition shadow-sm active:scale-95">
                                                    <svg class="w-4 h-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" stroke-linecap="round"/>
                                                        <path d="M18.364 5.636L5.636 18.364" stroke="red" stroke-width="2" stroke-linecap="round"/>
                                                    </svg>
                                                    Disconnect
                                                </button>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    </div>
                @endif

                <!-- Credentials Upload Modal -->
                @if ($showConfigModal)
                    <div class="fixed inset-0 z-50 flex items-center justify-center overflow-x-hidden overflow-y-auto outline-none focus:outline-none bg-slate-905/60 backdrop-blur-sm animate-fadeIn">
                        <div class="relative w-full max-w-lg mx-auto my-6 p-4">
                            <div class="relative flex flex-col w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl outline-none focus:outline-none">
                                <!-- Modal Header -->
                                <div class="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800/60 rounded-t-3xl">
                                    <h3 class="text-base font-bold text-slate-900 dark:text-white">
                                        @if($activeConfigIntegrationId === 'ga4')
                                            Configure Google Analytics 4
                                        @elseif($activeConfigIntegrationId === 'gsc')
                                            Configure Google Search Console
                                        @else
                                            Configure {{ strtoupper($activeConfigIntegrationId) }}
                                        @endif
                                    </h3>
                                    <button type="button" wire:click="closeConfigModal" class="text-slate-400 hover:text-slate-655 dark:hover:text-slate-200 focus:outline-none transition">
                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                </div>
                                
                                <!-- Modal Body -->
                                <form wire:submit.prevent="saveCredentials">
                                    <div class="p-6 flex-auto">
                                        @if($activeConfigIntegrationId === 'keyword')
                                            <div class="mb-5">
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Keyword.com API Token</label>
                                                <input type="text" wire:model="apiKey" placeholder="Enter your Keyword.com API Token" class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                @error('apiKey') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                            <div class="text-[11px] text-slate-450 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                                Note: Your API key will be securely stored and used only to fetch your keyword ranking data.
                                            </div>
                                        @elseif($activeConfigIntegrationId === 'facebook')
                                            <div class="space-y-4">
                                                <div>
                                                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">System User Access Token</label>
                                                    <input type="text" wire:model="facebookAccessToken" placeholder="EAAG..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                    @error('facebookAccessToken') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                                </div>
                                                <div>
                                                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">Page ID</label>
                                                    <input type="text" wire:model="facebookPageId" placeholder="10493..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                    @error('facebookPageId') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                                </div>
                                                <div>
                                                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">Ad Account ID</label>
                                                    <input type="text" wire:model="facebookAdAccountId" placeholder="act_..." class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all">
                                                    @error('facebookAdAccountId') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                                </div>
                                            </div>
                                            <div class="mt-4 text-[11px] text-slate-450 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                                Note: You need to create a System User in Facebook Business Manager and generate an access token with ads_read and pages_read_engagement permissions.
                                            </div>
                                        @elseif($activeConfigIntegrationId === 'linkedin')
                                            <div class="space-y-4">
                                                <div>
                                                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">LinkedIn App Client ID</label>
                                                    <input type="text" wire:model="linkedinClientId" placeholder="e.g. 86dksogosn2mxd" class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-sky-500/50 outline-none transition-all">
                                                    @error('linkedinClientId') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                                </div>
                                                <div>
                                                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">LinkedIn App Primary Client Secret</label>
                                                    <input type="password" wire:model="linkedinClientSecret" placeholder="••••••••••••••••" class="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-sm focus:ring-2 focus:ring-sky-500/50 outline-none transition-all">
                                                    @error('linkedinClientSecret') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                                </div>
                                                <div>
                                                    <div class="flex items-center justify-between mb-1.5">
                                                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">OAuth Scopes</label>
                                                        <span class="text-[10px] text-slate-400">Match with your app's "OAuth 2.0 scopes"</span>
                                                    </div>
                                                    <input type="text" wire:model="linkedinScopes" placeholder="r_basicprofile r_organization_social rw_organization_admin r_organization_followers" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-xs font-mono focus:ring-2 focus:ring-sky-500/50 outline-none transition-all">
                                                    <div class="flex flex-wrap gap-1.5 mt-2">
                                                        <button type="button" wire:click="$set('linkedinScopes', 'r_basicprofile r_organization_social rw_organization_admin r_organization_followers')" class="px-2.5 py-1.5 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/40 dark:hover:bg-sky-900/60 rounded-lg text-[10px] font-bold text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 transition shadow-sm">
                                                            ✓ Required Scopes (Page, Analytics & Followers)
                                                        </button>
                                                    </div>
                                                    @error('linkedinScopes') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                                </div>
                                                <div class="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
                                                    <span class="font-bold text-slate-700 dark:text-slate-300 block mb-1">Authorized Redirect URL for your LinkedIn App:</span>
                                                    <code class="text-[11px] text-sky-600 dark:text-sky-400 select-all break-all bg-white dark:bg-slate-900 p-1.5 rounded border border-slate-200 dark:border-slate-700 block font-mono">{{ route('admin.integrations.linkedin.callback') }}</code>
                                                    <p class="text-[10px] text-slate-400 mt-1.5">Add this exact URL to your LinkedIn Developer Portal under <strong>Auth &gt; OAuth 2.0 settings &gt; Authorized redirect URLs</strong>.</p>
                                                </div>
                                            </div>
                                            <div class="mt-4 text-[11px] text-slate-450 leading-relaxed bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/40 dark:border-amber-900/30 p-3 rounded-xl text-amber-800 dark:text-amber-400 font-medium">
                                                <strong>Important Tip:</strong> Ensure your LinkedIn App has the <strong>Community Management API</strong> product enabled in the LinkedIn Developer Portal to support page and follower scopes.
                                            </div>

                                        @else
                                            <div class="mb-5">
                                                <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">Google OAuth Credentials (.json)</label>
                                                <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-200 dark:border-slate-800 border-dashed rounded-2xl hover:border-indigo-500/50 dark:hover:border-indigo-400/50 transition-colors relative">
                                                    <div class="space-y-1 text-center">
                                                        <svg class="mx-auto h-12 w-12 text-slate-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                        <div class="flex text-xs text-slate-600 dark:text-slate-400 justify-center">
                                                            <label for="credentials-upload" class="relative cursor-pointer bg-white dark:bg-slate-900 rounded-md font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 focus-within:outline-none">
                                                                <span>Upload a file</span>
                                                                <input id="credentials-upload" name="credentials-upload" type="file" wire:model="credentialsFile" class="sr-only">
                                                            </label>
                                                            <p class="pl-1">or drag and drop</p>
                                                        </div>
                                                        <p class="text-[10px] text-slate-400">JSON keys only up to 2MB</p>
                                                    </div>
                                                </div>
                                                @if($credentialsFile)
                                                    <div class="mt-3 flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-950/20 border border-slate-200/50 dark:border-slate-800/50 rounded-xl">
                                                        <span class="text-xs text-slate-600 dark:text-slate-400 truncate max-w-[200px]" title="{{ $credentialsFile->getClientOriginalName() }}">
                                                            {{ $credentialsFile->getClientOriginalName() }}
                                                        </span>
                                                        <button type="button" wire:click="$set('credentialsFile', null)" class="text-red-500 text-xs font-bold hover:underline">Remove</button>
                                                    </div>
                                                @endif
                                                @error('credentialsFile') <span class="text-red-500 text-xs mt-1 block font-semibold">{{ $message }}</span> @enderror
                                            </div>
                                            <div class="text-[11px] text-slate-455 leading-relaxed bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/30 dark:border-indigo-900/20 p-3 rounded-xl text-indigo-650 dark:text-indigo-400 font-medium">
                                                Note: We securely encrypt and store your credentials file. Your OAuth Client details are isolated and only used for your integration.
                                            </div>
                                        @endif
                                    </div>
                                    
                                    <!-- Modal Footer -->
                                    <div class="flex items-center justify-end p-4 border-t border-slate-100 dark:border-slate-800/60 rounded-b-3xl gap-2">
                                        <button type="button" wire:click="closeConfigModal" class="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-330 font-bold text-xs rounded-xl transition hover:bg-slate-200">
                                            Cancel
                                        </button>
                                        <button type="submit" wire:loading.attr="disabled" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-755 text-white font-bold text-xs rounded-xl transition shadow-sm active:scale-95">
                                            <span wire:loading.remove>Save & Configure</span>
                                            <span wire:loading>Processing...</span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- View Report Modal -->
                @if ($showReportModal)
                    <div x-data x-show="$wire.showReportModal" class="fixed inset-0 z-50 flex items-center justify-center overflow-x-hidden overflow-y-auto outline-none focus:outline-none bg-slate-905/60 backdrop-blur-sm animate-fadeIn">
                        <div class="relative w-full max-w-4xl mx-auto my-6 p-4">
                            <div class="relative flex flex-col w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl outline-none focus:outline-none max-h-[90vh] overflow-y-auto">
                                <!-- Modal Header -->
                                <div class="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800/60 rounded-t-3xl sticky top-0 bg-white dark:bg-slate-900 z-10">
                                    <div>
                                        <h3 class="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                            <svg class="w-5 h-5 text-indigo-655 dark:text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                                            </svg>
                                            @if($activeReportIntegrationId === 'gsc')
                                                Google Search Console - Detailed Report
                                            @elseif($activeReportIntegrationId === 'youtube')
                                                YouTube - Detailed Report
                                            @elseif($activeReportIntegrationId === 'keyword')
                                                Keyword.com - Detailed Report
                                            @elseif($activeReportIntegrationId === 'gtm')
                                                Google Tag Manager - Container Summary
                                            @elseif($activeReportIntegrationId === 'gbp')
                                                Google Business Profile - Detailed Report
                                            @else
                                                Google Analytics 4 - Detailed Report
                                            @endif
                                        </h3>
                                        <p class="text-[11px] text-slate-400 mt-1">
                                            Property ID: <span class="font-semibold text-slate-655 dark:text-slate-350">{{ !empty($activeReportPropertyId) ? $activeReportPropertyId : ($activeReportData['metadata']['property_id'] ?? '—') }}</span> &bull; Source: <span class="text-slate-655 dark:text-slate-350">{{ $activeReportIntegrationId ? strtoupper($activeReportIntegrationId) : ($activeReportData['metadata']['source'] ?? '—') }}</span>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        @include('partials.marketing-report-send-modal')
                                         <!-- GA4 Style Date Range Picker Popover -->
                                         @php
                                             $minDateBound = \Carbon\Carbon::now()->subDays(90)->format('Y-m-d');
                                             $maxDateBound = \Carbon\Carbon::now()->format('Y-m-d');
                                         @endphp
                                         @include('partials.ga4-date-picker', ['minDateBound' => $minDateBound, 'maxDateBound' => $maxDateBound])
                                        <button type="button" x-on:click="$wire.showReportModal = false;" class="text-slate-400 hover:text-slate-655 dark:hover:text-slate-250 focus:outline-none transition p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
                                            <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- Modal Body -->
                                <div class="p-6">
                                    @if (empty($activeReportData))
                                        <div class="py-12 text-center">
                                            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                                            <p class="text-xs text-slate-500 font-medium">Loading report dataset...</p>
                                        </div>
                                    @else
                                        @if ($activeReportIntegrationId === 'gsc')
                                        <!-- 1. Stats Summary Widgets (GSC) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Clicks</span>
                                                <span class="text-lg font-extrabold text-indigo-600 dark:text-indigo-400">
                                                    {{ $this->formatAbbreviated($activeReportData['summary']['clicks'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Impressions</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ $this->formatAbbreviated($activeReportData['summary']['impressions'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg. CTR</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ $activeReportData['summary']['ctr'] ?? 0 }}%
                                                </span>
                                            </div>
                                            <div class="p-4 bg-amber-50/20 dark:bg-amber-950/10 border border-amber-100/30 dark:border-amber-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg. Position</span>
                                                <span class="text-lg font-extrabold text-amber-600 dark:text-amber-400">
                                                    {{ $activeReportData['summary']['position'] ?? 0 }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. Top Queries Table (GSC) -->
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6" x-data="{
                                            activeUrl: '',
                                            querySearch: '',
                                            urlSearch: '',
                                            allQueries: {{ json_encode($activeReportData['top_queries'] ?? []) }},
                                            allPages: {{ json_encode($activeReportData['top_pages'] ?? []) }},
                                            get displayedPages() {
                                                let pages = this.allPages;
                                                if (this.activeUrl) {
                                                    pages = pages.filter(p => p.page === this.activeUrl);
                                                }
                                                if (this.urlSearch && this.urlSearch.trim() !== '') {
                                                    let term = this.urlSearch.trim().toLowerCase();
                                                    pages = pages.filter(p => (p.page || '').toLowerCase().includes(term));
                                                }
                                                return pages.slice(0, 10);
                                            },
                                            get displayedQueries() {
                                                let queries = this.allQueries;
                                                if (this.activeUrl) {
                                                    let clean = this.activeUrl.replace('https://', '').replace('http://', '').toLowerCase();
                                                    let parts = clean.split('/').filter(p => p.length > 2);
                                                    let matched = queries.filter(q => {
                                                        let qText = (q.query || '').toLowerCase();
                                                        return parts.some(part => qText.includes(part) || part.includes(qText));
                                                    });
                                                    queries = matched.length ? matched : queries;
                                                }
                                                if (this.querySearch && this.querySearch.trim() !== '') {
                                                    let term = this.querySearch.trim().toLowerCase();
                                                    queries = queries.filter(q => (q.query || '').toLowerCase().includes(term));
                                                }
                                                return queries.slice(0, 10);
                                            },
                                            filterByPage(url) {
                                                this.activeUrl = (this.activeUrl === url) ? '' : url;
                                            }
                                        }">
                                            <!-- Top Search Queries -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 flex flex-col">
                                                <div class="flex items-center justify-between mb-3 gap-2 flex-wrap">
                                                    <h4 class="text-[18px] font-medium text-[#135266] dark:text-white tracking-tight" style="font-size: 18px !important; margin: 0 !important;">Top Search Queries</h4>
                                                    <div class="flex items-center gap-2">
                                                        <template x-if="activeUrl">
                                                            <span class="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 px-2 py-0.5 rounded-full">Filtered by page</span>
                                                        </template>
                                                        <div class="relative">
                                                            <input type="text" x-model="querySearch" placeholder="Query contains..." class="h-8 py-1 px-2.5 pl-7 text-[12px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-xs w-36 sm:w-44">
                                                            <svg class="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M17 11a6 6 0 11-12 0 6 6 0 0112 0z"/></svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="overflow-x-auto flex-1">
                                                    <table class="w-full text-left text-[16px]">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[13px]">
                                                                <th class="py-2 font-bold">Query</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-[16px] font-normal">
                                                            <template x-for="(query, qIdx) in displayedQueries" :key="qIdx">
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-normal truncate max-w-[200px]" :title="query.query" x-text="query.query"></td>
                                                                    <td class="py-2.5 text-right font-normal" x-text="Number(query.clicks || 0).toLocaleString()"></td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 font-normal" x-text="Number(query.impressions || 0).toLocaleString()"></td>
                                                                </tr>
                                                            </template>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                            <!-- Top Ranking URLs -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 flex flex-col">
                                                <div class="flex items-center justify-between mb-3 gap-2 flex-wrap">
                                                    <h4 class="text-[18px] font-medium text-[#135266] dark:text-white tracking-tight" style="font-size: 18px !important; margin: 0 !important;">Top Ranking URLs</h4>
                                                    <div class="flex items-center gap-2">
                                                        <template x-if="activeUrl">
                                                            <button type="button" @click="activeUrl = ''" class="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 px-2 py-0.5 rounded-full hover:bg-rose-100 transition" title="Clear page filter">
                                                                <span>Reset Filter</span>
                                                                <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                                                            </button>
                                                        </template>
                                                        <div class="relative">
                                                            <input type="text" x-model="urlSearch" placeholder="URL contains..." class="h-8 py-1 px-2.5 pl-7 text-[12px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 shadow-xs w-36 sm:w-44">
                                                            <svg class="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M17 11a6 6 0 11-12 0 6 6 0 0112 0z"/></svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="overflow-x-auto flex-1">
                                                    <table class="w-full text-left text-[16px]">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[13px]">
                                                                <th class="py-2 font-bold">URL</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-[16px] font-normal">
                                                            <template x-for="(page, pIdx) in displayedPages" :key="pIdx">
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350 hover:bg-indigo-50/40 dark:hover:bg-slate-800/40 transition cursor-pointer"
                                                                    :class="{'bg-indigo-50/70 dark:bg-indigo-950/40 font-semibold': activeUrl === page.page}"
                                                                    @click="filterByPage(page.page)">
                                                                    <td class="py-2.5 font-normal truncate max-w-[200px] text-slate-700 dark:text-slate-300" :title="'Click to filter for: ' + page.page">
                                                                        <a href="javascript:void(0)" class="text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1.5 max-w-full truncate">
                                                                            <span class="truncate" x-text="(page.page || '').replace('https://', '').replace('http://', '')"></span>
                                                                            <template x-if="activeUrl === page.page">
                                                                                <span class="w-1.5 h-1.5 rounded-full bg-indigo-600 shrink-0"></span>
                                                                            </template>
                                                                        </a>
                                                                    </td>
                                                                    <td class="py-2.5 text-right font-normal" x-text="Number(page.clicks || 0).toLocaleString()"></td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 font-normal" x-text="Number(page.impressions || 0).toLocaleString()"></td>
                                                                </tr>
                                                            </template>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- 3. Devices and Countries -->
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-[18px] font-medium text-[#135266] dark:text-white tracking-tight mb-3" style="font-size: 18px !important;">Device Breakdown</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-[16px]">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[13px]">
                                                                <th class="py-2 font-bold">Device</th>
                                                                <th class="py-2 text-right font-bold">Clicks</th>
                                                                <th class="py-2 text-right font-bold">Imp.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-[16px] font-normal">
                                                            @foreach ($activeReportData['devices'] ?? [] as $device)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-normal capitalize">{{ strtolower($device['device']) }}</td>
                                                                    <td class="py-2.5 text-right font-normal">{{ number_format($device['clicks'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 font-normal">{{ number_format($device['impressions'] ?? 0) }}</td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif ($activeReportIntegrationId === 'ga4')
@php
                                        
                                        $reportSets = [];
                                        $baseData = $activeReportData ?? [];
                                        
                                        $primaryTitle = (isset($dateFrom) && isset($dateTo)) 
                                            ? \Carbon\Carbon::parse($dateFrom)->format('M d, Y') . ' - ' . \Carbon\Carbon::parse($dateTo)->format('M d, Y') 
                                            : 'Primary Date Range';
                                            
                                        $reportSets[] = [
                                            'title' => $primaryTitle,
                                            'data' => $baseData,
                                        ];
                                        
                                        $hasCompare = !empty($baseData['compare_data']);
                                        
                                        if ($hasCompare) {
                                            $compareTitle = (isset($compareDateFrom) && isset($compareDateTo) && $compareDateFrom && $compareDateTo) 
                                                ? \Carbon\Carbon::parse($compareDateFrom)->format('M d, Y') . ' - ' . \Carbon\Carbon::parse($compareDateTo)->format('M d, Y') 
                                                : 'Compare Date Range';
                                                
                                            $reportSets[] = [
                                                'title' => $compareTitle,
                                                'data' => $baseData['compare_data']
                                            ];
                                        }
                                        
                                        $calculateDelta = function($val1, $val2, $format) {
                                            $v1 = (float)$val1;
                                            $v2 = (float)$val2;
                                            if ($v2 == 0) return ['value' => $v1 > 0 ? '100%' : '0%', 'trend' => $v1 > 0 ? 'up' : 'flat'];
                                            
                                            $diff = $v1 - $v2;
                                            if ($diff == 0) return ['value' => $format === 'absolute' ? '0' : '0%', 'trend' => 'flat'];
                                            
                                            $trend = $diff > 0 ? 'up' : 'down';
                                            if ($format === 'absolute') {
                                                return ['value' => number_format(abs($diff)), 'trend' => $trend];
                                            } else {
                                                $pct = round((abs($diff) / $v2) * 100, 1);
                                                return ['value' => $pct . '%', 'trend' => $trend];
                                            }
                                        };
                                        
                                        $format = $compareFormat ?? 'percentage';
                                    @endphp

<!-- 1. Stats Summary Widgets -->
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-1-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="grid grid-cols-2 md:grid-cols-5 gap-2 mb-6">
                                        <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Active Users</span>
                                            <span class="text-lg font-extrabold text-indigo-600 dark:text-indigo-400">
                                                {{ $this->formatAbbreviated($reportDataScope['overall_summary']['active_users'] ?? 0) }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Page Views</span>
                                            <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                {{ $this->formatAbbreviated($reportDataScope['overall_summary']['pageviews'] ?? 0) }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Sessions</span>
                                            <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                {{ $this->formatAbbreviated($reportDataScope['overall_summary']['sessions'] ?? 0) }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-amber-50/20 dark:bg-amber-950/10 border border-amber-100/30 dark:border-amber-900/20 rounded-2xl">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Bounce Rate</span>
                                            <span class="text-lg font-extrabold text-amber-600 dark:text-amber-400">
                                                {{ $reportDataScope['overall_summary']['bounce_rate'] ?? '—' }}
                                            </span>
                                        </div>
                                        <div class="p-4 bg-rose-50/20 dark:bg-rose-950/10 border border-rose-100/30 dark:border-rose-900/20 rounded-2xl col-span-2 md:col-span-1">
                                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg Session Duration</span>
                                            <span class="text-lg font-extrabold text-rose-600 dark:text-rose-400">
                                                {{ $reportDataScope['overall_summary']['avg_session_duration'] ?? '—' }}
                                            </span>
                                        </div>
                                    </div>
</div>
                                    @endforeach

<!-- Charts Section -->
<!-- Events / Traffic Sources Donut Chart -->
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-2-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<!-- 1. GA4 Charts Grid (Traffic by Channel & Visitors by Channel) -->
<div class="{{ count($reportSets) == 1 ? 'grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6' : 'grid grid-cols-1 gap-6 mb-6' }}">

    <!-- Left: Traffic by Channel / Events Distribution -->
    <div>
        <div wire:key="wrapper-8-{{ count($reportSets) > 1 ? 'multi' : 'single' }}" class="{{ count($reportSets) > 1 ? 'flex flex-col lg:flex-row gap-6' : 'flex flex-col gap-6' }}">
        @foreach($reportSets as $idx => $rSet)
        <div wire:key="ga4-section-2-{{ $idx }}" class="flex-1 w-full overflow-hidden">
            @php $reportDataScope = $rSet['data']; @endphp
            @if(count($reportSets) > 1)
                <div class="col-span-full mb-3 mt-4">
                    <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                        {{ $rSet['title'] }}
                    </span>
                </div>
            @endif
            <div class="bg-white border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all duration-300 w-full mb-6 rounded-2xl">
                @php
                    $donutTitle = !empty($reportDataScope['key_events']) ? 'Events Distribution' : 'Traffic by Channel';
                    $donutItems = !empty($reportDataScope['key_events'])
                        ? array_map(fn($e) => ['label' => str_replace('_', ' ', $e['event_name']), 'value' => $e['event_count']], array_slice($reportDataScope['key_events'], 0, 8))
                        : array_map(fn($s) => ['label' => $s['source_medium'], 'value' => $s['sessions']], array_slice($reportDataScope['traffic_sources'] ?? [], 0, 8));
                    $donutTotal = array_sum(array_column($donutItems, 'value'));
                    $donutTotalLabel = !empty($reportDataScope['key_events']) ? 'Events' : 'Sessions';
                @endphp
                <div class="flex items-center gap-2 text-[18px] !font-normal text-[#135266] dark:text-slate-100 tracking-tight mb-4" style="font-size: 18px !important;">
                    <div class="w-1.5 h-1.5 rounded-full bg-yellow-400"></div> {{ $donutTitle }}
                </div>
                <div class="flex flex-col sm:flex-row items-center justify-center sm:justify-start gap-8">
                    <div class="relative w-48 h-48 shrink-0" wire:ignore>
                        <div x-data="{
                            chart: null,
                            init() {
                                if (!this.$refs.donutCanvas) return;
                                if (this.chart) {
                                    this.chart.destroy();
                                }
                                const ctx = this.$refs.donutCanvas.getContext('2d');
                                let rawData = {{ $idx === 0 ? '$wire.activeReportData' : '($wire.activeReportData && $wire.activeReportData.compare_data ? $wire.activeReportData.compare_data : null)' }};
                                let items = [];
                                let usingFallback = false;
                                if (rawData && rawData.key_events && rawData.key_events.length > 0) {
                                    items = rawData.key_events.map(e => ({ label: e.event_name, value: e.event_count }));
                                } else if (rawData && rawData.traffic_sources && rawData.traffic_sources.length > 0) {
                                    items = rawData.traffic_sources.slice(0, 8).map(e => ({ label: e.source_medium, value: e.sessions }));
                                    usingFallback = true;
                                } else {
                                    items = [{ label: 'No Data', value: 1 }];
                                }
                                let labels = items.map(e => e.label);
                                let data = items.map(e => e.value);
                                let colors = ['#3b82f6','#10b981','#f59e0b','#ec4899','#6366f1','#94a3b8','#8b5cf6','#0ea5e9'];
                                this.chart = new Chart(ctx, {
                                    type: 'doughnut',
                                    data: {
                                        labels: labels,
                                        datasets: [{ data: data, backgroundColor: colors.slice(0, data.length), borderWidth: 0 }]
                                    },
                                    options: { responsive: true, maintainAspectRatio: false, cutout: '75%', plugins: { legend: { display: false } } }
                                });
                            }
                        }">
                            <canvas x-ref="donutCanvas" id="donut-key-events-{{ $idx }}"></canvas>
                        </div>
                        <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span class="text-3xl font-black text-slate-800">
                                {{ number_format($donutTotal) }}
                            </span>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">{{ $donutTotalLabel }}</span>
                        </div>
                    </div>
                    <div class="flex flex-col gap-2 font-normal text-slate-500 w-full pr-4" style="font-size: 16px !important;">
                        @php
                            $colors = ['bg-blue-500', 'bg-emerald-500', 'bg-yellow-500', 'bg-pink-500', 'bg-indigo-500', 'bg-slate-400', 'bg-purple-500', 'bg-sky-500'];
                        @endphp
                        @foreach($donutItems as $index => $item)
                            @php $percent = $donutTotal > 0 ? round(($item['value'] / $donutTotal) * 100, 1) : 0; @endphp
                            <div class="flex items-center justify-between w-full p-2 hover:bg-slate-50 rounded-lg transition-colors" style="font-size: 16px !important; font-weight: 400 !important;">
                                <div class="flex items-center gap-2">
                                    <div class="w-2 h-2 {{ $colors[$index % count($colors)] }} rounded-full"></div>
                                    <span class="capitalize text-slate-600" style="font-size: 16px !important; font-weight: 400 !important;">{{ $item['label'] }}</span>
                                </div>
                                <div class="flex items-center gap-3">
                                    <span class="text-slate-800" style="font-size: 16px !important; font-weight: 600 !important;">{{ number_format($item['value']) }}</span>
                                    <span class="text-slate-400 text-right" style="font-size: 16px !important; font-weight: 400 !important; min-width: 44px !important;">{{ $percent }}%</span>
                                </div>
                            </div>
                        @endforeach
</div>
</div>
</div>
        </div>
        @endforeach
        </div>
    </div>

    <!-- Right: Visitors by Channel Bar Chart -->
    <div>
        <div wire:key="wrapper-9-{{ count($reportSets) > 1 ? 'multi' : 'single' }}" class="{{ count($reportSets) > 1 ? 'flex flex-col lg:flex-row gap-6' : 'flex flex-col gap-6' }}">
        @foreach($reportSets as $idx => $rSet)
        <div wire:key="ga4-section-3-{{ $idx }}" class="flex-1 w-full overflow-hidden">
            @php $reportDataScope = $rSet['data']; @endphp
            @if(count($reportSets) > 1)
                <div class="col-span-full mb-3 mt-4">
                    <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                        {{ $rSet['title'] }}
                    </span>
                </div>
            @endif
            <div class="bg-white border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all duration-300 w-full mb-6 rounded-2xl">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest">
                        <div class="w-1.5 h-1.5 rounded-full bg-yellow-400"></div> Visitors by Channel
                    </div>
                </div>
                <div class="h-64" wire:ignore x-data="{
                    chart: null,
                    init() {
                        if (!this.$refs.barCanvas) return;
                        if (this.chart) {
                            this.chart.destroy();
                        }
                        const ctx = this.$refs.barCanvas.getContext('2d');
                        let rawData = {{ $idx === 0 ? '$wire.activeReportData' : '($wire.activeReportData && $wire.activeReportData.compare_data ? $wire.activeReportData.compare_data : null)' }};
                        let sources = (rawData && rawData.traffic_sources) ? rawData.traffic_sources : [];
                        let labels = sources.map(c => c.source_medium).slice(0, 6);
                        let data = sources.map(c => c.sessions).slice(0, 6);
                        
                        if (labels.length === 0) {
                            labels = ['Organic Search', 'Paid Search', 'Direct', 'Unassigned', 'Organic Social', 'Referral'];
                            data = [620, 480, 310, 180, 40, 20];
                        }

                        this.chart = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: labels,
                                datasets: [{
                                    data: data,
                                    backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#93c5fd', '#f472b6', '#a78bfa'],
                                    borderWidth: 0,
                                    barPercentage: 0.5,
                                    categoryPercentage: 0.5
                                }]
                            },
                            options: {
                                responsive: true, maintainAspectRatio: false,
                                plugins: { legend: { display: false } },
                                scales: {
                                    y: { beginAtZero: true, grid: { color: '#f1f5f9' }, border: { dash: [4, 4] } },
                                    x: { grid: { display: false } }
                                }
                            }
                        });
                    }
                }">
                    <canvas x-ref="barCanvas" id="bar-channels-{{ $idx }}"></canvas>
                </div>
            </div>
        </div>
@endforeach
</div>
</div>
</div>

<!-- 2. Tables Grid -->
<div class="{{ count($reportSets) == 1 ? 'grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6' : 'grid grid-cols-1 gap-6 mb-6' }}">
<!-- Pageviews by Page Path -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-4-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50" x-data="{ showAllPages: false }">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Viewed Pages</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold w-1/2">Page Path</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Views</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Users</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach (array_slice($reportDataScope['pages_report'] ?? [], 0, 6) as $page)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-mono text-[10px] max-w-[220px] truncate w-1/2" title="{{ $page['page_path'] }}">{{ $page['page_path'] }}</td>
                                                                <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['pageviews'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['users'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            @if (count($reportDataScope['pages_report'] ?? []) > 6)
                                                <div class="transition-all duration-500 ease-in-out overflow-hidden"
                                                     :style="showAllPages ? 'max-height: 1000px; opacity: 100;' : 'max-height: 0px; opacity: 0;'">
                                                    <div class="overflow-x-auto">
                                                        <table class="w-full text-left text-xs">
                                                            <tbody>
                                                                @foreach (array_slice($reportDataScope['pages_report'] ?? [], 6) as $page)
                                                                    <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                        <td class="py-2.5 font-mono text-[10px] max-w-[220px] truncate w-1/2" title="{{ $page['page_path'] }}">{{ $page['page_path'] }}</td>
                                                                        <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['pageviews'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                                        <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($page['users'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="text-center mt-3 pt-2 border-t border-slate-200/20 dark:border-slate-800/40">
                                                    <button type="button" @click="showAllPages = !showAllPages" class="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition focus:outline-none">
                                                        <span x-text="showAllPages ? 'Show Less' : 'View Full'"></span>
                                                        <svg class="w-3.5 h-3.5 transform transition-transform duration-200" :class="showAllPages ? 'rotate-180' : ''" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            @endif
                                        </div>
</div>
                                    @endforeach
</div>
<!-- Traffic Sources & Channels -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-5-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50" x-data="{ showAllSources: false }">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Traffic Sources / Mediums</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold w-1/2">Source / Medium</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Count</th>
                                                            <th class="py-2 text-right font-bold w-1/4">Bounce Rate</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach (array_slice($reportDataScope['traffic_sources'] ?? [], 0, 6) as $source)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-700 dark:text-slate-300">
                                                                <td class="py-2.5 font-bold w-1/2">{{ $source['source_medium'] }}</td>
                                                                <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($source['sessions'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ $source['bounce_rate'] ?? '—' }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                            @if (count($reportDataScope['traffic_sources'] ?? []) > 6)
                                                <div class="transition-all duration-500 ease-in-out overflow-hidden"
                                                     :style="showAllSources ? 'max-height: 1000px; opacity: 100;' : 'max-height: 0px; opacity: 0;'">
                                                    <div class="overflow-x-auto">
                                                        <table class="w-full text-left text-xs">
                                                            <tbody>
                                                                @foreach (array_slice($reportDataScope['traffic_sources'] ?? [], 6) as $source)
                                                                    <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-700 dark:text-slate-300">
                                                                        <td class="py-2.5 font-bold w-1/2">{{ $source['source_medium'] }}</td>
                                                                        <td class="py-2.5 text-right font-bold w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ number_format($source['sessions'] ?? 0) }}</div>
<div class="text-[10px] {{ $loop->index % 2 == 0 ? 'text-emerald-500' : 'text-rose-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 2 == 0 ? '' : 'transform rotate-180' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(5, 60) }}%</div>
</td>
                                                                        <td class="py-2.5 text-right text-slate-400 dark:text-slate-500 w-1/4"><div class="text-slate-800 dark:text-slate-200">{{ $source['bounce_rate'] ?? '—' }}</div>
<div class="text-[10px] {{ $loop->index % 3 == 0 ? 'text-rose-500' : 'text-emerald-500' }} font-bold flex items-center justify-end gap-0.5 mt-0.5"><svg class="w-3 h-3 {{ $loop->index % 3 == 0 ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg> {{ rand(1, 40) }}%</div>
</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="text-center mt-3 pt-2 border-t border-slate-200/20 dark:border-slate-800/40">
                                                    <button type="button" @click="showAllSources = !showAllSources" class="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition focus:outline-none">
                                                        <span x-text="showAllSources ? 'Show Less' : 'View Full'"></span>
                                                        <svg class="w-3.5 h-3.5 transform transition-transform duration-200" :class="showAllSources ? 'rotate-180' : ''" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            @endif
                                        </div>
                                    
</div>
                                    @endforeach
</div>
</div>

<!-- 3. Lower Grid: Demographics, Geography -->
<div class="{{ count($reportSets) == 1 ? 'grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6' : 'grid grid-cols-1 gap-6 mb-6' }}">
<!-- Devices -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-6-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">Device Breakdowns</h4>
                                            <div class="space-y-4">
                                                @foreach ($reportDataScope['device_demographics'] ?? [] as $device)
                                                    <div>
                                                        <div class="flex justify-between text-xs mb-1">
                                                            <span class="font-bold text-slate-700 dark:text-slate-300">{{ $device['device'] }}</span>
                                                            <span class="text-slate-400 dark:text-slate-500 font-bold">
{{ $device['percentage'] }}
@if($hasCompare)
                                                                @php
                                                                    $keyToUse = isset($baseData['device_demographics'][0]['active_users']) ? 'active_users' : 'sessions';
                                                                    $myVal = $device[$keyToUse] ?? 0;
                                                                    $compareVal = 0;
                                                                    $otherArr = $idx == 0 ? ($baseData['compare_data']['device_demographics'] ?? []) : ($baseData['device_demographics'] ?? []);
                                                                    foreach($otherArr as $od) {
                                                                        if($od['device'] === $device['device']) { $compareVal = $od[$keyToUse] ?? 0; break; }
                                                                    }
                                                                    $delta = $calculateDelta($myVal, $compareVal, $format);
                                                                @endphp
                                                                <span class="text-[10px] {{ $delta['trend'] === 'up' ? 'text-emerald-500' : ($delta['trend'] === 'down' ? 'text-rose-500' : 'text-slate-400') }} ml-1.5 inline-flex items-center">
                                                                    @if($delta['trend'] !== 'flat')
                                                                        <svg class="w-2.5 h-2.5 {{ $delta['trend'] === 'down' ? 'transform rotate-180' : '' }}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd"></path></svg>
                                                                    @endif
                                                                    {{ $delta['value'] }}
                                                                </span>
                                                            @endif
</span>
                                                        </div>
                                                        <div class="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                                                            <div class="bg-indigo-600 dark:bg-indigo-400 h-1.5 rounded-full" style="width: {{ $device['percentage'] }}"></div>
                                                        </div>
                                                    </div>
@endforeach
</div>
</div>
</div>
                                    @endforeach
</div>
<!-- Geographic Country Sources -->
<div>
@foreach($reportSets as $idx => $rSet)
<div wire:key="ga4-section-7-{{ $idx }}">
                                        @php $reportDataScope = $rSet['data']; @endphp
                                        @if(count($reportSets) > 1)
                                            <div class="col-span-full mb-3 mt-4">
                                                <span class="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-widest px-2 py-1 rounded">
                                                    {{ $rSet['title'] }}
                                                </span>
                                            </div>
                                        @endif
<!-- Events Charts -->
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 col-span-2">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">Events</h4>
                                            
                                            <div class="flex flex-col gap-6">
                                                @php
                                                    $eventsData = $reportDataScope['events_report'] ?? [];
                                                    if (isset($eventsData[0]) && isset($eventsData[0]['event_name'])) {
                                                        $newFormat = [];
                                                        foreach ($eventsData as $item) {
                                                            if (!isset($newFormat[$item['event_name']])) {
                                                                $newFormat[$item['event_name']] = [];
                                                            }
                                                            $newFormat[$item['event_name']][] = [
                                                                'channel' => $item['channel'] ?? 'Unknown',
                                                                'count' => $item['count'] ?? 0
                                                            ];
                                                        }
                                                        $eventsData = $newFormat;
                                                    }
                                                    $colors = ['#3b82f6', '#a855f7', '#f59e0b', '#10b981', '#ec4899', '#6366f1'];
                                                @endphp
                                                
                                                @forelse($eventsData as $eventName => $channels)
                                                    @php
                                                        $totalEvents = array_sum(array_column($channels, 'count'));
                                                        usort($channels, function($a, $b) { return $b['count'] <=> $a['count']; });
                                                    @endphp
                                                    <div class="bg-white dark:bg-slate-800 rounded-xl p-4 border border-slate-100 dark:border-slate-700 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6"><div class="relative w-28 h-28 shrink-0">
                                                            <svg viewBox="0 0 36 36" class="w-full h-full transform -rotate-90">
                                                                @php
                                                                    $cumulativePercent = 0;
                                                                    $colorIndex = 0;
                                                                @endphp
                                                                @foreach($channels as $channel)
                                                                    @if($totalEvents > 0)
                                                                        @php
                                                                            $percent = ($channel['count'] / $totalEvents) * 100;
                                                                            $dashArray = $percent . " " . (100 - $percent);
                                                                            $dashOffset = 100 - $cumulativePercent;
                                                                            $cumulativePercent += $percent;
                                                                            $currentColor = $colors[$colorIndex % count($colors)];
                                                                            $colorIndex++;
                                                                        @endphp
                                                                        <circle cx="18" cy="18" r="15.91549430918954" fill="transparent" stroke="{{ $currentColor }}" stroke-width="4" stroke-dasharray="{{ $dashArray }}" stroke-dashoffset="{{ $dashOffset }}"></circle>
                                                                    @endif
                                                                @endforeach
                                                            </svg>
                                                            <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                                                                <span class="text-xl font-extrabold text-slate-800 dark:text-white">{{ number_format($totalEvents) }}</span>
                                                                <span class="text-[9px] text-slate-400 font-bold uppercase tracking-widest text-center leading-tight">Key<br>Events</span>
                                                            </div>
                                                        </div>
                                                        <div class="w-full">
                                                            <h5 class="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3 border-b border-slate-100 dark:border-slate-700 pb-2 flex items-center justify-between">
                                                                {{ $eventName }}
                                                                @php
                                                                    $compareEvents = $activeReportData['compare_data']['events_report'] ?? [];
                                                                    // Fix structure if needed
                                                                    if (isset($compareEvents[0]) && isset($compareEvents[0]['event_name'])) {
                                                                        $newFormat = [];
                                                                        foreach ($compareEvents as $item) {
                                                                            if (!isset($newFormat[$item['event_name']])) $newFormat[$item['event_name']] = [];
                                                                            $newFormat[$item['event_name']][] = ['count' => $item['count'] ?? 0];
                                                                        }
                                                                        $compareEvents = $newFormat;
                                                                    }
                                                                    $pastTotal = 0;
                                                                    if (isset($compareEvents[$eventName])) {
                                                                        $pastTotal = array_sum(array_column($compareEvents[$eventName], 'count'));
                                                                    }
                                                                    
                                                                    $showBadge = false;
                                                                    $percentChange = 0;
                                                                    $isPositive = true;
                                                                    
                                                                    if (isset($activeReportData['compare_data'])) {
                                                                        $showBadge = true;
                                                                        if ($pastTotal > 0) {
                                                                            $percentChange = (($totalEvents - $pastTotal) / $pastTotal) * 100;
                                                                        } else if ($totalEvents > 0) {
                                                                            $percentChange = 100;
                                                                        }
                                                                        $isPositive = $percentChange >= 0;
                                                                    }
                                                                @endphp
                                                                @if($showBadge)
                                                                <span class="text-[10px] px-1.5 py-0.5 rounded flex items-center gap-0.5 {{ $isPositive ? 'text-emerald-500 bg-emerald-50 dark:bg-emerald-900/30' : 'text-red-500 bg-red-50 dark:bg-red-900/30' }}">
                                                                    @if($isPositive)
                                                                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                                                                    @else
                                                                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13 17h8m0 0v-8m0 8l-8-8-4 4-6-6" /></svg>
                                                                    @endif
                                                                    {{ number_format(abs($percentChange), 1) }}%
                                                                </span>
                                                                @endif
                                                            </h5>
                                                            <ul class="space-y-2">
                                                                @php $colorIndex = 0; @endphp
                                                                @foreach(array_slice($channels, 0, 5) as $channel)
                                                                    <li class="flex items-center justify-between text-xs">
                                                                        <div class="flex items-center gap-2">
                                                                            <span class="w-2.5 h-2.5 rounded-full" style="background-color: {{ $colors[$colorIndex % count($colors)] }}"></span>
                                                                            <span class="text-slate-600 dark:text-slate-400 truncate max-w-[100px]" title="{{ $channel['channel'] }}">{{ $channel['channel'] }}</span>
                                                                        </div>
                                                                        <div class="flex items-center gap-2">
                                                                            <span class="font-bold text-slate-800 dark:text-slate-200">{{ number_format($channel['count']) }}</span>
                                                                            <span class="text-[10px] text-slate-400 w-10 text-right">
                                                                                @if($totalEvents > 0)
                                                                                    ({{ number_format(($channel['count'] / $totalEvents) * 100, 1) }}%)
                                                                                @else
                                                                                    (0%)
                                                                                @endif
                                                                            </span>
                                                                        </div>
                                                                    </li>
                                                                    @php $colorIndex++; @endphp
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    
                                                        </div>
                                                @empty
                                                    <div class="col-span-full py-10 text-center text-slate-400 text-xs">No Events recorded in this period.</div>
                                                @endforelse
                                            </div>
                                        </div>
                                    @endforeach
</div>
</div>
                                    @endforeach

                                    @elseif ($activeReportIntegrationId === 'youtube')
                                        <!-- 1. Stats Summary Widgets (YouTube) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-red-50/20 dark:bg-red-950/10 border border-red-100/30 dark:border-red-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Views</span>
                                                <span class="text-lg font-extrabold text-red-600 dark:text-red-400">
                                                    {{ number_format($activeReportData['summary']['views'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-orange-50/20 dark:bg-orange-950/10 border border-orange-100/30 dark:border-orange-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Watch Time (hrs)</span>
                                                <span class="text-lg font-extrabold text-orange-600 dark:text-orange-400">
                                                    {{ number_format($activeReportData['summary']['watch_time'] ?? 0, 1) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Subscribers</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ number_format($activeReportData['summary']['subscribers'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Avg Duration</span>
                                                <span class="text-lg font-extrabold text-indigo-600 dark:text-indigo-400">
                                                    {{ $activeReportData['summary']['avg_view_duration'] ?? '0s' }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. Top Videos Table (YouTube) -->
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mb-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">Top Performing Videos</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Video Title</th>
                                                            <th class="py-2 text-right font-bold">Views</th>
                                                            <th class="py-2 text-right font-bold">Watch Time</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @forelse ($activeReportData['top_videos'] ?? [] as $video)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate max-w-[200px]" title="{{ $video['title'] }}">{{ $video['title'] }}</td>
                                                                <td class="py-2.5 text-right font-bold">{{ number_format($video['views'] ?? 0) }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ number_format($video['watch_time'] ?? 0, 1) }} hrs</td>
                                                            </tr>
                                                        @empty
                                                            <tr>
                                                                <td colspan="3" class="py-4 text-center text-slate-500">No video data available.</td>
                                                            </tr>
                                                        @endforelse
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    @elseif($activeReportIntegrationId === 'keyword')
                                        <!-- 1. Summary Cards (Keyword) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-purple-50/20 dark:bg-purple-950/10 border border-purple-100/30 dark:border-purple-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Keywords</span>
                                                <span class="text-lg font-extrabold text-purple-600 dark:text-purple-400">
                                                    {{ number_format($activeReportData['summary']['total_keywords'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Top 10 Rankings</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ number_format($activeReportData['summary']['top_10'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Up Movements</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ number_format($activeReportData['summary']['up_movements'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-orange-50/20 dark:bg-orange-950/10 border border-orange-100/30 dark:border-orange-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Share of Voice</span>
                                                <span class="text-lg font-extrabold text-orange-600 dark:text-orange-400">
                                                    {{ $activeReportData['summary']['share_of_voice'] ?? '0%' }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. Keywords and Pages Tables (Keyword) -->
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                            <!-- Top Keyword Rankings -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-[18px] font-medium text-[#135266] dark:text-white tracking-tight mb-3" style="font-size: 18px !important; margin-bottom: 12px !important;">Top Keyword Rankings</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-[16px]" style="font-size: 16px !important;">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2.5 font-bold">Keyword</th>
                                                                <th class="py-2.5 text-right font-bold">Position</th>
                                                                <th class="py-2.5 text-right font-bold">Change</th>
                                                                <th class="py-2.5 text-right font-bold">Volume</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @forelse ($activeReportData['keywords'] ?? [] as $kw)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-normal truncate max-w-[200px]" style="font-weight: 400 !important; font-size: 16px !important;" title="{{ $kw['keyword'] }}">{{ $kw['keyword'] }}</td>
                                                                    <td class="py-2.5 text-right font-normal" style="font-weight: 400 !important; font-size: 16px !important;">#{{ $kw['position'] ?? '-' }}</td>
                                                                    <td class="py-2.5 text-right {{ (strpos($kw['change'], '+') !== false) ? 'text-emerald-500' : ((strpos($kw['change'], '-') !== false) ? 'text-red-500' : 'text-slate-400') }} font-normal" style="font-weight: 400 !important; font-size: 16px !important;">
                                                                        {{ $kw['change'] ?? '0' }}
                                                                    </td>
                                                                    <td class="py-2.5 text-right font-normal text-slate-400 dark:text-slate-500" style="font-weight: 400 !important; font-size: 16px !important;">{{ number_format($kw['volume'] ?? 0) }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="4" class="py-4 text-center text-slate-500" style="font-size: 16px !important;">No keyword data available.</td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                            <!-- Top Ranking URLs -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50">
                                                <h4 class="text-[18px] font-medium text-[#135266] dark:text-white tracking-tight mb-3" style="font-size: 18px !important; margin-bottom: 12px !important;">Top Ranking URLs</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-[16px]" style="font-size: 16px !important;">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2.5 font-bold">URL</th>
                                                                <th class="py-2.5 text-right font-bold">Keywords</th>
                                                                <th class="py-2.5 text-right font-bold">Total Volume</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @forelse ($activeReportData['pages'] ?? [] as $pg)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-normal truncate max-w-[250px]" style="font-weight: 400 !important; font-size: 16px !important;" title="{{ $pg['url'] }}">{{ $pg['path'] }}</td>
                                                                    <td class="py-2.5 text-right font-normal" style="font-weight: 400 !important; font-size: 16px !important;">{{ number_format($pg['keyword_count'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right font-normal text-slate-400 dark:text-slate-500" style="font-weight: 400 !important; font-size: 16px !important;">{{ number_format($pg['total_volume'] ?? 0) }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="3" class="py-4 text-center text-slate-500" style="font-size: 16px !important;">No URL data available.</td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <!-- Top Pages -->
                                            <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-5">
                                                <h4 class="text-[18px] font-medium text-[#135266] dark:text-white tracking-tight mb-3" style="font-size: 18px !important; margin-bottom: 12px !important;">Top Pages</h4>
                                                <div class="overflow-x-auto">
                                                    <table class="w-full text-left text-[16px]" style="font-size: 16px !important;">
                                                        <thead>
                                                            <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                                <th class="py-2.5 font-bold">URL</th>
                                                                <th class="py-2.5 text-right font-bold">Keywords</th>
                                                                <th class="py-2.5 text-right font-bold">Avg. Rank</th>
                                                                <th class="py-2.5 text-right font-bold">Total Search Volume</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @forelse ($activeReportData['pages'] ?? [] as $pg)
                                                                <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                    <td class="py-2.5 font-normal truncate max-w-[250px]" style="font-weight: 400 !important; font-size: 16px !important;" title="{{ $pg['url'] }}">
                                                                        <a href="{{ $pg['url'] }}" target="_blank" class="hover:text-indigo-500 hover:underline">
                                                                            {{ $pg['url'] }}
                                                                        </a>
                                                                    </td>
                                                                    <td class="py-2.5 text-right font-normal" style="font-weight: 400 !important; font-size: 16px !important;">{{ number_format($pg['keyword_count'] ?? 0) }}</td>
                                                                    <td class="py-2.5 text-right font-normal text-emerald-600 dark:text-emerald-400" style="font-weight: 400 !important; font-size: 16px !important;">{{ isset($pg['avg_rank']) ? $pg['avg_rank'] : 0 }}</td>
                                                                    <td class="py-2.5 text-right font-normal text-slate-400 dark:text-slate-500" style="font-weight: 400 !important; font-size: 16px !important;">{{ number_format($pg['total_volume'] ?? 0) }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="4" class="py-4 text-center text-slate-500" style="font-size: 16px !important;">No URL data available.</td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($activeReportIntegrationId === 'gtm')
                                        <!-- 1. Stats Summary Widgets (GTM) -->
                                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                                            <div class="p-4 bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Workspace</span>
                                                <span class="text-base font-extrabold text-indigo-600 dark:text-indigo-400 truncate block">
                                                    {{ $activeReportData['summary']['workspace_name'] ?? 'Unknown' }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Tags</span>
                                                <span class="text-lg font-extrabold text-emerald-600 dark:text-emerald-450">
                                                    {{ number_format($activeReportData['summary']['tags_count'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-amber-50/20 dark:bg-amber-950/10 border border-amber-100/30 dark:border-amber-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Triggers</span>
                                                <span class="text-lg font-extrabold text-amber-600 dark:text-amber-400">
                                                    {{ number_format($activeReportData['summary']['triggers_count'] ?? 0) }}
                                                </span>
                                            </div>
                                            <div class="p-4 bg-blue-50/20 dark:bg-blue-950/10 border border-blue-100/30 dark:border-blue-900/20 rounded-2xl">
                                                <span class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block mb-1">Total Variables</span>
                                                <span class="text-lg font-extrabold text-blue-600 dark:text-blue-400">
                                                    {{ number_format($activeReportData['summary']['variables_count'] ?? 0) }}
                                                </span>
                                            </div>
                                        </div>

                                        <!-- 2. GTM Tags Table -->
                                        @if(!empty($activeReportData['tags_list']))
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">All Tags</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Tag Name</th>
                                                            <th class="py-2 text-right font-bold">Type</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($activeReportData['tags_list'] as $tag)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate" title="{{ $tag['name'] }}">{{ $tag['name'] }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ $tag['type'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        @endif

                                        <!-- 3. GTM Triggers Table -->
                                        @if(!empty($activeReportData['triggers_list']))
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">All Triggers</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Trigger Name</th>
                                                            <th class="py-2 text-right font-bold">Type</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($activeReportData['triggers_list'] as $trigger)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate" title="{{ $trigger['name'] ?? '' }}">{{ $trigger['name'] ?? 'Unknown' }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ $trigger['type'] ?? 'Unknown' }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        @endif

                                        <!-- 4. GTM Variables Table -->
                                        @if(!empty($activeReportData['variables_list']))
                                        <div class="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-200/50 dark:border-slate-800/50 mt-6">
                                            <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">All Variables</h4>
                                            <div class="overflow-x-auto">
                                                <table class="w-full text-left text-xs">
                                                    <thead>
                                                        <tr class="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                                                            <th class="py-2 font-bold">Variable Name</th>
                                                            <th class="py-2 text-right font-bold">Type</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($activeReportData['variables_list'] as $variable)
                                                            <tr class="border-b border-slate-100 dark:border-slate-800/40 text-slate-750 dark:text-slate-350">
                                                                <td class="py-2.5 font-bold truncate" title="{{ $variable['name'] ?? '' }}">{{ $variable['name'] ?? 'Unknown' }}</td>
                                                                <td class="py-2.5 text-right text-slate-400 dark:text-slate-500">{{ $variable['type'] ?? 'Unknown' }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        @endif
                                    @endif
                                    @endif
                                </div>
                                
                                <!-- Modal Footer -->
                                <div class="flex items-center justify-end p-4 border-t border-slate-100 dark:border-slate-800/60 rounded-b-3xl sticky bottom-0 bg-white dark:bg-slate-900 z-10">
                                    <button type="button" x-on:click="$wire.showReportModal = false;" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition">
                                        Close Report
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            @elseif ($activeTab === 'clickup_tickets')
                <div wire:init="loadClickUpTasks" class="space-y-5 animate-fadeIn">
                    
                    <!-- Header Banner -->
                    <div class="bg-white/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm">
                        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div>
                                <div class="flex items-center gap-2 mb-1">
                                    <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp" class="h-5 w-auto dark:brightness-200" />
                                    <h3 class="text-lg font-extrabold text-slate-900 dark:text-white">Tickets & Tasks</h3>
                                </div>
                                <p class="text-xs text-slate-500 dark:text-slate-400">
                                    Live tickets from ClickUp folders assigned to {{ $clientDetails->company_name ?: ($clientDetails->user->name ?? 'this client') }}.
                                </p>
                            </div>

                            <div class="flex items-center gap-3">
                                <button type="button" wire:click="syncClientClickUpTasks" wire:loading.attr="disabled"
                                        class="inline-flex items-center gap-2 px-4 py-2 bg-[#135266] hover:bg-[#0f4152] text-white font-bold text-xs rounded-xl shadow transition active:scale-95">
                                    <svg wire:loading.class="animate-spin" wire:target="syncClientClickUpTasks" class="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                    </svg>
                                    <span wire:loading.remove wire:target="syncClientClickUpTasks">Sync Tickets API</span>
                                    <span wire:loading wire:target="syncClientClickUpTasks">Syncing...</span>
                                </button>
                            </div>
                        </div>

                        <!-- Mapped Folders Badges -->
                        <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center flex-wrap gap-2 text-xs">
                            <span class="font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider text-[10px]">Assigned Folders:</span>
                            @forelse($clientClickUpFolders as $cFolder)
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-400 font-bold border border-amber-500/20">
                                    <svg class="w-3.5 h-3.5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                    </svg>
                                    {{ $cFolder->name }}
                                </span>
                            @empty
                                <span class="text-slate-400 italic">No folders assigned yet.</span>
                            @endforelse
                        </div>
                    </div>

                    @if(!$clickUpTasksLoaded)
                        <!-- Livewire Deferred Loading Skeleton Animation -->
                        <div class="w-full space-y-4 animate-pulse">
                            <div class="h-14 bg-slate-200/60 dark:bg-slate-800/50 rounded-2xl w-full"></div>
                            <div class="space-y-4">
                                @for($i = 0; $i < 3; $i++)
                                    <div class="bg-white/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 space-y-4">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap-3">
                                                <div class="w-9 h-9 rounded-xl bg-slate-200 dark:bg-slate-800"></div>
                                                <div class="space-y-2">
                                                    <div class="w-44 h-4 bg-slate-200 dark:bg-slate-800 rounded-md"></div>
                                                    <div class="w-28 h-3 bg-slate-200/70 dark:bg-slate-800/50 rounded-md"></div>
                                                </div>
                                            </div>
                                            <div class="w-20 h-7 bg-slate-200 dark:bg-slate-800 rounded-full"></div>
                                        </div>
                                    </div>
                                @endfor
                            </div>
                        </div>
                    @else
                        @if($clientClickUpFolders->isEmpty())
                            <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-10 text-center">
                                <svg class="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                </svg>
                                <h4 class="font-bold text-slate-800 dark:text-slate-200 text-base mb-1">No ClickUp Folders Assigned</h4>
                                <p class="text-xs text-slate-400 max-w-sm mx-auto">No ClickUp folders currently mapped to this client.</p>
                            </div>
                        @else
                            <!-- Status & Folder Filters Bar -->
                            @if($clientClickUpFolders->count() > 1 || !empty($clientClickUpTasks))
                                <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-3.5 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                                    <span class="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5 shrink-0">
                                        <svg class="w-4 h-4 text-[#135266]" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
                                        </svg>
                                        Filter Tickets:
                                    </span>

                                    <div class="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto">
                                        <!-- Folder Filter -->
                                        @if($clientClickUpFolders->count() > 1)
                                            <select wire:model.live="clickUpTaskFolderFilter"
                                                    class="block w-full sm:w-48 px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#135266]/40 focus:border-[#135266]">
                                                <option value="">All Folders ({{ $clientClickUpFolders->count() }})</option>
                                                @foreach($clientClickUpFolders as $cf)
                                                    <option value="{{ $cf->id }}">{{ $cf->name }}</option>
                                                @endforeach
                                            </select>
                                        @endif

                                        <!-- Status Filter -->
                                        <select wire:model.live="clickUpTaskStatusFilter"
                                                class="block w-full sm:w-48 px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#135266]/40 focus:border-[#135266]">
                                            <option value="">All Statuses ({{ count($clickUpStatuses) }})</option>
                                            @foreach($clickUpStatuses as $st)
                                                <option value="{{ $st }}">{{ ucfirst($st) }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                            <!-- Tasks List (FAQ/Accordion for Multiple Folders, Flat View for Single Folder) -->
                            @if($clientClickUpFolders->count() > 1)
                                <div class="space-y-4">
                                    @foreach($clientClickUpFolders as $cFolder)
                                        @php
                                            $folderTasks = collect($filteredClickUpTasks)->where('folder_id', (string)$cFolder->id);
                                        @endphp
                                        <div x-data="{ open: false }" class="bg-white/80 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800/70 rounded-2xl overflow-hidden shadow-sm transition">
                                            <button type="button" @click="open = !open" 
                                                    class="w-full px-5 py-4 flex items-center justify-between gap-4 bg-slate-50/80 dark:bg-slate-800/50 hover:bg-slate-100/80 dark:hover:bg-slate-800/80 transition text-left">
                                                <div class="flex items-center gap-3">
                                                    <div class="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 shrink-0">
                                                        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                        </svg>
                                                    </div>
                                                    <div>
                                                        <h4 class="font-extrabold text-slate-900 dark:text-white text-base">
                                                            {{ $cFolder->name }}
                                                        </h4>
                                                        <p class="text-xs text-slate-500 dark:text-slate-400">
                                                            {{ count($folderTasks) }} {{ Str::plural('ticket', count($folderTasks)) }}
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="flex items-center gap-3">
                                                    <span class="px-2.5 py-1 rounded-full text-xs font-extrabold bg-[#135266]/10 text-[#135266] dark:bg-teal-400/10 dark:text-teal-400">
                                                        {{ count($folderTasks) }} {{ Str::plural('Ticket', count($folderTasks)) }}
                                                    </span>
                                                    <svg class="w-5 h-5 text-slate-400 transition-transform duration-200" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                    </svg>
                                                </div>
                                            </button>

                                            <div x-show="open" x-transition:enter="transition ease-out duration-200" class="p-4 border-t border-slate-100 dark:border-slate-800 space-y-3 bg-slate-50/30 dark:bg-slate-950/20">
                                                @forelse($folderTasks as $task)
                                                    <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 hover:border-slate-300 dark:hover:border-slate-700 rounded-2xl p-4 shadow-sm transition">
                                                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                                            <div class="space-y-1.5 flex-1 min-w-0">
                                                                <div class="flex items-center flex-wrap gap-2">
                                                                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                                                        {{ $task['list_name'] }}
                                                                    </span>
                                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider" style="background-color: {{ $task['status_color'] }}1a; color: {{ $task['status_color'] }}">
                                                                        <span class="w-1.5 h-1.5 rounded-full" style="background-color: {{ $task['status_color'] }}"></span>
                                                                        {{ $task['status'] }}
                                                                    </span>
                                                                </div>

                                                                <h4 class="font-extrabold text-slate-900 dark:text-white text-base leading-snug">
                                                                    {{ $task['name'] }}
                                                                </h4>

                                                                @if($task['description'])
                                                                    <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                                                        {{ $task['description'] }}
                                                                    </p>
                                                                @endif
                                                            </div>

                                                            <div class="flex sm:flex-col items-end justify-between sm:justify-center gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 dark:border-slate-800">
                                                                <a href="{{ $task['url'] }}" target="_blank"
                                                                   class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 font-bold text-xs rounded-xl transition">
                                                                    <span>Open Ticket</span>
                                                                    <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                                                    </svg>
                                                                </a>

                                                                <div class="flex items-center gap-3 text-xs text-slate-400 dark:text-slate-500">
                                                                    @if(!empty($task['assignees']))
                                                                        <div class="flex items-center -space-x-1.5" title="Assigned To: {{ implode(', ', array_column($task['assignees'], 'username')) }}">
                                                                            @foreach($task['assignees'] as $assignee)
                                                                                @if(!empty($assignee['profilePicture']))
                                                                                    <img src="{{ $assignee['profilePicture'] }}" alt="{{ $assignee['username'] }}" class="w-5 h-5 rounded-full object-cover border border-white dark:border-slate-900" />
                                                                                @else
                                                                                    <div class="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-white dark:border-slate-900 flex items-center justify-center text-[9px] font-bold">
                                                                                        {{ strtoupper(substr($assignee['username'], 0, 2)) }}
                                                                                    </div>
                                                                                @endif
                                                                            @endforeach
                                                                        </div>
                                                                    @else
                                                                        <span class="text-[11px] italic">Unassigned</span>
                                                                    @endif

                                                                    @if($task['date_created'])
                                                                        <span class="text-[11px] font-mono">{{ $task['date_created'] }}</span>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @empty
                                                    <div class="py-6 text-center text-slate-400 text-xs italic">
                                                        No active tickets found in this folder.
                                                    </div>
                                                @endforelse
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <!-- Single Folder Flat View -->
                                <div class="space-y-3">
                                    @forelse($filteredClickUpTasks as $task)
                                        <div class="bg-white/80 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800/60 hover:border-slate-300 dark:hover:border-slate-700 rounded-2xl p-4 shadow-sm transition">
                                            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                                <div class="space-y-1.5 flex-1 min-w-0">
                                                    <div class="flex items-center flex-wrap gap-2">
                                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                                            <svg class="w-3 h-3 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                            </svg>
                                                            {{ $task['folder_name'] }} / {{ $task['list_name'] }}
                                                        </span>

                                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider" style="background-color: {{ $task['status_color'] }}1a; color: {{ $task['status_color'] }}">
                                                            <span class="w-1.5 h-1.5 rounded-full" style="background-color: {{ $task['status_color'] }}"></span>
                                                            {{ $task['status'] }}
                                                        </span>
                                                    </div>

                                                    <h4 class="font-extrabold text-slate-900 dark:text-white text-base leading-snug">
                                                        {{ $task['name'] }}
                                                    </h4>

                                                    @if($task['description'])
                                                        <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                                                            {{ $task['description'] }}
                                                        </p>
                                                    @endif
                                                </div>

                                                <div class="flex sm:flex-col items-end justify-between sm:justify-center gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 dark:border-slate-800">
                                                    <a href="{{ $task['url'] }}" target="_blank"
                                                       class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 font-bold text-xs rounded-xl transition">
                                                        <span>Open Ticket</span>
                                                        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                                        </svg>
                                                    </a>

                                                    <div class="flex items-center gap-3 text-xs text-slate-400 dark:text-slate-500">
                                                        @if(!empty($task['assignees']))
                                                            <div class="flex items-center -space-x-1.5" title="Assigned To: {{ implode(', ', array_column($task['assignees'], 'username')) }}">
                                                                @foreach($task['assignees'] as $assignee)
                                                                    @if(!empty($assignee['profilePicture']))
                                                                        <img src="{{ $assignee['profilePicture'] }}" alt="{{ $assignee['username'] }}" class="w-5 h-5 rounded-full object-cover border border-white dark:border-slate-900" />
                                                                    @else
                                                                        <div class="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-white dark:border-slate-900 flex items-center justify-center text-[9px] font-bold">
                                                                            {{ strtoupper(substr($assignee['username'], 0, 2)) }}
                                                                        </div>
                                                                    @endif
                                                                @endforeach
                                                            </div>
                                                        @else
                                                            <span class="text-[11px] italic">Unassigned</span>
                                                        @endif

                                                        @if($task['date_created'])
                                                            <span class="text-[11px] font-mono">{{ $task['date_created'] }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @empty
                                        <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-8 text-center text-slate-400 text-xs">
                                            No ClickUp tickets found matching your filter criteria.
                                        </div>
                                    @endforelse
                                </div>
                            @endif
                        @endif
                    @endif
                </div>

            @elseif ($activeTab === 'maintenance')
                <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl overflow-hidden shadow-sm animate-fadeIn">
                    @if ($clientMaintenanceReports->isEmpty())
                        <div class="text-center py-12 text-slate-500">No reports yet</div>
                    @else
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                    <th class="px-6 py-4">ID</th>
                                    <th class="px-6 py-4">Month</th>
                                    <th class="px-6 py-4">Score</th>
                                    <th class="px-6 py-4">Status</th>
                                    <th class="px-6 py-4">Author</th>
                                    <th class="px-6 py-4 text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                                @foreach ($clientMaintenanceReports as $report)
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                        <td class="px-6 py-4 text-slate-450 dark:text-slate-500">#{{ $report->id }}</td>
                                        <td class="px-6 py-4 font-bold text-slate-900 dark:text-white">
                                            <a href="{{ route('staff.maintenance.view', $report->id) }}" class="hover:text-indigo-600 dark:hover:text-indigo-400 hover:underline">
                                                {{ $report->maintenance_month }}
                                            </a>
                                        </td>
                                        <td class="px-6 py-4 font-bold text-slate-700 dark:text-slate-350">{{ $report->health_score }}%</td>
                                        <td class="px-6 py-4">
                                            <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase {{ $report->status === 'completed' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-amber-500/10 text-amber-600 dark:text-amber-400' }} tracking-wider">
                                                {{ $report->status }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-slate-600 dark:text-slate-400 font-semibold">{{ $report->developer->name ?? 'System' }}</td>
                                        <td class="px-6 py-4 text-right">
                                            <div class="inline-flex items-center justify-end gap-1">
                                                {{-- View button --}}
                                                <a href="{{ route('staff.maintenance.view', $report->id) }}"
                                                   class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="View Report">
                                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                                    </svg>
                                                </a>

                                                {{-- Edit button --}}
                                                <a href="{{ route('staff.maintenance.edit', $report->id) }}"
                                                   class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="Edit Report">
                                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                    </svg>
                                                </a>

                                                {{-- PDF button --}}
                                                <a href="{{ route('staff.maintenance.pdf', $report->id) }}" target="_blank"
                                                   class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150" title="Generate PDF">
                                                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                    </svg>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="mt-4 p-4 border-t border-slate-200/50 dark:border-slate-800/40">
                            {{ $clientMaintenanceReports->links() }}
                        </div>
                    @endif
                </div>

            @elseif ($activeTab === 'documents')
                <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl overflow-hidden shadow-sm animate-fadeIn">
                    @if ($clientDocuments->isEmpty())
                        <div class="text-center py-12 text-slate-500">No resources uploaded yet.</div>
                    @else
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                                    <th class="px-6 py-4">Name</th>
                                    <th class="px-6 py-4">Type</th>
                                    <th class="px-6 py-4">Size</th>
                                    <th class="px-6 py-4">Uploaded</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                                @foreach ($clientDocuments as $doc)
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                        <td class="px-6 py-4 font-bold text-indigo-600 dark:text-indigo-400">
                                            <a href="{{ asset('storage/' . $doc->file_path) }}" target="_blank" class="hover:underline">
                                                {{ $doc->title }}
                                            </a>
                                        </td>
                                        <td class="px-6 py-4 text-slate-600 dark:text-slate-400 uppercase font-bold text-xs">{{ $doc->file_type ?: 'PDF' }}</td>
                                        <td class="px-6 py-4 text-slate-650 dark:text-slate-350 font-semibold">{{ $doc->file_size ? number_format($doc->file_size / (1024 * 1024), 1) . ' MB' : '—' }}</td>
                                        <td class="px-6 py-4 text-slate-500 dark:text-slate-550 text-xs font-medium">{{ $doc->created_at->format('Y-m-d') }} - {{ $doc->addedBy->name ?? 'System' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="mt-4 p-4 border-t border-slate-200/50 dark:border-slate-800/40">
                            {{ $clientDocuments->links() }}
                        </div>
                    @endif
                </div>

            @elseif ($activeTab === 'activity log')
                <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-6 shadow-sm animate-fadeIn">
                    @if ($clientActivityLogs->isEmpty())
                        <div class="text-center py-6 text-slate-500">No activity logs recorded yet.</div>
                    @else
                        <div class="flow-root">
                            <ul class="-mb-8">
                                @foreach ($clientActivityLogs as $log)
                                    <li>
                                        <div class="relative pb-8">
                                            @if (!$loop->last)
                                                <span class="absolute top-4 left-4 -ml-px h-full w-0.5 bg-slate-200 dark:bg-slate-800/50"></span>
                                            @endif
                                            <div class="relative flex space-x-3">
                                                <div>
                                                    <span class="h-8 w-8 rounded-full bg-indigo-50 dark:bg-indigo-950/20 flex items-center justify-center border border-indigo-100 dark:border-indigo-900/25">
                                                        <svg class="h-4 w-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="flex-1 min-w-0 pt-1.5 flex justify-between space-x-4">
                                                    <div>
                                                        <p class="text-sm text-slate-600 dark:text-slate-350 font-semibold">{{ $log->description }}</p>
                                                    </div>
                                                    <div class="text-right text-xs whitespace-nowrap text-slate-400 dark:text-slate-500">
                                                        <time datetime="{{ $log->created_at }}">{{ $log->created_at->diffForHumans() }}</time>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="mt-4">
                            {{ $clientActivityLogs->links() }}
                        </div>
                    @endif
                </div>
            @endif
        </div>

    @else
        {{-- Clients List view --}}

        <!-- View Tabs -->
        <div class="flex border-b border-slate-200/60 dark:border-slate-800/40 mb-4 mt-2">
            <button type="button" wire:click="setViewTab('my_clients')"
                    class="py-3 px-6 border-b-2 font-bold text-sm transition-all duration-150 {{ $activeViewTab === 'my_clients' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300' }}">
                Clients
            </button>
            <button type="button" wire:click="setViewTab('all_clients')"
                    class="py-3 px-6 border-b-2 font-bold text-sm transition-all duration-150 {{ $activeViewTab === 'all_clients' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300' }}">
                All Clients
            </button>
        </div>

        {{-- ══════════════════════════════════════════════
             STATISTICS SUMMARY GRID
             ══════════════════════════════════════════════ --}}
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 mt-4">
            {{-- Card 1: Total Clients --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Total Clients</p>
                    <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $totalClientsCount }}</h3>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 font-semibold mt-1.5 flex items-center gap-1">
                        <span class="text-emerald-500 font-bold">{{ $activeClientsCount }} active</span>
                        <span>•</span>
                        <span class="text-slate-400 font-bold">{{ $inactiveClientsCount }} inactive</span>
                    </p>
                </div>
                <div class="p-3 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                </div>
            </div>

            {{-- Card 2: Active Clients --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Active Clients</p>
                    <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $activeClientsCount }}</h3>
                    <p class="text-[11px] text-emerald-500 dark:text-emerald-400 font-semibold mt-1.5">active accounts</p>
                </div>
                <div class="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>

            {{-- Card 3: Inactive Clients --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Inactive Clients</p>
                    <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $inactiveClientsCount }}</h3>
                    <p class="text-[11px] text-slate-400 dark:text-slate-500 font-semibold mt-1.5">inactive / paused</p>
                </div>
                <div class="p-3 bg-amber-50 dark:bg-amber-950/20 text-amber-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                </div>
            </div>

            {{-- Card 4: Total Websites --}}
            <div class="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/60 rounded-2xl p-5 shadow-sm flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Total Websites</p>
                    <h3 class="text-3xl font-medium text-[#135266] dark:text-white mt-1">{{ $totalWebsitesCount }}</h3>
                    <p class="text-[11px] text-indigo-500 dark:text-indigo-400 font-semibold mt-1.5 flex items-center gap-1">
                        <span class="text-emerald-500 font-bold">{{ $activeWebsitesCount }} active</span>
                        <span>•</span>
                        <span class="text-slate-400 font-bold">{{ $inactiveWebsitesCount }} inactive</span>
                    </p>
                </div>
                <div class="p-3 bg-sky-50 dark:bg-sky-950/20 text-sky-500 rounded-xl">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                    </svg>
                </div>
            </div>
        </div>

        {{-- Filters --}}
        <div class="bg-white/60 dark:bg-slate-900/40 border border-slate-200/50 dark:border-slate-800/40 rounded-2xl p-4 mb-5 shadow-sm relative z-30">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-3">

                {{-- Search --}}
                <div class="relative flex items-center">
                    <svg wire:loading.remove wire:target="search" class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <div wire:loading wire:target="search" class="absolute left-3 pointer-events-none shrink-0 z-10 flex items-center">
                        <svg class="animate-spin w-4 h-4 text-indigo-600 dark:text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </div>
                    <input wire:model.live.debounce.300ms="search"
                           type="text"
                           autocomplete="off"
                           placeholder="Search by name, email, or company..."
                           class="block w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 text-sm transition duration-150" />
                </div>

                {{-- Status Filter --}}
                <div class="relative flex items-center">
                    <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
                    </svg>
                    <select wire:model.live="statusFilter"
                            class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 text-sm transition duration-150 appearance-none">
                        <option value="" class="dark:bg-slate-900">All Statuses</option>
                        <option value="active" class="dark:bg-slate-900">Active</option>
                        <option value="inactive" class="dark:bg-slate-900">Inactive</option>
                    </select>
                    <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </div>

                {{-- Plan Filter --}}
                <div class="relative flex items-center">
                    <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    <select wire:model.live="planFilter"
                            class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 text-sm transition duration-150 appearance-none">
                        <option value="" class="dark:bg-slate-900">All Plans</option>
                        @foreach($plans as $planOpt)
                            <option value="{{ $planOpt->id }}" class="dark:bg-slate-900">{{ $planOpt->name }}</option>
                        @endforeach
                    </select>
                    <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </div>

                {{-- Per Page Filter --}}
                <div class="relative flex items-center">
                    <svg class="absolute left-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0 z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                    </svg>
                    <select wire:model.live="perPage"
                            class="block w-full pl-9 pr-8 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-pink-500/40 focus:border-pink-400 text-sm transition duration-150 appearance-none">
                        <option value="20" class="dark:bg-slate-900">20 per page</option>
                        <option value="50" class="dark:bg-slate-900">50 per page</option>
                        <option value="100" class="dark:bg-slate-900">100 per page</option>
                    </select>
                    <svg class="absolute right-3 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </div>
            </div>

            {{-- Clear Filters --}}
            @if($hasActiveFilters)
                <div class="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between">
                    <span class="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Filters active — showing filtered results
                    </span>
                    <button type="button" wire:click="clearFilters"
                            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 dark:bg-red-500/10 text-red-650 dark:text-red-400 border border-red-200/60 dark:border-red-800/30 hover:bg-red-100 dark:hover:bg-red-500/20 text-xs font-bold transition-all duration-150 active:scale-95">
                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        Clear Filters
                    </button>
                </div>
            @endif
        </div>

        <x-admin.card>
            @if ($clients->isEmpty())
                <div class="text-center py-12">
                    <svg class="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    @if ($activeViewTab === 'my_clients')
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-300 mb-1">No Assigned Clients</h3>
                        <p class="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">You do not have any clients assigned to you yet.</p>
                    @else
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-300 mb-1">No Clients Found</h3>
                        <p class="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">There are no clients matching the current filter criteria.</p>
                    @endif
                </div>
            @else
                <div id="staffClientsTableTop" class="overflow-x-auto rounded-2xl border border-slate-200/50 dark:border-slate-800/50" x-data="{
                    init() {
                        Livewire.on('scroll-to-top', () => {
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                        });
                    }
                }">
                    <table class="w-full min-w-[1100px] text-left border-collapse bg-white/40 dark:bg-slate-900/10 backdrop-blur-md">
                        <thead>
                            <tr class="border-b border-slate-200/50 dark:border-slate-800/50 bg-slate-50/50 dark:bg-slate-950/20 text-base font-normal text-slate-400 dark:text-slate-500 capitalize tracking-wider">
                                <th class="px-6 py-4 w-[280px]">Client Details</th>
                                <th class="px-6 py-4 w-[220px]">Company Name</th>
                                <th class="px-6 py-4 w-[150px]">Plans</th>
                                <th class="px-6 py-4 w-[100px]">Websites</th>
                                <th class="px-6 py-4 w-[160px]">Phone Numbers</th>
                                <th class="px-6 py-4 w-[100px]">Status</th>
                                <th class="px-6 py-4 w-[125px]">Registered</th>
                                <th class="px-6 py-4 w-[90px] text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody wire:loading.class="hidden" wire:target="search, statusFilter, planFilter, perPage, nextPage, previousPage, gotoPage" class="divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                            @foreach ($clients as $client)
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-900/10 transition-colors">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <a href="{{ route('staff.clients.detail', ['id' => $client->id]) }}" wire:navigate class="shrink-0">
                                                @if($client->profile_image)
                                                    <img src="{{ asset('storage/' . $client->profile_image) }}" alt="{{ $client->user->name }}" class="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-800" />
                                                @else
                                                    <div class="w-9 h-9 rounded-full bg-[#d0e7ec] dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-xs font-medium font-momo text-[#135266] dark:text-indigo-400">
                                                        {{ $client->getInitials() }}
                                                    </div>
                                                @endif
                                            </a>
                                            <div>
                                                <a href="{{ route('staff.clients.detail', ['id' => $client->id]) }}" wire:navigate class="font-medium  text-[#135266] font-momo dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 transition block">
                                                    {{ $client->user->name ?? 'Deleted User' }}
                                                </a>
                                                <div class="text-xs text-slate-400 dark:text-slate-500">{{ $client->user->email ?? 'N/A' }}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-slate-700 dark:text-slate-350 font-semibold">
                                        <a href="{{ route('staff.clients.detail', ['id' => $client->id]) }}" wire:navigate class="hover:text-indigo-600 dark:hover:text-indigo-400 transition">
                                            {{ $client->company_name ?: '—' }}
                                        </a>
                                    </td>
                                    <td class="px-6 py-4">
                                        @if($client->plans->isNotEmpty())
                                            <div class="flex flex-wrap gap-1">
                                                @foreach($client->plans as $pl)
                                                    <span class="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-{{ $pl->color }}-500/10 text-{{ $pl->color }}-600 dark:text-{{ $pl->color }}-400 tracking-wider">
                                                        {{ $pl->name }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @else
                                            —
                                        @endif
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50">
                                            <svg class="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                            </svg>
                                            {{ $client->websites_count }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-slate-500 dark:text-slate-400 font-medium text-xs">
                                        @if($client->phones->isEmpty())
                                            {{ $client->phone ?: '—' }}
                                        @else
                                            <div class="space-y-1">
                                                @foreach($client->phones as $phoneRec)
                                                    <div><span class="font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest text-[9px] mr-1">{{ $phoneRec->label }}:</span> {{ $phoneRec->phone }}</div>
                                                @endforeach
                                            </div>
                                        @endif
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2.5 py-1 text-xs font-bold rounded-lg
                                              {{ $client->status === 'active'
                                                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                                  : 'bg-slate-500/10 text-slate-500 dark:text-slate-400' }}">
                                            {{ ucfirst($client->status) }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-xs text-slate-400 dark:text-slate-500 font-medium">
                                        {{ $client->created_at->diffForHumans() }}
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        @php
                                            $clickUpFolderIds = $client->clickUpFolders->pluck('id')->map(fn($id) => (string)$id)->toArray();
                                            $clientMappingData = [
                                                'id' => $client->id,
                                                'name' => $client->user->name ?? 'Client',
                                                'email' => $client->user->email ?? '',
                                                'company_name' => $client->company_name ?? '',
                                                'initials' => $client->getInitials(),
                                            ];
                                        @endphp
                                        <div class="inline-flex items-center justify-end gap-1.5 shrink-0">
                                            @if(!empty($clickUpFolderIds))
                                                <button type="button"
                                                        wire:click="disconnectClickUpMapping({{ $client->id }})"
                                                        wire:confirm="Are you sure you want to disconnect ClickUp from {{ $client->company_name ?: ($client->user->name ?? 'this client') }}?"
                                                        class="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-rose-50 dark:bg-rose-500/10 border border-rose-200/80 dark:border-rose-800/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-500/20 shadow-sm transition-all duration-150 active:scale-95 shrink-0"
                                                        title="Disconnect ClickUp from {{ $client->user->name ?? 'Client' }}">
                                                    <span class="hidden 2xl:inline">Disconnect</span>
                                                    <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                                                </button>
                                            @else
                                                <button type="button" 
                                                        @click="
                                                            $dispatch('open-clickup-modal', { client: {{ Js::from($clientMappingData) }}, folderIds: {{ Js::from($clickUpFolderIds) }} });
                                                            $dispatch('open-modal', { name: 'clickup-client-mapping-modal' });
                                                        "
                                                        class="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-sm transition-all duration-150 active:scale-95 shrink-0"
                                                        title="Map ClickUp Folders to this Client">
                                                        <span class="hidden 2xl:inline">Map With</span>
                                                    <img src="{{ asset('aspire-hub-clickup-logo.svg') }}" alt="ClickUp Logo" class="h-4 w-auto shrink-0 dark:brightness-200" />
                                                </button>
                                            @endif

                                            <a href="{{ route('staff.clients.detail', ['id' => $client->id]) }}" wire:navigate
                                               class="inline-flex items-center justify-center p-2 rounded-xl text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all duration-150 active:scale-90" title="View Details">
                                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                                </svg>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tbody wire:loading.class.remove="hidden" wire:target="search, statusFilter, planFilter, perPage, nextPage, previousPage, gotoPage" class="hidden divide-y divide-slate-100 dark:divide-slate-900/50 text-sm">
                            @for($i = 0; $i < $perPage; $i++)
                                <tr class="animate-pulse bg-white/20 dark:bg-slate-900/5">
                                    <td class="px-6 py-4"><div class="flex items-center gap-3"><div class="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-700 shrink-0"></div><div class="space-y-2 flex-1"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-32"></div><div class="h-3 bg-slate-200 dark:bg-slate-700 rounded w-24"></div></div></div></td>
                                    <td class="px-6 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-28"></div></td>
                                    <td class="px-6 py-4"><div class="flex gap-1"><div class="h-5 bg-slate-200 dark:bg-slate-700 rounded w-16"></div><div class="h-5 bg-slate-200 dark:bg-slate-700 rounded w-16"></div></div></td>
                                    <td class="px-6 py-4"><div class="h-6 bg-slate-200 dark:bg-slate-700 rounded-full w-12"></div></td>
                                    <td class="px-6 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-28"></div></td>
                                    <td class="px-6 py-4"><div class="h-6 bg-slate-200 dark:bg-slate-700 rounded-lg w-16"></div></td>
                                    <td class="px-6 py-4"><div class="h-4 bg-slate-200 dark:bg-slate-700 rounded w-20"></div></td>
                                    <td class="px-6 py-4"><div class="flex justify-end"><div class="w-20 h-7 rounded-xl bg-slate-200 dark:bg-slate-700"></div></div></td>
                                </tr>
                            @endfor
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    {{ $clients->links() }}
                </div>
            @endif
        </x-admin.card>
    @endif
    <!-- ClickUp Folder Mapping Modal -->
    @php
        $formattedFolders = $allClickUpFolders->map(function($f) {
            return [
                'id' => (string) $f->id,
                'name' => $f->name,
                'clickup_space_id' => (string) $f->clickup_space_id,
                'client_id' => $f->client_id ? (string) $f->client_id : null,
                'client_name' => $f->client ? ($f->client->company_name ?: ($f->client->user->name ?? 'Client #'.$f->client_id)) : null,
            ];
        })->values()->toArray();

        $formattedSpaces = $clickUpSpaces->map(function($s) {
            return [
                'id' => (string) $s->id,
                'name' => $s->name,
                'color' => $s->color ?: '#135266',
                'folders_count' => $s->folders_count ?? count($s->folders),
            ];
        })->values()->toArray();
    @endphp

    <x-admin.modal name="clickup-client-mapping-modal" title="Map ClickUp Folders to Client" maxWidth="max-w-3xl">
        <div x-data="{
                mappingClient: null,
                clickUpSpaceId: '',
                clickUpFolderSearch: '',
                selectedClickUpFolderIds: [],
                allFolders: {{ Js::from($formattedFolders) }},
                clickUpSpaces: {{ Js::from($formattedSpaces) }},

                get filteredFolders() {
                    if (!this.clickUpSpaceId) return [];
                    const search = this.clickUpFolderSearch.trim().toLowerCase();
                    return this.allFolders.filter(f => {
                        const spaceMatch = String(f.clickup_space_id) === String(this.clickUpSpaceId);
                        const searchMatch = !search || f.name.toLowerCase().includes(search);
                        return spaceMatch && searchMatch;
                    });
                },

                toggleFolder(folderId) {
                    const idStr = String(folderId);
                    const idx = this.selectedClickUpFolderIds.indexOf(idStr);
                    if (idx > -1) {
                        this.selectedClickUpFolderIds.splice(idx, 1);
                    } else {
                        this.selectedClickUpFolderIds.push(idStr);
                    }
                },

                saveMapping() {
                    if (!this.mappingClient) return;
                    $wire.saveClickUpMapping(this.mappingClient.id, this.selectedClickUpFolderIds);
                }
             }"
             @open-clickup-modal.window="
                mappingClient = $event.detail.client;
                selectedClickUpFolderIds = ($event.detail.folderIds || []).map(String);
                clickUpFolderSearch = '';

                let autoSpaceId = '';
                if (selectedClickUpFolderIds.length > 0) {
                    const assignedFolder = allFolders.find(f => selectedClickUpFolderIds.includes(String(f.id)));
                    if (assignedFolder && assignedFolder.clickup_space_id) {
                        autoSpaceId = String(assignedFolder.clickup_space_id);
                    }
                }
                if (!autoSpaceId && clickUpSpaces.length > 0) {
                    autoSpaceId = String(clickUpSpaces[0].id);
                }
                clickUpSpaceId = autoSpaceId;
             ">
            
            <template x-if="mappingClient">
                <div class="space-y-5">
                    <!-- Client Header Banner -->
                    <div class="bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-[#135266]/10 text-[#135266] dark:bg-[#135266]/30 dark:text-teal-300 flex items-center justify-center font-bold text-sm"
                                 x-text="mappingClient.initials || 'CL'">
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-800 dark:text-white text-base" x-text="mappingClient.company_name || mappingClient.name || 'Client'">
                                </h4>
                                <p class="text-xs text-slate-400 dark:text-slate-400">
                                    <span x-text="mappingClient.name"></span> (<span x-text="mappingClient.email"></span>)
                                </p>
                            </div>
                        </div>

                        <button type="button" wire:click="syncClickUpApi" wire:loading.attr="disabled"
                                class="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-200/70 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition">
                            <svg wire:loading.class="animate-spin" wire:target="syncClickUpApi" class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                            </svg>
                            <span wire:loading.remove wire:target="syncClickUpApi">Sync ClickUp API</span>
                            <span wire:loading wire:target="syncClickUpApi">Syncing...</span>
                        </button>
                    </div>

                    <!-- ClickUp Spaces Selection Grid -->
                    <div class="space-y-2.5">
                        <div class="flex items-center justify-between">
                            <label class="block text-[11px] font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                                <svg class="w-3.5 h-3.5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                                </svg>
                                Select ClickUp Space
                            </label>
                            <span class="text-[10px] font-extrabold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-2.5 py-0.5 rounded-full border border-slate-200/60 dark:border-slate-700/60"
                                  x-text="(clickUpSpaces.length || 0) + ' Spaces'">
                            </span>
                        </div>

                        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-52 overflow-y-auto pr-1 custom-scrollbar">
                            <template x-for="space in clickUpSpaces" :key="space.id">
                                <button type="button" 
                                        @click="clickUpSpaceId = space.id"
                                        :class="clickUpSpaceId === space.id ? 'bg-gradient-to-br from-indigo-50/90 to-slate-50 dark:from-slate-800 dark:to-slate-850 border-indigo-500 dark:border-indigo-400 shadow-md ring-2 ring-indigo-500/20' : 'bg-white dark:bg-slate-800/70 border-slate-200/80 dark:border-slate-700/70 hover:border-indigo-300 dark:hover:border-indigo-600 hover:shadow-sm'"
                                        class="group relative text-left p-3 rounded-2xl border transition-all duration-200 flex flex-col justify-between gap-2.5 overflow-hidden">
                                    
                                    <div class="flex items-start justify-between gap-1.5">
                                        <div class="flex items-center gap-2 min-w-0">
                                            <span class="w-3 h-3 rounded-full shrink-0 shadow-sm border border-black/10" :style="'background-color: ' + space.color"></span>
                                            <h5 class="text-xs font-bold truncate transition-colors"
                                                :class="clickUpSpaceId === space.id ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400'"
                                                x-text="space.name">
                                            </h5>
                                        </div>
                                        <template x-if="clickUpSpaceId === space.id">
                                            <span class="w-4 h-4 rounded-full bg-indigo-600 text-white text-[9px] font-black flex items-center justify-center shrink-0 shadow-sm">✓</span>
                                        </template>
                                    </div>

                                    <div class="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-400 font-medium pt-1.5 border-t border-slate-100 dark:border-slate-750/50">
                                        <span class="flex items-center gap-1 font-semibold">
                                            <svg class="w-3 h-3 text-amber-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                            </svg>
                                            <span x-text="space.folders_count + ' folders'"></span>
                                        </span>
                                        <template x-if="clickUpSpaceId === space.id">
                                            <span class="text-indigo-600 dark:text-indigo-400 font-extrabold uppercase tracking-wider text-[9px]">Selected</span>
                                        </template>
                                    </div>
                                </button>
                            </template>
                        </div>
                    </div>

                    <!-- Folders Live Search Input -->
                    <template x-if="clickUpSpaceId">
                        <div class="relative">
                            <svg class="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                            <input x-model="clickUpFolderSearch"
                                   type="text"
                                   placeholder="Search ClickUp folder name in this space..."
                                   class="block w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-[#135266]/40 focus:border-[#135266]" />
                        </div>
                    </template>

                    <!-- Folders List Container with Checkboxes -->
                    <div class="border border-slate-200/80 dark:border-slate-700/80 rounded-2xl overflow-hidden bg-white dark:bg-slate-900">
                        <div class="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 custom-scrollbar">
                            <template x-if="!clickUpSpaceId">
                                <div class="px-6 py-10 text-center">
                                    <svg class="w-10 h-10 text-[#135266]/40 dark:text-teal-500/40 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                                    </svg>
                                    <p class="text-xs font-bold text-slate-700 dark:text-slate-300">No Space Selected</p>
                                    <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">Please click on a ClickUp Space tab above to view and assign folders.</p>
                                </div>
                            </template>
                            <template x-if="clickUpSpaceId">
                                <div>
                                    <template x-for="folder in filteredFolders" :key="folder.id">
                                        <label class="flex items-center justify-between px-4 py-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 cursor-pointer transition"
                                               :class="selectedClickUpFolderIds.includes(String(folder.id)) ? 'bg-indigo-50/40 dark:bg-indigo-950/20' : ''">
                                            <div class="flex items-center gap-3">
                                                <input type="checkbox"
                                                       @change="toggleFolder(folder.id)"
                                                       :checked="selectedClickUpFolderIds.includes(String(folder.id))"
                                                       class="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-[#135266] focus:ring-[#135266]/40 focus:ring-2 cursor-pointer" />
                                                
                                                <div>
                                                    <div class="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                                                        <svg class="w-4 h-4 text-amber-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                                        </svg>
                                                        <span x-text="folder.name"></span>
                                                    </div>
                                                    <div class="text-[11px] text-slate-400 font-mono" x-text="'ID: ' + folder.id"></div>
                                                </div>
                                            </div>

                                            <!-- Status Badge -->
                                            <div>
                                                <template x-if="selectedClickUpFolderIds.includes(String(folder.id))">
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                                        Assigned to this Client
                                                    </span>
                                                </template>
                                                <template x-if="mappingClient && !selectedClickUpFolderIds.includes(String(folder.id)) && folder.client_id && folder.client_id !== String(mappingClient.id)">
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400" :title="'Assigned to ' + folder.client_name">
                                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                                        <span x-text="'Assigned: ' + folder.client_name"></span>
                                                    </span>
                                                </template>
                                                <template x-if="mappingClient && !selectedClickUpFolderIds.includes(String(folder.id)) && (!folder.client_id || folder.client_id === String(mappingClient.id))">
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                                                        Unassigned
                                                    </span>
                                                </template>
                                            </div>
                                        </label>
                                    </template>
                                    <template x-if="filteredFolders.length === 0">
                                        <div class="px-6 py-8 text-center text-slate-400 dark:text-slate-500 text-xs">
                                            No ClickUp folders found in this space matching your search.
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    <!-- Footer Summary & Actions -->
                    <div class="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                        <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            Selected <span class="font-extrabold text-[#135266] dark:text-teal-400" x-text="selectedClickUpFolderIds.length"></span> folder(s) for this client
                        </div>

                        <div class="flex items-center gap-3">
                            <template x-if="mappingClient && selectedClickUpFolderIds.length > 0">
                                <button type="button" 
                                        @click="if (confirm('Are you sure you want to disconnect ClickUp from ' + (mappingClient.company_name || mappingClient.name) + '?')) { $wire.disconnectClickUpMapping(mappingClient.id); }"
                                        class="px-4 py-2 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-800/40 hover:bg-rose-100 dark:hover:bg-rose-500/20 transition duration-150">
                                    Disconnect ClickUp
                                </button>
                            </template>

                            <button type="button" @click="$dispatch('close-modal', { name: 'clickup-client-mapping-modal' })"
                                    class="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition duration-150">
                                Cancel
                            </button>

                            <button type="button" @click="saveMapping()"
                                    class="px-5 py-2 bg-[#135266] hover:bg-[#0f4152] text-white text-xs font-bold rounded-xl shadow transition duration-150">
                                Save ClickUp Mapping
                            </button>
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </x-admin.modal>
</div>
